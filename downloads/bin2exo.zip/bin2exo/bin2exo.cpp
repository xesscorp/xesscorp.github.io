#include <stdio.h>
#include <stdlib.h>
#include "exo_record.h"

void
print_help(char *argv[]);


int
main(int argc, char *argv[])
{
		exo_record Record;				// The S-record.
		int iBytesPerRecord;			// The # of data bytes per record.
		int iStartAddress;				// The start address for the first record.
		int iBytesRead;					// Return value of fread()
		FILE *pInFile, *pOutFile;		// Input and output files.
		char *pcBuffer;					// Holds data read from fread()

		// Check for the correct number of arguments
		if (argc != 5)
		{
				fprintf (stderr, "Incorrect number of arguments.\n");
				print_help(argv);
				return -1;
		}

		// Get the number of bytes per record
		iBytesPerRecord = atoi(argv[1]);
		printf("Setting the number of data bytes per record to %d\n", iBytesPerRecord);
		Record.set_bytes_in_record(iBytesPerRecord);
		pcBuffer = new char[iBytesPerRecord];
		if (pcBuffer == NULL)
		{
				fprintf(stderr, "ERROR:  Unable to allocate buffer.\n");
				return -1;
		}

		// Attach the record to the new buffer.
		Record.set_buffer(pcBuffer);

		// Get the start address
		sscanf(argv[2], "%x", &iStartAddress);
		printf("Setting start address to 0x%06x\n", iStartAddress);
		Record.set_start_address(iStartAddress);

		// Open the input and output files.
		pInFile = fopen(argv[3], "rb");
		if (pInFile == NULL)
		{
				fprintf(stderr, "ERROR:  Can't open file '%s' for reading.\n", argv[3]);
				delete [] pcBuffer;
				return -1;
		}

		pOutFile = fopen(argv[4], "w");
		if (pOutFile == NULL)
		{
				fprintf(stderr, "ERROR:  Can't open file '%s' for writing.\n", argv[4]);
				fclose(pInFile);
				delete [] pcBuffer;
				return -1;
		}


		// Read the input file and write the output file.
		Record.set_record_type(data_record);
		iBytesRead = fread(pcBuffer, 1, iBytesPerRecord, pInFile);
		while (iBytesRead != 0)
		{
				if (Record.print_record(pOutFile) != exo_ok)
				{
						fprintf(stderr, "ERROR:  Problem writing exo file.\n");
						fclose(pInFile);
						fclose(pOutFile);
						delete [] pcBuffer;
						return -1;
				}

				Record.increment_address();
				iBytesRead = fread(pcBuffer, 1, iBytesPerRecord, pInFile);
				Record.set_bytes_in_record(iBytesRead);
		}

		// Write the EOF record.
		Record.set_record_type(EOF_record);
		if (Record.print_record(pOutFile) != exo_ok)
		{
				fprintf(stderr, "ERROR:  Problem writing exo file.\n");
				fclose(pInFile);
				fclose(pOutFile);
				delete [] pcBuffer;
				return -1;
		}

		// Cleanup
		fclose(pInFile);
		fclose(pOutFile);
		delete [] pcBuffer;
		return 0;
} // end function main()


void
print_help(char *argv[])
{
		fprintf(stderr, "usage:  %s <#bytes/record> <start addr in hex> <infile> <outfile>\n", argv[0]);
		fprintf(stderr, "Input file is raw binary data.  Output file will be S-record format.\n");
}
