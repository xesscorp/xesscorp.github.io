#include <stdio.h>
#include <stdlib.h>
#include "exo_record.h"

/////////////////////////////////////////////////////////////////////
// Constructor.  Initialize the contents of the record.
exo_record::exo_record(void)
{
		RecordType = EOF_record;
		uiBytesInRecord = 0;
		uiAddress = 0;
		pcBuffer = NULL;
} // end method exo_record::exo_record()


/////////////////////////////////////////////////////////////////////
void
exo_record::set_record_type(EXO_RECORD_TYPE NewType)
{
		RecordType = NewType;
} // end method exo_record::exo_set_record_type()


/////////////////////////////////////////////////////////////////////
void
exo_record::set_bytes_in_record(unsigned int uiNewBytesInRecord)
{
		uiBytesInRecord = uiNewBytesInRecord;
} // end method exo_record::exo_set_bytes_in_record()


/////////////////////////////////////////////////////////////////////
void
exo_record::set_start_address(unsigned int uiNewAddress)
{
		uiAddress = uiNewAddress;
} // end method exo_record::exo_set_start_address()


/////////////////////////////////////////////////////////////////////
void
exo_record::increment_address(void)
{
		uiAddress = uiAddress + uiBytesInRecord;
} // end method exo_record::increment_address()


/////////////////////////////////////////////////////////////////////
void
exo_record::increment_address(int iCount)
{
		uiAddress = uiAddress + (iCount * uiBytesInRecord);
} // end method exo_record::increment_address()


/////////////////////////////////////////////////////////////////////
void
exo_record::set_buffer(char *pcNewBuffer)
{
		pcBuffer = pcNewBuffer;
} // end method exo_record::set_buffer()


/////////////////////////////////////////////////////////////////////
// The checksum is the one's complement of the sum of all the bytes
// in the record including the bytes-in-record, the address, and all
// the data.  It doesn't include the S2 or S8 tag.
EXO_RETURN
exo_record::calc_checksum(void)
{
		unsigned i;

		// Make sure we have a valid data buffer.
		if ((pcBuffer == NULL) && (RecordType != EOF_record))
				return exo_no_buffer;

		// Add 4 to the bytes-in-record number for the address (3 bytes)
		// and the bytes-in-record entry itself (1 byte).
		uiCheckSum = uiBytesInRecord + 4;

		// Add all the bytes in the address.  The address for an EOF
		// record is always 0.
		if (RecordType != EOF_record)
		{
				for (i = 0; i < 3; i++)
						uiCheckSum += (uiAddress >> (8*i)) & 0x00FF;
		}

		// Add all the data bytes.
		for (i = 0; i < uiBytesInRecord; i++)
				uiCheckSum += pcBuffer[i];

		// Take the one's complement and keep the LSB.
		uiCheckSum = (~uiCheckSum) & 0x00FF;

		return exo_ok;
} // end method exo_record::calc_checksum()


/////////////////////////////////////////////////////////////////////
EXO_RETURN
exo_record::print_record(FILE *pOutFile)
{
		unsigned i;

		// Print the record type.
		switch (RecordType)
		{
				case data_record:
						fprintf(pOutFile, "S2");
						break;

				case EOF_record:
						fprintf(pOutFile, "S8");
						break;
		}; // end switch()

		// Print the byte count.
		if (((uiBytesInRecord < 1) || (uiBytesInRecord > 16)) && (RecordType != EOF_record))
		{
				fprintf(stderr, "ERROR:  Can't have %d bytes per record.\n",
								uiBytesInRecord);
				return exo_fail;
		}
		// Don't forget -- add 4 to the BytesInRecord for the byte count
		// (1 byte) and the address (3 bytes).
		fprintf(pOutFile, "%02x", (uiBytesInRecord+4));

		// Print the address.
		switch (RecordType)
		{
				case data_record:
						if (uiAddress > 0x00FFFFFF)
						{
								fprintf(stderr, "ERROR:  Address exceeded six byte maximum.\n");
								return exo_fail;
						}
						fprintf(pOutFile, "%06x", uiAddress);
						break;

				case EOF_record:
						fprintf(pOutFile, "%06x", 0);
						break;
		};

		// Print the data.
		switch (RecordType)
		{
				case data_record:
						for (i = 0; i < uiBytesInRecord; i++)
								fprintf(pOutFile, "%02x", pcBuffer[i]);
						break;

				case EOF_record:
						// No data to print.
						break;
		};

		// Print the checksum.
		if (calc_checksum() != exo_ok)
		{
				fprintf(stderr, "ERROR:  Problem calculating checksum.\n");
				return exo_fail;
		}
		// The XSTools expect \r\n for a newline.  You might have to remove
		// the \r if you're using a Windows compiler.
		fprintf(pOutFile, "%02x\r\n", uiCheckSum);

		return exo_ok;
} // end method exo_record::print_record()


/////////////////////////////////////////////////////////////////////
void
exo_record::blab(void)
{
		printf("Record contents:\n");
		switch(RecordType)
		{
				case (data_record):
						printf("\tdata_record\n");
						break;
				case EOF_record:
						printf("\tEOF_record\n");
						break;
		};

		printf("\t%d bytes per record\n", uiBytesInRecord);

		printf("\t0x%06x start address\n", uiAddress);

		fflush(stdout);

} // end method exo_record::blab()
