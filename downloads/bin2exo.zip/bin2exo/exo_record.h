#ifndef exo_record_h
#define exo_record_h

// Return values from exo_record methods.
typedef enum EXO_RETURN {exo_ok, exo_fail, exo_no_buffer, exo_file_full};

// Only two types of record -- data and EOF.
typedef enum EXO_RECORD_TYPE {data_record, EOF_record};

class exo_record
{
		private:
				EXO_RECORD_TYPE RecordType;		// Data or EOF?
				unsigned int uiBytesInRecord;	// How many bytes per record?
				unsigned int uiAddress;			// What address does this record start at?
				unsigned int uiCheckSum;		// The checksum for this record.
				char *pcBuffer;					// The data bytes.

				EXO_RETURN calc_checksum(void);	// Sets the checksum.  Called by print_record().

		public:
				// Constructor
				exo_record(void);

				void set_record_type(EXO_RECORD_TYPE NewType);

				void set_bytes_in_record(unsigned int uiNewBytesInRecord);

				void set_start_address(unsigned int uiNewAddress);

				// Increment the address by one record.
				void increment_address(void);

				// Increment (or decrement) the address by multiple records.
				void increment_address(int iCount);

				// Attach a data buffer to the record.
				void set_buffer(char *pcNewBuffer);

				// Print the record to the output file.
				EXO_RETURN print_record(FILE *pOutFile);

				// Debug.  Print out the contents of the record.
				void blab(void);
};	// end class exo_record


#endif // exo_record_h
