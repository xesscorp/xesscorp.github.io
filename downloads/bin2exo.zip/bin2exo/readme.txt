This program converts binary files into Motorola S-Record EXO files.

Run the program like so:

  bin2exo <#bytes/record> <start addr in hex> <infile> <outfile>

where:

  #bytes/record = the number of data bytes in each S-record not counting
      the bytes for the address and checksum

  start addr in hex = the starting address of the first S-record

  infile = the input file containing binary data

  outfile = the resulting EXO file containing S-records

You can test the program as follows:

  bin2exo 16 0000 test.bin test2.exo
  fc test.exo test2.exo

If the program is working correctly, the test2.exo file should match 
the test.exo file.

This program was compiled with Visual C++ 5.0.

This program was created by Roger Dickinson at Georgia Tech Research Institute.
You can reach him at roger.dickinson@gtri.gatech.edu.
