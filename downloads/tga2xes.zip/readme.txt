TGA2XES 8/27/2005 Charles Batiste

Tested with the XSA50 board and a photoshop image saved as 800x600x24bit TGA

Note: Only supports 24 or 32 bit tga images, but should be easy to support 16 and 8 bit

The test image is a picture of a girl eating a hamburger on a beach. It has many colors, but I think
the ouput can be improved with a better RGB quantizer.

usage:

tga2xes inputfile.tga ouputfile.xes
