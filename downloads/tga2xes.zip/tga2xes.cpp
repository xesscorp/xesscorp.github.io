/*

TGA2XES 8/27/2005 Charles Batiste

Tested with the XSA50 board and a photoshop saved 24bit TGA
Compiled using Visual Studio 6

Note: Only supports 24 or 32 bit tga images, but should be easy to support 16 and 8 bit

*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <memory.h>

//#define GRAYSCALE

#define BYTES_PER_LINE 16

typedef struct TGA_HEADER
{
   char  idlength;                // 0
   char  colourmaptype;           // 1
   char  datatypecode;            // 2
   char  pad[5];                  // 3
   short x_origin;                // 8
   short y_origin;                // 10
   short width;                   // 12
   short height;                  // 14
   char  bitsperpixel;            // 16
   char  imagedescriptor;         // 17
} TGA_HEADER;

TGA_HEADER header;

int LoadWidth()
{
	return header.width;
}

int LoadHeight()
{
	return header.height;
}

unsigned char *LoadTGA(char *name)
{
	FILE *f;
	unsigned char *data, *p;

	f = fopen(name, "rb");
	if (!f)
		return 0;
	fread(&header, sizeof(TGA_HEADER), 1, f);
	printf("tga %d %d %d\n", header.width, header.height, header.bitsperpixel);

	p = data = (unsigned char *)malloc(header.width * header.height * header.bitsperpixel);
	if (!data)
		return 0;

	for (int y=header.height-1; y>=0; y--)
  {
    p = data + (y * (int)header.width * 4);

		for (int x=0; x<header.width; x++)
		{
			if (header.bitsperpixel == 32)
			{
				fread(p, 1, 1, f);
				p++;
				fread(p, 1, 1, f);
				p++;
				fread(p, 1, 1, f);
				p++;
				fread(p, 1, 1, f);
				p++;
			}
			else if (header.bitsperpixel == 24)
			{
				fread(p, 1, 1, f);
				p++;
				fread(p, 1, 1, f);
				p++;
				fread(p, 1, 1, f);
				p++;
				*p++ = 0xff;
			}
		}
  }

	return data;
}

void main(char argc, char **argv)
{
	unsigned char *image;
	unsigned int addr=0;

// load image
	image = LoadTGA(argv[1]);
	if (!image)
	{
		printf("couldn't load TGA %s\n", argv[1]);
		exit(1);
	}

	if (LoadWidth() % BYTES_PER_LINE != 0)
	{
		printf("TGA width not multiple of %d\n", BYTES_PER_LINE);
		exit(1);
	}

//write out hex file
	FILE *fout;
	
	int color;
	int	bcount=0;

	fout = fopen(argv[2], "w");
	for (int y=0; y<LoadHeight(); y++)
		for (int x=0; x<LoadWidth(); x++)
		{
			unsigned char r, g, b, a;
			b = *image++;
			g = *image++;
			r = *image++;
			a = *image++;
#ifdef GRAYSCALE
      r = g = b = ((int)r + g + b) / 3;     // make image grayscale
#endif
			color = (((r >> 5) & 0x7) << 5) | (((g >> 6) & 0x3) << 3) | (((b >> 5) & 0x7) << 0);

			if ((bcount % BYTES_PER_LINE) == 0)
				fprintf(fout, "+ %02X %08X", BYTES_PER_LINE, addr);
			fprintf(fout, " %02X", color);
			if ((bcount % BYTES_PER_LINE) == (BYTES_PER_LINE-1))
			{
				fprintf(fout,"\n");
				addr += BYTES_PER_LINE;
			}

			bcount++;
		}

  fclose(fout);
}
