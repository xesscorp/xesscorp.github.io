#include "DLPORTIO.H"
#include <stdio.h>
#include <unistd.h>
#include <sys/io.h> 

int pinit(void)
{
  static int state=0;
  int result;
  
  if (state==0)
    {
      result=ioperm(0x378,3,1); //activate 3 ports
      setuid(getuid());
      state=1;
    }
  else
    {
      result=0;
    }
  return result;
}

unsigned char DlPortReadPortUchar(unsigned short Port)
{
  return inb(Port);
}

void DlPortWritePortUchar(unsigned short Port,unsigned char Value)
{
  outb(Value,Port);
}
