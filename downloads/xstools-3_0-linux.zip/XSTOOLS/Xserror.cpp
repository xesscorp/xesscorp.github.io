/*
 * This software is in the public domain.
 * You may use it as you see fit with the understanding that
 * we make no guarantees of its fitness for any particular purpose.
 *
 * Author: XESS Corporation
 *         www.xess.com
 */

//
// This object allows the reporting of errors with a standardized format.
//

// $Log: Xserror.cpp,v $
// Revision 1.2  2000/11/14 11:25:16  bretzdl
// Port to Linux. Makefile DLPORTIO.C added
//
// Revision 1.4  2000/09/10 16:53:00  DEVB
// Added #ifdef...#endif to remove calls to Windows message box functions
// when xserror object is used in command-line applications.
//
// Revision 1.3  2000/09/10 13:38:57  DEVB
// Error message object now gathers error messages for display in a
// Windows message box.
//
// Revision 1.2  1999/03/30 18:27:12  DEVB
// Released source into the public domain
//
// Revision 1.1  1999/03/29 22:02:44  DEVB
// Initial revision
//

#include <stdio.h>
#include <assert.h>
#ifdef _WINDOWS
#include "gxsload/stdafx.h"
#endif
#include "XSERROR.H"


// begin methods and functions

// init error object with output going to stream s
XSError::XSError(_IO_ostream_withassign & s)
{
  
	for(XSErrorSeverity i=XSErrorMin; i<XSErrorMax; i=(XSErrorSeverity)((int)i+1))
		SetNumErrors(i,0);
	_IO_ostream_withassign::operator=(s);
	state = XSErrorInitial;
	severity = XSErrorNone;
	header = "";
	storedMsg = "";
}

// destruct error object
XSError::~XSError(void)
{
	;
}

// assign contents of one source error object to another
XSError& XSError::operator= (XSError& src)
{
	for(XSErrorSeverity i=XSErrorMin; i<XSErrorMax; i=(XSErrorSeverity)((int)i+1))
	SetNumErrors(i,src.GetNumErrors(i));
	tie(&src);
	SetState(src.GetState());
	SetSeverity(src.GetSeverity());
	SetHeader(src.GetHeader());
	storedMsg = this->storedMsg;
	return *this;
}

// get number of errors of a certain type that have occurred
unsigned int XSError::GetNumErrors(XSErrorSeverity s) const
{
	assert(s>=XSErrorMin && s<XSErrorMax);
	return numErrors[s];
}

// set number of errors of a certain type that have occurred
void XSError::SetNumErrors(XSErrorSeverity s, unsigned int n)
{
	assert(s>=XSErrorMin && s<XSErrorMax);
	numErrors[s] = n;
}

// returns true if errors were recorded by this error object
bool XSError::IsError(void) const
{
	for(XSErrorSeverity i=XSErrorMin; i<XSErrorMax; i=(XSErrorSeverity)((int)i+1))
		if(GetNumErrors(i)) return 1; // yes, there were errors
		return 0; // no errors were recorded
}

XSErrorSeverity XSError::GetSeverity(void) const
{
	return severity;
}

// set severity of next error message
void XSError::SetSeverity(XSErrorSeverity s)
{
	severity = s;
	switch(GetSeverity())
	{
	case XSErrorFatal:
		(*this) << GetHeader().data() << " FATAL ERROR: ";
		SetState(XSErrorInMessage);
		break;
	case XSErrorMajor:
		(*this) << GetHeader().data() << " MAJOR ERROR: ";
		cout.flush();
		SetState(XSErrorInMessage);
		break;
	case XSErrorMinor:
		(*this) << GetHeader().data() << " MINOR ERROR: ";
		cout.flush();
		SetState(XSErrorInMessage);
		break;
	case XSErrorNone:
		(*this) << GetHeader().data() << ": ";
		cout.flush();
		SetState(XSErrorInMessage);
		break;
	default:
		SetSeverity(XSErrorMinor);
		(*this) << "\nerror severity was incorrectly set!\n";
		cout.flush();
		EndMsg();
		break;
	}
}

XSErrorState XSError::GetState(void) const
{
	return state;
}

void XSError::SetState(XSErrorState s )
{
	state = s;
}

// set header string for each error message
void XSError::SetHeader(string& h)
{
	header = h;
}

string& XSError::GetHeader(void)
{
	return header;
}

// end an error message
void XSError::EndMsg(void)
{
	switch(GetSeverity())
	{
	case XSErrorFatal:
		SetNumErrors(XSErrorFatal,GetNumErrors(XSErrorFatal)+1);
		operator<<("Abnormal termination of program\n");
#ifdef _WINDOWS
		AfxMessageBox(storedMsg.data(),MB_ICONSTOP);
#endif
		exit(1);
		break;
	case XSErrorMajor:
		SetNumErrors(XSErrorMajor,GetNumErrors(XSErrorMajor)+1);
#ifdef _WINDOWS
		AfxMessageBox(storedMsg.data(),MB_ICONINFORMATION);
#endif
		storedMsg = "";
		SetState(XSErrorInitial);
		break;
	case XSErrorMinor:
		SetNumErrors(XSErrorMinor,GetNumErrors(XSErrorMinor)+1);
#ifdef _WINDOWS
		AfxMessageBox(storedMsg.data(),MB_ICONINFORMATION);
#endif
		storedMsg = "";
		SetState(XSErrorInitial);
		break;
	case XSErrorNone:
		SetNumErrors(XSErrorNone,GetNumErrors(XSErrorNone)+1);
#ifdef _WINDOWS
		AfxMessageBox(storedMsg.data(),MB_ICONINFORMATION);
#endif
		storedMsg = "";
		SetState(XSErrorInitial);
		break;
	default:
		SetSeverity(XSErrorMinor);
		(*this) << "\nerror severity was not set!\n";
		cout.flush();
#ifdef _WINDOWS
		AfxMessageBox(storedMsg.data(),MB_ICONINFORMATION);
#endif
		storedMsg = "";
		SetState(XSErrorInitial);
		break;
	}
}

// a simple interface for sending an error message
void XSError::SimpleMsg(XSErrorSeverity s, string& msg)
{
	SetSeverity(s);
	(*this) << msg.data();
	EndMsg();
}


// overload << operator to assist in displaying error messages in a window
XSError& XSError::operator<<(long n)
{
	char num[30];
	printf(num,"%ld",n);
	string s = num;
	storedMsg = storedMsg + s;
	(_IO_ostream_withassign&)(*this) << num;
	return *this;
}

// overload << operator to assist in displaying error messages in a window
XSError& XSError::operator<<(const char* msg)
{
	string s = msg;
	storedMsg = storedMsg + s;
	(_IO_ostream_withassign&)(*this) << msg;
	return *this;
}

// overload << operator to assist in displaying error messages in a window
XSError& XSError::operator<<(string& msg)
{
	storedMsg = storedMsg + msg;
	(_IO_ostream_withassign&)(*this) << msg.data();
	return *this;
}

// overload << operator to assist in displaying error messages in a window
XSError& XSError::operator<<(ostream& s)
{
	(_IO_ostream_withassign&)(*this) << s;
	return *this;
}



