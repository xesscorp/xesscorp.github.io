// gxsloadDlg.h : header file
//

#if !defined(AFX_GXSLOADDLG_H__E2170D67_0451_11D3_8544_00A0CC3E3927__INCLUDED_)
#define AFX_GXSLOADDLG_H__E2170D67_0451_11D3_8544_00A0CC3E3927__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CGxsloadDlg dialog

class CGxsloadDlg : public CDialog
{
// Construction
public:
	CGxsloadDlg(CWnd* pParent = NULL);	// standard constructor

	void DownloadSelectedFiles(void);

// Dialog Data
	//{{AFX_DATA(CGxsloadDlg)
	enum { IDD = IDD_GXSLOAD_DIALOG };
	CStatic	m_statStatus;
	CListBox	m_lstFiles;
	CComboBox	m_cmbLpt;
	CButton	m_btnReload;
	BOOL	m_chkEEPROM;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGxsloadDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGxsloadDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnReload();
	afx_msg void OnSelchangeLstFiles();
	afx_msg void OnChkEeprom();
	//}}AFX_MSG
	afx_msg void OnDropFiles(HDROP hDropInfo);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GXSLOADDLG_H__E2170D67_0451_11D3_8544_00A0CC3E3927__INCLUDED_)
