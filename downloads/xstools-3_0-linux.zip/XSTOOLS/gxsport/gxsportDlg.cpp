// gxsportDlg.cpp : implementation file
//

#include <assert.h>

#include "stdafx.h"
#include "gxsport.h"
#include "gxsportDlg.h"

#include <stdlib.h>
#include <assert.h>
#include <strstrea.h>
#include <fstream.h>
#include <string>
using std::string;

#include "pport.h"
#include "utils.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGxsportDlg dialog

CGxsportDlg::CGxsportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGxsportDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGxsportDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGxsportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGxsportDlg)
	DDX_Control(pDX, IDC_COMBO_LPT, m_cmbLpt);
	DDX_Control(pDX, IDC_CHK_COUNT, m_chkCount);
	DDX_Control(pDX, IDC_BTN_STROBE, m_btnStrobe);
	DDX_Control(pDX, IDC_BTN_DATA7, m_btnData7);
	DDX_Control(pDX, IDC_BTN_DATA6, m_btnData6);
	DDX_Control(pDX, IDC_BTN_DATA5, m_btnData5);
	DDX_Control(pDX, IDC_BTN_DATA4, m_btnData4);
	DDX_Control(pDX, IDC_BTN_DATA3, m_btnData3);
	DDX_Control(pDX, IDC_BTN_DATA2, m_btnData2);
	DDX_Control(pDX, IDC_BTN_DATA1, m_btnData1);
	DDX_Control(pDX, IDC_BTN_DATA0, m_btnData0);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGxsportDlg, CDialog)
	//{{AFX_MSG_MAP(CGxsportDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_ACTIVATE()
	ON_BN_CLICKED(IDC_BTN_DATA0, OnBtnData0)
	ON_BN_CLICKED(IDC_BTN_DATA1, OnBtnData1)
	ON_BN_CLICKED(IDC_BTN_DATA2, OnBtnData2)
	ON_BN_CLICKED(IDC_BTN_DATA3, OnBtnData3)
	ON_BN_CLICKED(IDC_BTN_DATA4, OnBtnData4)
	ON_BN_CLICKED(IDC_BTN_DATA5, OnBtnData5)
	ON_BN_CLICKED(IDC_BTN_DATA6, OnBtnData6)
	ON_BN_CLICKED(IDC_BTN_DATA7, OnBtnData7)
	ON_BN_CLICKED(IDC_BTN_STROBE, OnBtnStrobe)
	ON_BN_CLICKED(IDC_CHK_COUNT, OnChkCount)
	ON_CBN_DBLCLK(IDC_COMBO_LPT, OnDblclkComboLpt)
	ON_CBN_SELCHANGE(IDC_COMBO_LPT, OnSelchangeComboLpt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int active=0;

/////////////////////////////////////////////////////////////////////////////
// CGxsportDlg message handlers

BOOL CGxsportDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// strobe button starts off disabled because there is no new data to output
	// to the parallel port
	m_btnStrobe.EnableWindow(false);

	// place parallel port numbers into the list box
	m_cmbLpt.AddString("LPT1");
	m_cmbLpt.AddString("LPT2");
	m_cmbLpt.AddString("LPT3");
	m_cmbLpt.SelectString(-1,"LPT1");  // select the default parallel port upon startup

	// initialize the parallel port object
	XSError errMsg(cerr); // setup error channel
	//Pport port(&errMsg,0,0x03);	// create parallel port object
	parPort = new Pport(&errMsg,1,0x03); // create parallel port object

	// initialize array of button pointers to the parallel port data buttons
	dataBtn[0] = &m_btnData0;
	dataBtn[1] = &m_btnData1;
	dataBtn[2] = &m_btnData2;
	dataBtn[3] = &m_btnData3;
	dataBtn[4] = &m_btnData4;
	dataBtn[5] = &m_btnData5;
	dataBtn[6] = &m_btnData6;
	dataBtn[7] = &m_btnData7;

	// display the parallel port data on the buttons
	newPortDataVal = parPort->GetData();
	DisplayBtnData(newPortDataVal);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGxsportDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGxsportDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGxsportDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


// initialize the button text to reflect the data value 
void CGxsportDlg::DisplayBtnData(unsigned int data)
{
	ASSERT(data>=0 && data<=255);
	int i;
	for(i=0; i<8; i++,data>>=1)
	{
		if((data&1) == 0)
			dataBtn[i]->SetWindowText("0");
		else
			dataBtn[i]->SetWindowText("1");
	}

}

void CGxsportDlg::OnBtnData(int bitPos)
{
	ASSERT(bitPos>=0 && bitPos<=7);

	// toggle the data bit and show the new value on the button
	if(newPortDataVal & (1<<bitPos))
	{ // data bit is 1 so reset it to 0
		newPortDataVal &= (~(1<<bitPos));
		dataBtn[bitPos]->SetWindowText("0");
	}
	else
	{ // data bit is 0 so set it to 1
		newPortDataVal |= (1<<bitPos);
		dataBtn[bitPos]->SetWindowText("1");
	}

	HandleStrobe();
}

void CGxsportDlg::OnBtnData0() 
{
	OnBtnData(0);
}

void CGxsportDlg::OnBtnData1() 
{
	OnBtnData(1);
}

void CGxsportDlg::OnBtnData2() 
{
	OnBtnData(2);
}

void CGxsportDlg::OnBtnData3() 
{
	OnBtnData(3);
}

void CGxsportDlg::OnBtnData4() 
{
	OnBtnData(4);
}

void CGxsportDlg::OnBtnData5() 
{
	OnBtnData(5);
}

void CGxsportDlg::OnBtnData6() 
{
	OnBtnData(6);
}

void CGxsportDlg::OnBtnData7() 
{
	OnBtnData(7);
}

void CGxsportDlg::HandleStrobe()
{
	// enable strobe button when counting or if the new data value
	// is different from the current parallel port data
	if(m_chkCount.GetCheck()==BST_UNCHECKED)
	{ // just setting data value with buttons
		if(newPortDataVal==parPort->GetData())
			m_btnStrobe.EnableWindow(false);
		else
			m_btnStrobe.EnableWindow(true);
	}
	else
	{ // here we are counting up the data value on the port
		m_btnStrobe.EnableWindow(true);
	}
}

void CGxsportDlg::OnBtnStrobe() 
{
	if(m_chkCount.GetCheck()==BST_UNCHECKED)
	{
		// place the new data value on the parallel port when strobe is clicked
		parPort->SetData(newPortDataVal);
		// then display the strobe button appropriately 
		HandleStrobe();
		// now the written value should match the value that is out there
		ASSERT(newPortDataVal == parPort->GetData());
		// remove focus from this window
		CWnd::SetFocus();
	}
	else
	{ // incrementing data port value
		parPort->SetData(newPortDataVal+1);
		newPortDataVal = parPort->GetData();
		DisplayBtnData(newPortDataVal);
	}
}

void CGxsportDlg::OnDblclkComboLpt() 
{
	int selection = m_cmbLpt.GetCurSel();
	if(selection != CB_ERR)
	{
		ASSERT(selection>=0 && selection<=2);
		parPort->SetNum(selection+1);
		newPortDataVal = parPort->GetData();
		DisplayBtnData(newPortDataVal);
		HandleStrobe();
	}
}

void CGxsportDlg::OnSelchangeComboLpt() 
{
	int selection = m_cmbLpt.GetCurSel();
	if(selection != CB_ERR)
	{
		ASSERT(selection>=0 && selection<=2);
		parPort->SetNum(selection+1);
		newPortDataVal = parPort->GetData();
		DisplayBtnData(newPortDataVal);
		HandleStrobe();
	}
}

void CGxsportDlg::OnChkCount() 
{
	HandleStrobe();	
}

void CGxsportDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	if(nState != WA_INACTIVE)
	{ // window is being re-activated, so update display of port data
		newPortDataVal = parPort->GetData();
		DisplayBtnData(newPortDataVal);
		HandleStrobe();
	}
}
