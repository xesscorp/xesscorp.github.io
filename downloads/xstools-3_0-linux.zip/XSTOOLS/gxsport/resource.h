//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gxsport.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GXSPORT_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_BTN_STROBE                  1008
#define IDC_BTN_DATA0                   1009
#define IDC_DATALBL0                    1010
#define IDC_LPTLBL                      1012
#define IDC_CHK_COUNT                   1013
#define IDC_COMBO_LPT                   1014
#define IDC_BTN_DATA1                   1016
#define IDC_BTN_DATA2                   1017
#define IDC_BTN_DATA3                   1018
#define IDC_BTN_DATA4                   1019
#define IDC_BTN_DATA5                   1020
#define IDC_BTN_DATA6                   1021
#define IDC_BTN_DATA7                   1022
#define IDC_DATALBL1                    1023
#define IDC_DATALBL2                    1024
#define IDC_DATALBL3                    1025
#define IDC_DATALBL4                    1026
#define IDC_DATALBL5                    1027
#define IDC_DATALBL6                    1028
#define IDC_DATALBL7                    1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
