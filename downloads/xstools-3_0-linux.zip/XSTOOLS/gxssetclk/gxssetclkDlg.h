// gxssetclkDlg.h : header file
//

#if !defined(AFX_GXSSETCLKDLG_H__5EBA40F6_7332_11D3_9A38_00A0CC3E3927__INCLUDED_)
#define AFX_GXSSETCLKDLG_H__5EBA40F6_7332_11D3_9A38_00A0CC3E3927__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CGxssetclkDlg dialog

class CGxssetclkDlg : public CDialog
{
// Construction
public:
	CGxssetclkDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGxssetclkDlg)
	enum { IDD = IDD_GXSSETCLK_DIALOG };
	CStatic	m_staticStatus;
	CEdit	m_editFreq;
	CComboBox	m_cmbLpt;
	CComboBox	m_cmbBoard;
	BOOL	m_chkExtClk;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGxssetclkDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGxssetclkDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSet();
	afx_msg void OnChkExtclk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GXSSETCLKDLG_H__5EBA40F6_7332_11D3_9A38_00A0CC3E3927__INCLUDED_)
