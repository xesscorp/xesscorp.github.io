//
// dsm.c -- show the operation of a delta-sigma modulator
//


#include <stdio.h>
#include <stdlib.h>


#define NUMBER_OF_BITS	200


int main(int argc, char *argv[]) {
  int numer, denom;
  int accu;
  int i;

  if (argc != 3) {
    printf("Usage: %s numerator denominator\n", argv[0]);
    exit(1);
  }
  numer = atoi(argv[1]);
  denom = atoi(argv[2]);
  /*
   * produce a bitstream with a given density (numer / denom) of ones
   */
  accu = 0;
  for (i = 0; i < NUMBER_OF_BITS; i++) {
    if (i % 20 == 0) {
      printf("\n");
    }
    accu += numer;
    if (accu >= denom) {
      accu -= denom;
      printf("1");
    } else {
      printf("0");
    }
  }
  printf("\n");
  return 0;
}
