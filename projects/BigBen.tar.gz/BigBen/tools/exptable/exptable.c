/*
 * exptable.c -- generate values for an exponential table
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define OUTFILE_NAME	"exp_mem.init"
#define INSTANCE_NAME	"exp_slope_mem"

#define EXP_TBL_SIZE	256
#define EXP_TBL_BPS	16


int main(void) {
  int i, j, index;
  double x;
  double y;
  int ampl;
  int s;
  unsigned int mask;
  unsigned int r;
  unsigned int data[EXP_TBL_SIZE];
  unsigned int delta[EXP_TBL_SIZE];
  unsigned char b[32];
  FILE *outfile;

  /* generate values */
  ampl = (1 << (EXP_TBL_BPS - 1)) - 100;
  mask = (1 << EXP_TBL_BPS) - 1;
  for (i = 0; i <= EXP_TBL_SIZE; i++) {
    x = (1.0 * i) / EXP_TBL_SIZE;
    y = exp(-x * log(2.0));
    s = (int) floor(ampl * y + 0.5);
    r = s & mask;
    if (i < EXP_TBL_SIZE) {
      printf("%3d\t%14e\t%14e\t%10d\t0x%08X\n",
             i, x, y, s, r);
      data[i] = r;
    } else {
      /* the value for i == EXP_TBL_SIZE is not */
      /* stored in the table but remains in r */
    }
  }
  for (i = 0; i < EXP_TBL_SIZE; i++) {
    if (i < EXP_TBL_SIZE - 1) {
      delta[i] = (data[i + 1] - data[i]) & mask;
    } else {
      /* use r to compute ths last slope */
      delta[i] = (r - data[i]) & mask;
    }
    printf("%3d\t0x%04X\t0x%04X\n",
           i, data[i] & mask, delta[i] & mask);
  }
  /* convert data to Verilog "defparam" statements written to a file */
  outfile = fopen(OUTFILE_NAME, "w");
  if (outfile == NULL) {
    printf("Error: cannot open output file '%s'\n", OUTFILE_NAME);
    exit(1);
  }
  for (i = 0; i < 64; i++) {
    fprintf(outfile, "  defparam %s.INIT_%02X = 256'h", INSTANCE_NAME, i);
    for (j = 0; j < 32; j += 2) {
      index = i * 16 + j / 2;
      if (index < 1 * EXP_TBL_SIZE) {
        index = index - 0 * EXP_TBL_SIZE;
        b[j + 0] = data[index] & 0xFF;
        b[j + 1] = data[index] >> 8;
      } else
      if (index < 2 * EXP_TBL_SIZE) {
        index = index - 1 * EXP_TBL_SIZE;
        b[j + 0] = delta[index] & 0xFF;
        b[j + 1] = delta[index] >> 8;
      } else {
        b[j + 0] = 0;
        b[j + 1] = 0;
      }
    }
    for (j = 31; j >= 0; j--) {
      fprintf(outfile, "%02X", b[j]);
    }
    fprintf(outfile, ";\n");
  }
  fclose(outfile);
  /* done */
  return 0;
}
