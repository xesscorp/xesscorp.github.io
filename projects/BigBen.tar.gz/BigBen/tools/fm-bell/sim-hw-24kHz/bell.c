/*
 * bell.c -- bell simulation
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "wrtwav.h"


#define NUM_SEC			15

#define CONTROL_RATE_DIVISOR	256


/**************************************************************/


#define SINE_TBL_SIZE	256
#define SINE_TBL_BPS	16

#define PI		M_PI


short sineValueTable[SINE_TBL_SIZE];
short sineSlopeTable[SINE_TBL_SIZE];


void makeSineTable(void) {
  int i;
  double x;
  double y;
  int ampl;
  int s;
  unsigned int mask;
  unsigned int r;

  ampl = (1 << (SINE_TBL_BPS - 1)) - 100;
  mask = (1 << SINE_TBL_BPS) - 1;
  for (i = 0; i < SINE_TBL_SIZE; i++) {
    x = (2.0 * PI * i) / SINE_TBL_SIZE;
    y = sin(x);
    s = (int) floor(ampl * y + 0.5);
    r = s & mask;
    printf("%3d\t%14e\t%14e\t%10d\t0x%08X\n",
           i, x, y, s, r);
    sineValueTable[i] = r;
  }
  for (i = 0; i < SINE_TBL_SIZE; i++) {
    sineSlopeTable[i] = (sineValueTable[(i + 1) % SINE_TBL_SIZE] -
                         sineValueTable[i]) & mask;
    printf("%3d\t0x%04X\t0x%04X\n",
           i, sineValueTable[i] & mask, sineSlopeTable[i] & mask);
  }
}


short sineLookup(unsigned short phase) {
  int index;
  int fraction;
  short value;
  short slope;
  int corr;

  index = (phase >> 8) & 0xFF;
  fraction = phase & 0xFF;
  value = sineValueTable[index];
  slope = sineSlopeTable[index];
  corr = (fraction * slope) >> 8;
  return value + corr;
}


void checkSineLookupAt(unsigned short phase) {
  int i;

  printf("sine table lookup check\n");
  printf("phase = 0x%04X: value = %d, slope = %d, next value = %d\n",
         phase,
         sineValueTable[phase >> 8],
         sineSlopeTable[phase >> 8],
         sineValueTable[(phase >> 8) + 1]);
  for (i = 0; i <= 256; i++) {
    printf("phase = 0x%04X: value = %d\n", phase, sineLookup(phase));
    phase++;
  }
}


void checkSineLookup(int really) {
  if (really) {
    checkSineLookupAt(3 << 8);
    checkSineLookupAt(61 << 8);
    checkSineLookupAt(67 << 8);
    checkSineLookupAt(125 << 8);
    checkSineLookupAt(131 << 8);
    checkSineLookupAt(189 << 8);
    checkSineLookupAt(195 << 8);
    checkSineLookupAt(253 << 8);
  }
}


/**************************************************************/


#define EXP_TBL_SIZE	256
#define EXP_TBL_BPS	16


short expValueTable[EXP_TBL_SIZE];
short expSlopeTable[EXP_TBL_SIZE];


void makeExpTable(void) {
  int i;
  double x;
  double y;
  int ampl;
  int s;
  unsigned int mask;
  unsigned int r;

  ampl = (1 << (EXP_TBL_BPS - 1)) - 100;
  mask = (1 << EXP_TBL_BPS) - 1;
  for (i = 0; i <= EXP_TBL_SIZE; i++) {
    x = (1.0 * i) / EXP_TBL_SIZE;
    y = exp(-x * log(2.0));
    s = (int) floor(ampl * y + 0.5);
    r = s & mask;
    if (i < EXP_TBL_SIZE) {
      printf("%3d\t%14e\t%14e\t%10d\t0x%08X\n",
             i, x, y, s, r);
      expValueTable[i] = r;
    } else {
      /* the value for i == EXP_TBL_SIZE is not */
      /* stored in the table but remains in r */
    }
  }
  for (i = 0; i < EXP_TBL_SIZE; i++) {
    if (i < EXP_TBL_SIZE - 1) {
      expSlopeTable[i] = (expValueTable[(i + 1)] -
                          expValueTable[i]) & mask;
    } else {
      /* use r to compute the last slope */
      expSlopeTable[i] = (r - expValueTable[i]) & mask;
    }
    printf("%3d\t0x%04X\t0x%04X\n",
           i, expValueTable[i] & mask, expSlopeTable[i] & mask);
  }
}


short expLookup(unsigned short phase) {
  int index;
  int fraction;
  short value;
  short slope;
  int corr;

  index = (phase >> 8) & 0xFF;
  fraction = phase & 0xFF;
  value = expValueTable[index];
  slope = expSlopeTable[index];
  corr = (fraction * slope) >> 8;
  return value + corr;
}


void checkExpLookupAt(unsigned short phase) {
  int i;

  printf("exp table lookup check\n");
  printf("phase = 0x%04X: value = %d, slope = %d, next value = %d\n",
         phase,
         expValueTable[phase >> 8],
         expSlopeTable[phase >> 8],
         expValueTable[(phase >> 8) + 1]);
  for (i = 0; i <= 256; i++) {
    printf("phase = 0x%04X: value = %d\n", phase, expLookup(phase));
    phase++;
  }
}


void checkExpLookup(int really) {
  if (really) {
    checkExpLookupAt(0 << 8);
    checkExpLookupAt(64 << 8);
    checkExpLookupAt(128 << 8);
    checkExpLookupAt(254 << 8);
  }
}


/**************************************************************/


unsigned short modulatorOscDelta = 0;
unsigned short modulatorEnvDelta = 0;
unsigned short carrierOscDelta = 0;
unsigned short carrierEnvDelta = 0;

unsigned short modulatorOscPhase = 0;
unsigned short modulatorEnvPhase = 0;
unsigned short carrierOscPhase = 0;
unsigned short carrierEnvPhase = 0;


int controlRateCounter = 0;


short nextSample(void) {
  short modulatorOscSample;
  short modulatorEnvSample;
  short modulatorEnvShift;
  short modulation;
  short carrierOscSample;
  short carrierEnvSample;
  short carrierEnvShift;
  short sample;

  if (++controlRateCounter == CONTROL_RATE_DIVISOR) {
    controlRateCounter = 0;
  }

  modulatorOscSample = sineLookup(modulatorOscPhase);
  modulatorOscPhase += modulatorOscDelta;

  modulatorEnvSample = expLookup((modulatorEnvPhase & 0x0FFF) << 4);
  modulatorEnvShift = (modulatorEnvPhase >> 12) & 0x0F;
  if (controlRateCounter == 0) {
    modulatorEnvPhase += modulatorEnvDelta;
  }

  modulation = ((int) modulatorOscSample * (int) modulatorEnvSample) >>
               (15 + modulatorEnvShift);

  carrierOscSample = sineLookup(carrierOscPhase + 3 * modulation);
  carrierOscPhase += carrierOscDelta;

  carrierEnvSample = expLookup((carrierEnvPhase & 0x0FFF) << 4);
  carrierEnvShift = (carrierEnvPhase >> 12) & 0x0F;
  if (controlRateCounter == 0) {
    carrierEnvPhase += carrierEnvDelta;
  }

  sample = ((int) carrierOscSample * (int) carrierEnvSample) >>
           (15 + carrierEnvShift);

  return sample;
}


/**************************************************************/


int main(void) {
  int i;
  short sample;

  /* make tables and check lookup */
  makeSineTable();
  checkSineLookup(0);
  makeExpTable();
  checkExpLookup(0);
  /* set sound parameters */
  modulatorOscDelta = 921;
  modulatorEnvDelta = 29;
  carrierOscDelta = 658;
  carrierEnvDelta = 38;
  /* generate samples */
  for (i = 0; i < NUM_SEC * SAMPLE_RATE; i++) {
    sample = nextSample() / 4;
    writeSample(sample, sample);
  }
  /* write output file */
  writeWav("test.wav");
  return 0;
}
