/*
 * common.h -- common definitions, error handling
 */


#ifndef _COMMON_H_
#define _COMMON_H_


typedef int Bool;

#define FALSE			0
#define TRUE			1


typedef unsigned char Byte;
typedef unsigned short Word;
typedef unsigned int Dword;


void error(char *fmt, ...);


#endif /* _COMMON_H_ */
