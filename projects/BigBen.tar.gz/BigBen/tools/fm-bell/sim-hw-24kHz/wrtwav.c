/*
 * wrtwav.c -- write the .wav file
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "wrtwav.h"


/**************************************************************/


static Sample *data = NULL;
static int dataSize = 0;	/* in samples */
static int numSamples = 0;	/* number of samples written */


void writeSample(Sample leftChannel, Sample rightChannel) {
  Sample *newData;
  int newDataSize;

  if (numSamples + 2 > dataSize) {
    /* buffer is full */
    if (dataSize == 0) {
      /* first allocation */
      newDataSize = 1024;
    } else {
      /* subsequent allocation */
      newDataSize = 2 * dataSize;
    }
    newData = malloc(newDataSize * sizeof(Sample));
    if (newData == NULL) {
      error("cannot allocate sample buffer");
    }
    if (data != NULL) {
      memcpy(newData, data, numSamples * sizeof(Sample));
      free(data);
    }
    data = newData;
    dataSize = newDataSize;
  }
  data[numSamples++] = leftChannel;
  data[numSamples++] = rightChannel;
}


/**************************************************************/


static void writeByte(char val, FILE *file) {
  unsigned char byte;

  byte = val & 0xFF;
  fwrite(&byte, 1, 1, file);
}


static void writeShort(short val, FILE *file) {
  unsigned char byte;

  byte = val & 0xFF;
  fwrite(&byte, 1, 1, file);
  byte = (val >> 8) & 0xFF;
  fwrite(&byte, 1, 1, file);
}


static void writeInt(int val, FILE *file) {
  unsigned char byte;

  byte = val & 0xFF;
  fwrite(&byte, 1, 1, file);
  byte = (val >> 8) & 0xFF;
  fwrite(&byte, 1, 1, file);
  byte = (val >> 16) & 0xFF;
  fwrite(&byte, 1, 1, file);
  byte = (val >> 24) & 0xFF;
  fwrite(&byte, 1, 1, file);
}


void writeWav(char *wavName) {
  FILE *wavFile;
  int subchunk1size;
  int subchunk2size;
  int chunksize;
  short audioFormat;
  short numChannels;
  int sampleRate;
  int byteRate;
  short blockAlign;
  short bitsPerSample;
  int i;

  /* open output file */
  wavFile = fopen(wavName, "w");
  if (wavFile == NULL) {
    error("cannot open output file '%s'", wavName);
  }
  /* compute parameters */
  subchunk1size = 16;  /* always 16 for PCM */
  subchunk2size = numSamples * sizeof(Sample);
  chunksize = 4 + (8 + subchunk1size) + (8 + subchunk2size);
  audioFormat = 1;  /* PCM */
  numChannels = NUM_CHANNELS;
  sampleRate = SAMPLE_RATE;
  byteRate = BYTE_RATE;
  blockAlign = BLOCK_ALIGN;
  bitsPerSample = BITS_PER_SAMPLE;
  /* write RIFF header */
  writeByte('R', wavFile);
  writeByte('I', wavFile);
  writeByte('F', wavFile);
  writeByte('F', wavFile);
  writeInt(chunksize, wavFile);
  writeByte('W', wavFile);
  writeByte('A', wavFile);
  writeByte('V', wavFile);
  writeByte('E', wavFile);
  /* write fmt subchunk */
  writeByte('f', wavFile);
  writeByte('m', wavFile);
  writeByte('t', wavFile);
  writeByte(' ', wavFile);
  writeInt(subchunk1size, wavFile);
  writeShort(audioFormat, wavFile);
  writeShort(numChannels, wavFile);
  writeInt(sampleRate, wavFile);
  writeInt(byteRate, wavFile);
  writeShort(blockAlign, wavFile);
  writeShort(bitsPerSample, wavFile);
  /* write data subchunk */
  writeByte('d', wavFile);
  writeByte('a', wavFile);
  writeByte('t', wavFile);
  writeByte('a', wavFile);
  writeInt(subchunk2size, wavFile);
  for (i = 0; i < numSamples; i++) {
    writeShort(data[i], wavFile);
  }
  /* close output file */
  fclose(wavFile);
}
