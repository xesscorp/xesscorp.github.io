/*
 * wrtwav.h -- write the .wav file
 */


#ifndef _WRTWAV_H_
#define _WRTWAV_H_


#define CLK			100000000	/* clock rate */
#define DIV			4096		/* clock divisor */
#define SAMPLE_RATE		(CLK / DIV)	/* in samples/sec */
#define NUM_CHANNELS		2		/* stereo */
#define BYTES_PER_SAMPLE	2		/* 16 bit resolution */

#define BYTE_RATE	(SAMPLE_RATE * NUM_CHANNELS * BYTES_PER_SAMPLE)
#define BLOCK_ALIGN	(NUM_CHANNELS * BYTES_PER_SAMPLE)
#define BITS_PER_SAMPLE	(BYTES_PER_SAMPLE * 8)


typedef short Sample;


void writeSample(Sample leftChannel, Sample rightChannel);
void writeWav(char *wavName);


#endif /* _WRTWAV_H_ */
