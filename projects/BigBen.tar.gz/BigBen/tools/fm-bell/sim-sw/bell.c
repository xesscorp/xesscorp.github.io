/*
 * bell.c -- bell simulation
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "wrtwav.h"


#define NUM_SEC		15
#define PI		M_PI


int main(void) {
  double f0;
  int n, m;
  double a, alpha;
  double b, beta;
  double t;
  double modAmpl;
  double modulator;
  double carrAmpl;
  double carrier;
  short sample;
  int i;

  f0 = 49.0;
  n = 5;
  m = 7;
  a = 8000.0;
  alpha = 0.6140;
  b = 10.0;
  beta = 0.4605;
  for (i = 0; i < NUM_SEC * SAMPLE_RATE; i++) {
    t = i * (1.0 / SAMPLE_RATE);
    modAmpl = b * exp(-beta * t);
    modulator = modAmpl * sin(2.0 * PI * m * f0 * t);
    carrAmpl = a * exp(-alpha * t);
    carrier = carrAmpl * sin(2.0 * PI * n * f0 * t + modulator);
    sample = floor(carrier + 0.5);
    writeSample(sample, sample);
  }
  writeWav("test.wav");
  return 0;
}
