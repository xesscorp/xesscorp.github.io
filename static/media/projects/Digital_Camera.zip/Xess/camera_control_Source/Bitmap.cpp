/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	Bitmap.cpp
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

****************************************************************/

#include "Bitmap.h"


// Create a big block of memory for the bitmap and then
// assign pointers to the correct spots within it

Bitmap::Bitmap(LONG width, LONG Height)
{
	nSize = sizeof(BITMAPFILEHEADER) +
						sizeof(BITMAPINFOHEADER) +
						width * Height * sizeof(DWORD);

	lpBitmap = (LPBYTE) LocalAlloc(LPTR, nSize);
	phdr = (PBITMAPFILEHEADER) lpBitmap;
	pbih = (PBITMAPINFOHEADER) (lpBitmap + sizeof(BITMAPFILEHEADER));
	lpPixels = (LPDWORD) (lpBitmap + sizeof(BITMAPFILEHEADER) +
		sizeof(BITMAPINFOHEADER)); 

}

Bitmap::~Bitmap()
{
	if (lpBitmap != NULL) GlobalFree((HGLOBAL)lpBitmap);
}
