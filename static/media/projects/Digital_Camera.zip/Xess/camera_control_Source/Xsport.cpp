/*
 * This software is in the public domain.
 * You may use it as you see fit with the understanding that
 * we make no guarantees of its fitness for any particular purpose.
 /*

Notes:

  Look in file's XSABoard.cpp & .h

// inversion mask for parallel port connection to XSA Board
// 00000011: bits  7- 0 are attached to data pins D7-D0
// 00000xxx: bits 15-11 are attached to status pins /S7,S6,S5,S4,S3
// xxxx1001: bits 19-16 are attached to control pins /C3,C2,/C1,/C0
const unsigned int invMask = 0x090003;

  to do:
	write data read to file  --get file name from command line


*/

#include <process.h>
#include <windows.h>
#include <stdlib.h>
#include <assert.h>
#include <strstrea.h>
#include <fstream.h>
#include <string>
using std::string;

#include "XSError.h"
#include "PPort.h"
#include "Utils.h"

#define NOP 0
#define START_UPLOAD 1
#define COLORDEPTH 32


// version info
string version("$Name: V4_0_0 $");

// global variables
string lpt;			// parallel port identifier
int portNum = -1;	// parallel port number

XSError errMsg(cerr); // setup error channel
bool writeControlBits = false; // true if bitstring is destined for control bits


// BMP file stuff should really be move somewhere else.
void CreateBitMapFile(LPTSTR pszFile, LPDWORD lpRawImage, LONG lWidth,
						LONG lHeight)
{

	HANDLE hf;                  // file handle 
    BITMAPFILEHEADER hdr;       // bitmap file-header 
    PBITMAPINFOHEADER pbih;     // bitmap info-header 
    DWORD cb;                   // incremental count of bytes 
    DWORD dwTmp; 

  
	//Create the info header
	pbih = (PBITMAPINFOHEADER) LocalAlloc(LPTR, sizeof(BITMAPINFOHEADER)); 
	pbih->biSize = sizeof(BITMAPINFOHEADER); 
    pbih->biWidth = lWidth;
    pbih->biHeight = lHeight; 
    pbih->biPlanes = 1; 
    pbih->biBitCount = COLORDEPTH; 
	
    // If the bitmap is not compressed, set the BI_RGB flag. 
    pbih->biCompression = BI_RGB; 
	pbih->biXPelsPerMeter = 96;  //From what paint writes
	pbih->biYPelsPerMeter = 96;

    // Compute the number of bytes in the array of color 
    // indices and store the result in biSizeImage. 
    // For Windows NT, the width must be DWORD aligned unless 
    // the bitmap is RLE compressed. This example shows this. 
    // For Windows 95/98/Me, the width must be WORD aligned unless the 
    // bitmap is RLE compressed.
    pbih->biSizeImage = pbih->biWidth * pbih->biHeight; 
    
	// Set biClrImportant to 0, indicating that all of the 
    // device colors are important. 
    pbih->biClrImportant = 0; 
 
	
	// Create the .BMP file. 
    hf = CreateFile(pszFile, 
                   GENERIC_READ | GENERIC_WRITE, 
                   (DWORD) 0, 
                    NULL, 
                   CREATE_ALWAYS, 
                   FILE_ATTRIBUTE_NORMAL, 
                   (HANDLE) NULL); 
    
	//if (hf == INVALID_HANDLE_VALUE)
    //    errhandler("CreateFile", hwnd); 
    
	hdr.bfType = 0x4d42;        // 0x42 = "B" 0x4d = "M" 
    // Compute the size of the entire file. 
    hdr.bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
                 pbih->biSize + pbih->biSizeImage); 
    
	hdr.bfReserved1 = 0; 
    hdr.bfReserved2 = 0; 

    // Compute the offset to the array of color indices. 
    hdr.bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + 
                    pbih->biSize;


	

    // Copy the BITMAPFILEHEADER into the .BMP file. 
    WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER), 
        (LPDWORD) &dwTmp,  NULL); 

    // Copy the BITMAPINFOHEADER and RGBQUAD array into the file. 
    WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFOHEADER), 
                  (LPDWORD) &dwTmp, ( NULL)); 

    // Copy the array of color indices into the .BMP file. 
    cb = pbih->biSizeImage * sizeof(lpRawImage); 
	//shp = (BYTE*)lpBits;
   
	if (!WriteFile(hf, (LPVOID) lpRawImage, (int) cb, (LPDWORD) &dwTmp,NULL)) 
		cout << "Sucker " << dwTmp << endl;



    // Close the .BMP file and free memory
    CloseHandle(hf); 
	GlobalFree((HGLOBAL)pbih);

}


int ShowMenu( void )
{
	int returnval;

	cout << "\n1. Upload from board to file"
		 << "\n2. Send Command to board"
		 << "\n0. Exit"
		 << "\n\nSelect Item: ";
	cin >> returnval;
	return returnval;

}

//Gee overload is fun
void SendCommand( PPort &port)
{
	unsigned cmdToSend=0xC;
	cout << "\nCommand to send in dec:";			//there's a hex function somewhere
	cin >> cmdToSend;
	
	cmdToSend = cmdToSend << 1;  //lsb is shifted in as a 0 6 bits that we want. 1 clk bit
	port.Out(cmdToSend,0,6);							//lower 6 bits
	port.Out((cmdToSend|1),0,6);		//upper 6 bits   Magic numbers!

	cout << "\nCommand sent\n";
}




//toggle lsb of ppd port.  shift right msb's. mask off all but 6 bits that we want.  
void SendCommand( PPort &port, unsigned cmdToSend )
{
	//unsigned int cmdToSend=0xC;
	//cout << "\nCommand to send in dec:";			//there's a hex function somewhere
	//cin >> cmdToSend;
	
	cmdToSend = cmdToSend << 1;  //lsb is shifted in as a 0 6 bits that we want. 1 clk bit
	port.Out(cmdToSend,0,6);							//lower 6 bits  ppd0 = 0
	port.Out((cmdToSend|1),0,6);		//upper 6 bits   Magic numbers! ppd0 = 1
}


void UploadToFile( PPort &port )
{
	LPBYTE	lpRawImage;              // memory pointer 
    LPDWORD lpFormattedImage;
	LONG	lWidth; 
    LONG	lHeight; 
	DWORD	lSize;
	BYTE	bByte;
	unsigned short int usiPixel;

	//Open file to write pp data to
	fstream fout;
	char data_low=0;
	char data_high=0;
	unsigned int readLength;
	unsigned int startAddress=0x00;	//Shift startAddress around to get 6 bits at at time.. but later
	unsigned int endAddress=1280*1024-1;	//Just a random length

	lWidth = 1280;
	lHeight = 1024;
	lSize = lWidth * lHeight;
	
	if (endAddress < startAddress)
	{
		cout << "\nEnd address less then start address!\n";
		return;
	}
	
	//Calculate number of bytes to read
	readLength = (endAddress - startAddress);
	
	//But the end and start address sent to the board must me in terms of words
	endAddress = endAddress / 2;



	//Make memory buffer to copy to file
	lpRawImage = (LPBYTE) GlobalAlloc(GMEM_FIXED, readLength * sizeof(BYTE));
	lpFormattedImage = (LPDWORD) GlobalAlloc(GMEM_FIXED, lSize * sizeof(DWORD));

	fout.open("data_out.bin", ios::out);
	fout.setmode( filebuf::binary );		//Open it as type binary or else you'll get carriage returns
	
	//Send commands to the board to start an upload
	

	SendCommand(port, NOP);		//Send NOP before sending upload command
		
	SendCommand(port, START_UPLOAD);		//Start Upload
	
	SendCommand(port, startAddress);		//Start Address lsb
	SendCommand(port, startAddress>>=6);	// A = A >> 6;
	SendCommand(port, startAddress>>=6);
	SendCommand(port, startAddress>>=6);		//lsb

	SendCommand(port, endAddress);		//End Address  lsb
	SendCommand(port, endAddress>>=6);
	SendCommand(port, endAddress>>=6);
	SendCommand(port, endAddress>>=6);		//lsb

	
	for(unsigned int i=0; i<1000; i++);  // let the chips fifo fill
	SendCommand(port, NOP);
	SendCommand(port, NOP);

	//read length in number of bytes to read
	for(i=0; i<=(readLength); i++)
	{
		//I should be able to stream line this alot
		
		port.Out(0,0,0);
		data_low = 0;									//Clear the byte
		data_low = (char) (port.In(11,14));				//fill lower nibble
		
		port.Out(1,0,0);
		data_high = (char) ((port.In(11,14) << 4));		//fill lower nibble, shift it to high nibble. 0's shifted into low
		data_low = data_low | data_high;					//Combine them
		fout.write(&data_low , 1);							//write whole byte out to file

		//Just shove the image raw into a buffer
		lpRawImage[i] = (BYTE)data_low;			
	}
	

	//Make another buffer to hold the bmp formatted image.

	for(i=0; i<lSize-1; i++)
	{
		lpFormattedImage[i] = RGB(lpRawImage[i], lpRawImage[i], lpRawImage[i]);
	}
	

	CreateBitMapFile("bitmap.bmp", lpFormattedImage, lWidth, lHeight);
	GlobalFree((HGLOBAL)lpRawImage);
	GlobalFree((HGLOBAL)lpFormattedImage);

		
	cout << "\nfile saved\n";
	fout.close();
}

/*
int main( int argc, char **argv )
{
	XSError err(cerr); // setup error channel
	portNum = 1;
	lpt = "LPT1";
	
	// store the parallel port that will be used
	SetXSTOOLSParameter((string)"LPT",lpt);

	// create the parallel port object
	PPort port;
	if(port.Setup(&errMsg,portNum,0x3) == false)
	{
		err.SimpleMsg(XSErrorMajor,(string)"Invalid parallel port was selected!\n");
		return 1;
	}
	
	// exit without changing the parallel port if there was an error
	if(errMsg.IsError())
		return 1;


	int menuChoice;
	while(1)
	{
		menuChoice = ShowMenu();

		switch(menuChoice)
		{
		case 1:
			UploadToFile(port);	
			break;
		case 2:
			SendCommand(port);
			break;
		case 0:
			cout << endl;						//break while 1 loop and exit program
			return 0;
		}
	} 


}
*/