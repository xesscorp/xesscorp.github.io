/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	Bitmap.h
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

****************************************************************/

#ifndef myBITMAP
#define myBITMAP

#include <windows.h>


#define COLORDEPTH 32


class Bitmap
{

public:
	Bitmap(LONG, LONG);
	~Bitmap( void );


//private:

    LPBYTE	lpBitmap;
	PBITMAPFILEHEADER phdr;       // bitmap file-header 
    PBITMAPINFOHEADER pbih;     // bitmap info-header 
    LPDWORD lpPixels;		//Picture Data
	UINT	nSize;

};

#endif


