/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	hardware_interface.cpp
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

****************************************************************/



#include "hardware_interface.h"


/*******************************************************************

	Constructor
	Open port, set default addresses
	Alloc memory for raw buffer
	setup events

*******************************************************************/
hardware_interface::hardware_interface( void )
{
	//Setup Port
	lpt = "LPT1";			// parallel port identifier
	portNum = 1;			// parallel port number
	writeControlBits = false;
	errMsg = new XSError(cerr); // setup error channel
	port = new PPort;

	port->Setup(errMsg,portNum,0x3);  // Error Handling?

	//Setup Camera variables .. 
	startAddress = STARTADDRESS;	
	endAddress = ENDADDRESS;
	lpRawImage = (LPBYTE) GlobalAlloc(GMEM_FIXED, 
		endAddress - startAddress * sizeof(BYTE));	


	//Create an event. Don't reset on waitforsinbleobject's return, 
	//And start with the event set
	hEventGoStop = CreateEvent(NULL, TRUE, TRUE, NULL);
	hEventThreadDead = CreateEvent(NULL, TRUE, FALSE, NULL);
	bEndThread = FALSE;
}

/*******************************************************************

	Destructor
	Delete Memory only if not NULL

*******************************************************************/
hardware_interface::~hardware_interface( void )
{
	if (errMsg != NULL) delete errMsg;
	if (port != NULL) delete port;
	if (lpRawImage != NULL) GlobalFree((HGLOBAL)lpRawImage);

}

/*******************************************************************

  Return Handles to events

*******************************************************************/
HANDLE hardware_interface::GethEventGoStop( void )
{	return hEventGoStop;	}

HANDLE hardware_interface::GethEventThreadDead( void )
{	return hEventThreadDead;	}


/*******************************************************************

  Sets bool to end thread. ... is checked in downloadimage
  Sets flag so thread can run to check the flag if it is suspended

*******************************************************************/
void hardware_interface::EndThread( void )
{
	SetEvent(hEventGoStop);
	bEndThread = TRUE;	
}

/*******************************************************************

  Confirm the port opened

*******************************************************************/
bool hardware_interface::OpenedOK( void )
{
	if(errMsg->IsError())
		return false;
	else
		return true;
}


/*******************************************************************

  Helper for downloadimage
  Sets port bits, then toggles clock bit

  lsb is shifted in as a 0. 
  Send 6 bits that we want + 1 clk bit that we toggle
  
  mask off all but 6 bits that we want.  

*******************************************************************/
void hardware_interface::SendCommand( UINT cmdToSend)
{
	cmdToSend = cmdToSend << 1;  
	port->Out(cmdToSend,0,6);	
	port->Out((cmdToSend|1),0,6);
}


/*******************************************************************
	
	Most of the thread's time is spent here.  Command to
	start upload is sent, followed by 24bit start and end
	addresses.  Then that range of data is read from the
	camera.

	Setup to write debugging info to file data_out.bin
	See camera documentation for more details on what's
	being sent, recieved here.

	Only update status bar, check for bEndThread every 32k.

*******************************************************************/
void hardware_interface::DownloadImage(HWND hwnd)
{
	char data_low=0;	// or BYTE?
	char data_high=0;
	//Shift em, but save their values	
	UINT tmpStartAddress = startAddress;	
	UINT tmpEndAddress = endAddress /2;    //in terms of words
	UINT readLen;
	UINT i;

	//Open it as type binary or else you'll get carriage returns
	fstream fout;
	fout.open("data_out.bin", ios::out);
	fout.setmode( filebuf::binary );		

	//Send commands to the board to start an upload
	SendCommand(NOP); 	//Send NOP before sending upload command
		
	SendCommand(START_UPLOAD);		//Start Upload
	
	SendCommand(tmpStartAddress);		//Start Address lsb
	SendCommand(tmpStartAddress>>=6);	// A = A >> 6;
	SendCommand(tmpStartAddress>>=6);
	SendCommand(tmpStartAddress>>=6);		//lsb

	SendCommand(tmpEndAddress);		//End Address  lsb
	SendCommand(tmpEndAddress>>=6);
	SendCommand(tmpEndAddress>>=6);
	SendCommand(tmpEndAddress>>=6);		//lsb

	
	//for(UINT i=0; i<1000; i++);  // let the fifos fill  need something better here
	SendCommand(NOP);
	SendCommand(NOP);

	/*
	This loop takes about 10s cause of the slow pport
	Use it to update percent complete
	read length in number of bytes to read
	*/
	readLen = (endAddress - startAddress);
	fpctcmplt = 0;
	for(i=0; i<=readLen; i++)
	{
		port->Out(0,0,0);
		data_low = 0;							//Clear the byte
		data_low = (char) (port->In(11,14));	//fill lower nibble
		
		//fill lower nibble, shift it to high nibble. 
		//0's shifted into low
		port->Out(1,0,0);
		data_high = (char) ((port->In(11,14) << 4));		
		data_low = data_low | data_high;		//Combine them

		//Just shove the image raw into the buffer
		lpRawImage[i] = (BYTE)data_low;		
		//fout.write(&data_low , 1);	//debug file		

		//Power of 2.  Bigger number = slower update rate
		if (!(i%(32768)))		
		{
			fpctcmplt = (float)i / (float)readLen;
			WaitForSingleObject(hEventGoStop, INFINITE);
			
			if(bEndThread)
			{
				SetEvent(hEventThreadDead);				
				_endthread();
			}
	
			SendMessage(hwnd, WM_DOWNLOAD_STATUS, 
				(WPARAM)&fpctcmplt, 0);
		}
	}
	fout.close();
}

/*	**************************************************

  Copies the raw hardware input buffer to location pointed
  to by lpTmp
	
*******************************************************/
bool hardware_interface::GetRawBuffCpy( LPBYTE lpDest )
{
	CopyMemory( lpDest, lpRawImage,  
		endAddress - startAddress * sizeof(BYTE));
	return true;
}
