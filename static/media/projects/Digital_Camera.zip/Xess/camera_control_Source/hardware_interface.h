/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	hardware_interface.h
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

****************************************************************/

#ifndef HARDWAREINTERFACE
#define HARDWAREINTERFACE

#include <string.h>
#include <fstream.h>
#include <process.h>
#include "XSError.h"
#include "PPort.h"
#include "Utils.h"  
#include "resource.h"


#define STARTADDRESS 0
#define ENDADDRESS (1280*1024-1)
#define NOP 0
#define START_UPLOAD 1

#define WM_DOWNLOAD_STATUS WM_USER+1

class hardware_interface
{

public:
	hardware_interface( void );
	~hardware_interface( void );
	bool OpenedOK( void );
	void DownloadImage( HWND );
	bool GetRawBuffCpy( LPBYTE );
	HANDLE GethEventGoStop( void );
	HANDLE GethEventThreadDead( void );
	void EndThread(void);

private:
	//Parallel Port vars
	string lpt;
	int portNum;
	bool writeControlBits; 
	XSError* errMsg;
	PPort* port;
	
	//Camera data reader vars
	LPBYTE	lpRawImage;            
	UINT startAddress;	
	UINT endAddress;
	float fpctcmplt;
	HANDLE hEventGoStop, hEventThreadDead;
	bool bEndThread;
	


	void SendCommand( UINT );

};

#endif
