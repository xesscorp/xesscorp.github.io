/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	image_manip.cpp
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

****************************************************************/

#include "image_manip.h"


image_manip::image_manip( void )
{	
	lWidth = IMAGE_WIDTH;
	lHeight = IMAGE_HEIGHT;
	lSize = IMAGE_WIDTH * IMAGE_HEIGHT; //-1
	
	lpRawImage = (LPBYTE) GlobalAlloc(GMEM_FIXED, 
		lSize * sizeof(BYTE));	
	ptrBMP = new Bitmap(lWidth, lHeight);
	
}

//Don't leak 10mb on close
image_manip::~image_manip( void )
{
	if (lpRawImage != NULL) GlobalFree((HGLOBAL)lpRawImage);
	if (ptrBMP != NULL) GlobalFree((HGLOBAL)ptrBMP);
}

LPBYTE image_manip::GetlpRawImage()
{
	return lpRawImage;
}

/*******************************************************************

	Converts raw buffer to a bitmap buffer, adjusting the color as 
	it goes.  Then it calls createbitmap to append bitmap header
	data to create a complete bitmap file in memory
	
	  Newcolor = oldcolor * (adj / 127) where adj is range 0 to 255

*******************************************************************/
void image_manip::RawtoBMP( void )
{

	RGBQUAD rgbqTmp;

	//Update new color adjust
	//Above 127 add ... below sub but now exceeding 0 or 255
	rgbqCACur = rgbqCANext;

	// Translate the raw data to bmp data
	// for Grayscale sensor
	for(UINT i=0; i<lSize-1; i++)
	{
	
		rgbqTmp.rgbRed = (BYTE)min(255, ((float)lpRawImage[i] * 
			((float)rgbqCACur.rgbRed / 127)));
		rgbqTmp.rgbGreen = (BYTE)min(255, ((float)lpRawImage[i] * 
			((float)rgbqCACur.rgbGreen / 127)));
		rgbqTmp.rgbBlue = (BYTE)min(255, ((float)lpRawImage[i] * 
			((float)rgbqCACur.rgbBlue / 127)));

	
		ptrBMP->lpPixels[i] = RGB(rgbqTmp.rgbBlue, rgbqTmp.rgbGreen, 
			rgbqTmp.rgbRed);
	}

	// fill the FormattedImage buffer with the bmp
	CreateBitMap();
	
}

/*******************************************************************

	Append info header and file header to top of bitmap buffer to
	create a complete bitmap in memory

*******************************************************************/
void image_manip::CreateBitMap()
{

  
	//Create the info header
	ptrBMP->pbih->biSize = sizeof(BITMAPINFOHEADER); 
    ptrBMP->pbih->biWidth = lWidth;
    ptrBMP->pbih->biHeight = lHeight; 
    ptrBMP->pbih->biPlanes = 1; 
    ptrBMP->pbih->biBitCount = COLORDEPTH; 
	
    // If the bitmap is not compressed, set the BI_RGB flag. 
    ptrBMP->pbih->biCompression = BI_RGB; 
	ptrBMP->pbih->biXPelsPerMeter = 96;  //From what paint writes
	ptrBMP->pbih->biYPelsPerMeter = 96;

    // Compute the number of bytes in the array of color 
    // indices and store the result in biSizeImage. 
    // For Windows NT, the width must be DWORD aligned unless 
    // the bitmap is RLE compressed. This example shows this. 
    // For Windows 95/98/Me, the width must be WORD aligned unless the 
    // bitmap is RLE compressed.
    ptrBMP->pbih->biSizeImage = 
		ptrBMP->pbih->biWidth * ptrBMP->pbih->biHeight; 
    
	// Set biClrImportant to 0, indicating that all of the 
    // device colors are important. 
    ptrBMP->pbih->biClrImportant = 0; 
 
	ptrBMP->phdr->bfType = 0x4d42;        // 0x42 = "B" 0x4d = "M" 
    
	// Compute the size of the entire file. 
    ptrBMP->phdr->bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
                 ptrBMP->pbih->biSize + ptrBMP->pbih->biSizeImage); 
    
	ptrBMP->phdr->bfReserved1 = 0; 
    ptrBMP->phdr->bfReserved2 = 0; 

    // Compute the offset to the array of color indices. 
    ptrBMP->phdr->bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + 
                    ptrBMP->pbih->biSize;


}


/*******************************************************************

	Write bitmap out to file

*******************************************************************/
void image_manip::WriteBMPFile(char* pszFile)
{
	HANDLE hf;                  // file handle 
	DWORD dwTmp;				// unused bytes written

	// Create the .BMP file. 
    hf = CreateFile(pszFile, 
                   GENERIC_READ | GENERIC_WRITE, 
                   (DWORD) 0, 
                    NULL, 
                   CREATE_ALWAYS, 
                   FILE_ATTRIBUTE_NORMAL, 
                   (HANDLE) NULL); 
    
	WriteFile(hf, (LPVOID) ptrBMP->lpBitmap, (int) ptrBMP->nSize, 
		(LPDWORD) &dwTmp,NULL);		
    CloseHandle(hf); 

}

Bitmap* image_manip::GetBitmap( void )
{
	
	return ptrBMP;
}

void 	image_manip::SetColorAdj(RGBQUAD rgbqNewAdj)
{
	rgbqCANext = rgbqNewAdj;
}
