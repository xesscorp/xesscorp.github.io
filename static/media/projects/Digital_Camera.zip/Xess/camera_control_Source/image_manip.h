/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	Image_manip.h
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

****************************************************************/


#ifndef IMAGEMANIP
#define IMAGEMANIP

#include <fstream.h>
#include <windows.h>
#include "Bitmap.h"


#define IMAGE_WIDTH 1280
#define IMAGE_HEIGHT 1024

class image_manip
{

public:
	image_manip( void );
	~image_manip( void );
	void RawtoBMP(void);
	LPBYTE GetlpRawImage();
	void CreateBitMap();
	void WriteBMPFile(char*);
	Bitmap* GetBitmap( void );
	void 	SetColorAdj(RGBQUAD);


private:

	LPBYTE	lpRawImage;            
	LONG	lWidth; 
    LONG	lHeight; 
	DWORD	lSize;
	Bitmap*	ptrBMP;
	RGBQUAD	rgbqCANext, rgbqCACur;

};

#endif
