/****************************************************************
  
	CST 238 GUI Project.
	Windows interface to digital camera senior project.
		
    Filename:  	mystructs.h
	Compiler:	MSVC 6.0
	Author:		Ryan Henderson

  
	mystructs.h    
	Just a header file to define some commonly used structures.

****************************************************************/


#ifndef MYSTRUCTS
#define MYSTRUCTS



typedef struct
{
	HWND				hwnd;
	hardware_interface* hi;
	image_manip*		im;
}
PARAMS, *PPARAMS;


typedef struct
{
	RGBQUAD rgbqAdj;
}
CAMCTR_DATA;

#endif
