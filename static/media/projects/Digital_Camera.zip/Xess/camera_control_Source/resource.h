//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       103
#define ID_STATUS_BAR                   104
#define IDD_DIALOG1                     105
#define IDD_ABOUT                       107
#define IDI_ICON1                       108
#define IDC_SLIDERRED                   1000
#define IDC_SLIDERGREEN                 1001
#define IDC_SLIDERBLUE                  1003
#define IDC_PROGRESS1                   1005
#define IDC_STATIC_REDVAL               1008
#define IDC_STATIC_GREENVAL             1009
#define IDC_STATIC_BLUEVAL              1010
#define ID_FILE_EXIT                    40001
#define ID_CONTROL_GO                   40003
#define ID_CONTROL_STOP                 40004
#define ID_ADJUST_COLORBALANCE          40005
#define ID_ABOUT_ABOUTCAMERACONTROL     40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
