
#include "string_buffer.h"

string_buffer::string_buffer( void )
{
	index = 0;
	buffer[0] = 0;
}

void string_buffer::Add( char c )
{
	int i;

	if (index > BUFFERMAX-1)
	{
		//Scroll the buffer down
		for(i=0; i<BUFFERMAX-1; i++)
		{
			buffer[i] = buffer[i+1];		
		}
		buffer[i] = c;

	}
	else
	{
		//Just fill the buffer
		buffer[index++] = c;
		buffer[index] = 0;
	}

}

char* string_buffer::GetBuffer( void )
{
	return buffer;

}

int string_buffer::GetLength( void )
{
	return strlen(buffer);
}

void string_buffer::EmptyBuffer( void )
{
	index = 0;
	buffer[0] = 0;
}