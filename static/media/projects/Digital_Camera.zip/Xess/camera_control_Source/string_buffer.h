
#include <string.h>

#ifndef STRINGBUFFER
#define STRINGBUFFER

#define BUFFERMAX 51

class string_buffer
{

public:
	string_buffer( void );
	void Add( char );
	char* GetBuffer( void );
	int GetLength( void );
	void EmptyBuffer( void );

private:
	char buffer[BUFFERMAX];
	int index;

};

#endif