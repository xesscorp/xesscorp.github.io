(c) ALSE - http://www.alse-fr.com/English

This is a complete project for the Xess XC40-010XL board :
 * LED display is active high.
   Only the Least Significant Digit is displayed.
 * Reset is on the // Port
 * The keyboard is connected to the PS/2 connector

The bitfile is ready to use for XS40-010XL boards.

To make changes :
 - Synthesize with FPGA Express or Leonardo Spectrum or Synplicity
   There is a script for Leonardo and another (project file) for Synplify.
 - Place and Route the Edif file with Ise Classics (4.2)

----------------------------------------
# UCF file for Xess XS40-010XL
#
NET Clk         LOC=P13; # CLOCK FROM EXTERNAL OSCILLATOR
#
# LED DRIVER OUTPUTS
NET D7SEG_L(1)  LOC=P19; # a
NET D7SEG_L(2)  LOC=P23; # b
NET D7SEG_L(3)  LOC=P26; # c
NET D7SEG_L(4)  LOC=P25; # d
NET D7SEG_L(5)  LOC=P24; # e
NET D7SEG_L(6)  LOC=P18; # f
NET D7SEG_L(7)  LOC=P20; # g
#
NET nLEDP LOC=P70; # Parallel Port status S3
#
# PS/2 Keyboard Connector
NET PS2_Clk  LOC=P68;
NET PS2_Data LOC=P69;

#
# DATA BITS FROM THE PC PARALLEL PORT
NET Reset    LOC=P46; # We use PC_D2 as Reset

# Other signals to preserve and set to '1'

NET RST   LOC=P36; # uC ACTIVE-HIGH RESET
NET RST   PULLUP;
NET nOE   LOC=P61; # ACTIVE-LOW OUTPUT ENABLE
NET nOE   PULLUP;
NET nCE   LOC=P65; # ACTIVE-LOW CHIP ENABLE
NET nCE   PULLUP;
