(c) ALSE - http://www.alse-fr.com/English

This is a complete project demonstrating the use
of the simple PS/2 Controller.

The files are :

- PS2_Ctrl.pdf : the documentation. Read it !
- PS2_Ctrl.vhd : the controller
- SevenSeg.vhd : 7-Segments decoder (for the simple application)
- PS2simpl.vhd : Simple Application top-level.
- KBD_Tst.vhd  : Self-testing Unitary Test Bench
- Kbd.do       : Simulation script, ready to use.
- wKbd.do      : waveform script for simualtion with ModelSim

The subdirectory Xess contains an XC40 board specific version.

