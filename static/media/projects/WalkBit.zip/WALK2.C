/* WALK2.C
 *
 * ---------------------------
 * Demo Program for Xess Board
 * ---------------------------
 * (c) B. Cuzeau | alse@compuserve.com
 * 
 * This trivial C code works well with SDCC
 * (Excellent freeware 8051 compiler)
 * http://sdcc.sourceforge.net
 * Use :
 *  sdcc walk2.c
 *  copy walk2.ihx walk2.hex
 *  xsload walk2.hex vtop.bit
 * Enjoy !
 */

// Declare the FPGA registers

xdata at 0x0F000 unsigned char  LEDREG;  // 7-Seg LED
xdata at 0x0E000 unsigned char  LFSR;    // Interrupt Control & Status Register
xdata at 0x0D000 unsigned char  LFShift; // Transmitter Control and Status Register

// Function Prototypes
int delai (int i);

// --- Main ---

void main (void)
{
  unsigned short i;
  unsigned short A;

  delai (4);  // 1 second initial tempo

// walking bit test :
  A=1;
  for (i=0; i<32; i++)
  { if (A==128) A=1; //(we don't have the MSB)
    LEDREG=A;
    A = A<<1;
    delai (1);
  }

// LFSR test :

  A=1;
  LFSR=A;    // Store seed in shift register
  while ( A != 0)
  {
    //A=LFSR;    // read the LFSR
    //LFShift=A; // shift for next pass
    //LEDREG=A;  // display the value

    // If you like it a bit more cryptic :

    LEDREG=LFShift=A=LFSR;
    delai (2); // small tempo
  }
}

// Note : if the LFSR ever comes to 0,
// we get stuck at the end of main
// (SDCC implements an implicit jmp $)

// --- SubRoutines ---

int delai (int i)   // 1 = ~ 1/5 second
{
  int k, l;
  for (k=0; k<=i; k++)
  {
    for (l=0; l<=32767; l++)
      ;
  }

}