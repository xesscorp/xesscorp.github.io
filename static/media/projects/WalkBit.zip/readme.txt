(if you can, you should rather open the
Word-format documentation included.)

  --------------------------------------
    Walking Bit & Random numbers
  --------------------------------------
   Bert Cuzeau
   alse@compuserve.com

I have written this example after having spent some
time figuring out how to use the 8031-FPGA combination.
(I did not have the Foundation software)
I also experienced Xilinx Mapper problems while trying to
implement the asynchronous solutions suggested
in various examples.

This example does only require a VHDL synthesizer,
and the Xilinx Alliance Base product.

Files :

- G_BIDIR.vhd : optional : Bi-directional buffer
- G_DEC.vhd   : optional : D flipFlip with Enable & Clear
- LFSREG.vhd  : Random Number Generator
- LEDREG.vhd  : Led register
- VTOP.vhd    : Top-Level description
- XL40.ucf    : Pin Lock constraint file
- XC4010XL.bit: Ready-to-use download file for XC4010XL

- WALK.asm    : Assembler program file
- WALK.hex    : Binary program file

- README.txt  : this file
- WALKBIT.doc : Word-formatted documentation with schematics.

Note : The two first vhdl modules are not necessary.
They can be used to demonstrate the use of "Generate"
VHDL statements.
It would have been trivial to include verything in a single
file (top-level), but it is not the way to handle more
complex projects...
This project can serve as a platform for more ambitious
designs (enhancing the decoder process, adding other submodules,
etc....)
PLEASE : before doing this, you should check the timing
information of the 8031 chip and ensure that the synchronous
solution implemented here is correct.

--------------------------------------------------
  Design Flow (based on Alliance 2.1i):
--------------------------------------------------

 * Create a directory and place the files listed above.

 * Launch your perferred VHDL Synthesis tool.
 * Create a new project in your new directory.
 * Add the sources files LFSREG.vhd, LEDREG.vhd and VTOP.vhd.
   VTOP should be the top-level (the last in the list if you
   use Synplicity)
 * Select the proper target for your board,
 * Synthesize the project. (select the VTOP if you use
   FPGA Express)
   You should only have one normal warning (we have one
   unused bit in LEDreg).
   The Edif file should be done (vtop.edf).
 * Quit your synthesis tool.

 * Launch Xilinx Design Manager
 * File-New Project-Browse
   Go to your directory and pick vtop.edf
   Click on Ok (use the default work directory)
 * In the Constraints File box, select "Custom"
   Browse back to your dir and select XL40.UCF
   Click on Ok.
   Click on OK.
   Now we're back to the main screen.
 * Click on the black arrow (Design-Implement)
   You should end up with a properly implemented chip,
   with a bit file ready to use !
 * Quit Design Manager.

 * Open an MS-DOS window
 * Type :
   xsload walk.hex vtop.bit
 * Run GXSPORT to toggle the D0 bit to 1 then back to 0
   in order to reset properly the 8031.

   You should see the walking bit followed by 32 pseudo-
   random patterns on the LED display.

   PS: If your board doesn't pass the GXSTEST, you
   could try to reprogram the clock generator as indicated
   in the documentation.

I hope this may be useful for those who are focused on
VHDL methodologies.

Have fun !

   ---------------------------
   Bert Cuzeau

   ASIC & FPGA Design Expert
   Doulos HDL Course Leader

   alse@compuserve.com
   ---------------------------

