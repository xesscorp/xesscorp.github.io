             Audio Codec Configurator for the XSB-300E Board
                               XESS Corp.
                               11/15/2003

This ZIP file contains a graphical utility and parallel port interface
circuit that will let you load the configuration registers of the AK4565
audio codec on the XSB-300E Board.  Once the codec is initialized, you 
can download your circuit that processes the serial input and output 
data streams.  Isolating the initialization allows you to easily try 
different options for the codec without having to modify your signal 
processing circuit.

This ZIP file contains another ZIP file, cfgcodec.zip, that has the design
files for the circuit that interfaces the audio codec to the parallel port.  

Here's how to use the files in this ZIP file:

1) Make sure you have XSTOOLS 4.0.3 installed on your PC.  Earlier
   versions of XSTOOLs do not have support for the XSB-300E Board.

2) Place the cfgcodec.bit file into the C:\XSTOOLS\XSB folder.

3) Place the gxssetcodec.exe file into the C:\XSTOOLS folder.

4) Double-click on the C:\XSTOOLS\gxssetcodec.exe icon.  Then set the
   codec options using the graphical user interface.

5) Plug an audio source into the blue jack of J1 and a set of headphones
   into the green jack of J1.

6) Click on the SET button in the gxssetcodec window to load your
   settings into the codec and listen to the results through the
   headphones.  Then change the settings to achieve the desired results.

