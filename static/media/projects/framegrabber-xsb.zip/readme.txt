                  Frame Grabber for the XSB-300E Board
                               XESS Corp.
                               10/15/2003

This ZIP file contains another ZIP file, fg.zip, that has the design
files for a frame grabber that runs on an XSB-300E Board.  Every few
seconds the frame grabber will sample a frame of video using the
SAA7114 video codec and will display the luminance as a black-and-white
image on a VGA monitor using the THS8133 video DAC.

The frame grabber design does not include the circuitry required to
initialize the SAA7114.  We provide a utility that will initialize the
SAA7114 registers with values from a file on the PC.  Once the SAA7114
is initialized, the frame grabber can be downloaded to the XSB-300E
Board whereupon it will begin grabbing and displaying video frames.
Splitting the initialization out of the main frame grabber design allows
you to easily try different options for the SAA7114 without having to
modify the generic frame grabber design.

Here's how to use the frame grabber:

1) Make sure you have XSTOOLS 4.0.3 installed on your PC.  Earlier
   versions of XSTOOLs do not have support for the XSB-300E Board.

2) Place the xssetsaa.exe and fg.bit files into the C:\XSTOOLS folder.

3) Place the cfgi2c.bit and saa7114.txt files into the 
   C:\XSTOOLS\XSB folder.

4) Open a command-line window and go to the C:\XSTOOLS folder.
   Then issue the command:
      xssetsaa -p 1 -b XSB-300E -f XSB\saa7114.txt

5) Plug a source of NTSC video into RCA jack J8 and a VGA monitor
   into connector X2 of the XSB-300E Board.

6) Use GXSLOAD to download the fg.bit file into the XSB-300E Board.
   The LED2 digit will display a "T" rotated 90 degrees that flashes
   every second as a new frame of video is grabbed and stored in memory.
   The frame of video will be displayed on the VGA monitor.  

Change the contents of the saa7114.txt file if you want to try
different options of the SAA7114 chip.  The saa7114.txt file consists
of a series of lines with each line having a register address and the 
value to be loaded into that register.  You must make sure that the
last two lines in the file reset and then set bit D5 of register 0x88.
This generates a software reset for the SAA7114 and causes it to
recognize the options enabled by the new register values.

