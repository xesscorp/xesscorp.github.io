USING GNAT ON THE XESS XSA-3S1000 Board
    GNAT is a simple module invented by Silicon and Software Systems (S3)
    Ltd. that makes it easy to control and monitor your FPGA design through
    the JTAG port. You can find out all about GNAT at
    http://www.s3group.com/system_ic/gnat/. They also have an example design
    for an FPGA board that illustrates what can be done with GNAT (
    http://www.s3group.com/system_ic/gnat/download_gnat/ ).

    We have slightly modified their example design to port it to the XESS
    XSA-3S1000 Board. You can find the archive for this modified project at
    http://www.xess.com/projects/gnat_xsa_3s1000.zip .

APPLICATION DIRECTORY TREE
    The directory tree for the XSA-3S1000 GNAT example is shown below:

      gnat_xsa_3s1000 --+
                        |
                        +--- bin
                        |
                        +--- gnat
                        |            
                        +--- spartan3

    The content of each subdirectory is listed below.

    * bin
        This directory contains several executables. gnat-gui.exe is S3's
        interactive interface to a GNAT-enabled design. Xilinx provides the
        playxsvf*.exe executables that will download an XSVF-formatted
        bitstream into an FPGA through its JTAG port. (These can be used by
        gnat-gui.exe to configure the FPGA directly without using the Xilinx
        iMPACT program.)

    * gnat
        This directory stores the VHDL files for the GNAT module. These
        files are unchanged from those provided directly by S3.

    * spartan3
        This directory stores the top-level VHDL module and pin assignment
        UCF file for the example design that interfaces to the GNAT module.
        These design files are compiled with the GNAT module using Xilinx
        WebPACK 6.3 to create an XSVF file that can be downloaded to the
        XSA-3S1000. There is also a gnat-setup-s3.tcl file that tells the
        gnat-gui.exe program about the connection of the GNAT module to the
        other circuitry in the example design. All these files have been
        slightly modified to reflect the hardware of the XSA-3S1000 Board.
        The changes have been clearly marked so you can identify the places
        where you will have to alter these files for your own designs.

INSTALLATION
    *   Get the GNAT archive from the S3 website (
        http://www.s3group.com/system_ic/gnat/download_gnat/ ). This
        contains an article from the Xilinx XCELL magazine that describes
        GNAT (xc_jtag53.pdf). Another document (gnat-s3.pdf) describes how
        to install and use GNAT in greater detail than is discussed here. It
        also describes the circuitry included in the example design.

    *   Get the archive for the modified GNAT example design from the XESS
        website ( http://www.xess.com/projects/gnat_xsa_3s1000.zip ) and
        unpack it.

    *   Go to http://www.xilinx.com and download and install the WebPACK and
        Chipscope Pro software packages.

    *   Create a new CHIPSCOPE environment variable that points to the
        Chipscope installation directory. (On Windows 2000 or XP, define the
        new variable by clicking START -> SETTINGS -> CONTROL PANEL ->
        SYSTEM -> ADVANCED -> ENVIRONMENT VARIABLES and then click on New...
        to create a system variable named CHIPSCOPE with the appropriate
        directory as its value.) Then add %CHIPSCOPE%; to the beginning of
        the PATH system variable.

    *   Copy one of the playxsvf*.exe files from gnat_xsa_s3\bin to your
        %XILINX%\bin\nt directory and change its name to playxsvf.exe. (On
        Windows 2000, I found only the playxsvfdyn501b.exe would work
        correctly when called by gnat-gui.exe.)

    *   Prepare your XSA-3S1000 Board by using GXSLOAD or XSLOAD to program
        the CPLD with the XSTOOLS\XSA\3S1000\p3jtag.svf file. Then move the
        shunt on jumper J9 to the XI position. (This allows the board to
        respond to JTAG commands by making the CPLD emulate a Xilinx
        Parallel 3 cable.)

TESTING THE EXAMPLE DESIGN
    *   Double-click the gnat_xsa_3s1000\spartan3\spartan3.npl file to open
        the WebPACK project for the example design.

    *   Highlight the toplevel-rtl object in the Sources pane. Then
        double-click the "Generate PROM, ACE or JTAG File" item in the
        Processes pane. The example design will go through the synthesis and
        implementation phases and then iMPACT will start. Once iMPACT
        starts, do the following:

        *   Indicate that you want to create a Boundary-Scan File. Click
            Next>.

        *   Select XSVF as the file type. Click Finish.

        *   Type-in the name of the file to be created: gnat-s3.xsvf. Click
            Save and then click OK on the acknowledgement window that
            follows.

        *   Select the file containing the device configuration bitstream
            that will be translated into XSVF. Click Open.

        *   A drawing of a JTAG chain containing a single xc3s1000 FPGA
            should appear in the main iMPACT window. Right-click on the
            xc3s1000 block and select Program... Click on OK in the window
            that appears. Within a few seconds, you should receive an
            acknowledgement that the programming was successful. The
            gnat-s3.xsvf file now contains the bitstream for the FPGA. You
            can close iMPACT at this point.

    *   Start the GNAT interface by double-clicking the
        gnat_xsa_3s1000\bin\gnat-gui.exe icon. You will be asked to select a
        setup file. Go to the gnat_xsa_3s1000\spartan3 directory, highlight
        the gnat-setup-s3.tcl file and click on Open. (This file contains
        information that tells gnat-gui.exe about the various interfaces
        between the GNAT module and the other circuitry in the example
        design.) The main GNAT window should appear.

    *   Higlight the xc3s1000 object in the JTAG Chain pane. Then click on
        the "select file" button in the Command Window. Go to the
        gnat_xsa_3s1000\spartan3 directory, highlight the gnat-s3.xsvf file
        that was created, and click on Open. Then click on the run button in
        the Command Window. The contents of the XSVF file will be downloaded
        to configure the FPGA with the circuitry of the example design. This
        should take about 10 seconds. Look in the Log Window for error
        messages. (You may have to scroll it to the right to see errors
        relating to the XSVF download procedure.) If errors occur during the
        download, you may have to try a different version of the
        playxsvf.exe file. If none of the versions works, then you will have
        to download the bitstream using iMPACT. (Remember to close iMPACT
        before starting gnat-gui or they will clash as they both try to
        access the JTAG port of the FPGA).

    *   Click on the "Start Polling" button. This will make gnat-gui
        continuously monitor the state of the circuit downloaded into the
        FPGA. Now you can click on the Inc button and watch how the LEDs
        change on the XSA-3S1000 Board and in the Virtual Instruments
        Window. Pressing the SW2 pushbutton on the XSA-3S1000 Board will
        extinguish the LEDs on the board and in the Virtual Instruments
        Window. Changing the DIP switch settings on the board will also be
        reflected in the Virtual Instruments Window.

ENVIRONMENT
    This example design was developed using the following versions of
    software:

       Xilinx WebPACK       : 6.3.03i
       Xilinx Chipscope Pro : 6.3.03i
       Xilinx playxsvf      : playxsvfdyn501b.exe
       S3 GNAT              : V1.1 (beta)

SOURCE FILES
    You can download the source files for the original GNAT example design
    from the S3 website at
    http://www.s3group.com/system_ic/gnat/download_gnat/ .

    You can download the source files for the modified GNAT example design
    from the XESS website at
    http://www.xess.com/projects/gnat_xsa_3s1000.zip .

AUTHOR
    Dave Vanden Bout, X Engineering Software Systems Corp.

    Send bug reports to bugs@xess.com.

COPYRIGHT AND LICENSE
    Copyright 2005 by X Engineering Software Systems Corporation.

    These applications can be freely distributed and modified as long as you
    do not remove the attributions to the author or his employer.

HISTORY
    08/11/2005 - Initial release.

