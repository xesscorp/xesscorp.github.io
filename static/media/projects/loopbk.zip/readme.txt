LOOPBACK EXAMPLE FOR XSTEND BOARD

XESS CORPORATION, 1999

========================================================

PURPOSE
-------
These files are used to create a .BIT file for an XS40
Board that is inserted into an XStend Board.  The .BIT
file will program the XS40 such that it will accept a
digitized stereo signal from the XStend board codec ADC
and loop it back to the codec DAC.  The DAC will convert
the digitized signal back into an analog signal that will
drive stereo headphones.


FILES
-----
loopback.vhd: This is the top-level VHDL module for the
   loopback design.  It calls the codec interface module
   to do all the work.  There is a switch in this module
   that you must set to select the version of XStend
   Board you are targeting (either V1.2 or V1.3).

codec.vhd: This is the VHDL for the codec interface
   circuit.  You can get an explanation of how this works
   by reading the XStend Board manual found in the
   manuals/docs section of www.xess.com/FPGA.

loopback.ucf: This is the user-constraints file.  It holds
   the assignment of the loopback I/O signals to the actual
   pins of the XS40/XStend Board combination.

