This is a simple NTSC generator that puts a gray scale picture on the TV.

C code:
	'togray' reads a 320x262 BMP ( 24 bit color ) and puts the gray scale pixels in test.bin. Currently togray is hardcoded to read 'test.bmp'. Modify togray 
	if you need to display another bitmap image.

	'rbw' reads 'test.bin' and generates the xes file test.xes
	First, you run togray, then you run rbw.

VHDL code:
		memtest.vhd
		randgen.vhd
		sdramcnt.vhd
		tst50.vhd
		xs_pckg.vhd

ISE project file:
	ntsc2.ise

The connections between the XSA-50 and the R2R ladder are summarized in
in r2r.jpg.

Both 'sdramtst.bit' and 'test.xes' need to be downloaded to
the XSA 50 board.
