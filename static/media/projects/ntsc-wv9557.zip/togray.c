/* rbw: read color  BMP file */
/* and produced test.bin     */
/* only do 320x262           */

#include <stdio.h>
#include <windows.h>

#define YOUR_BMP_FILE "test.bmp"
unsigned char b[320*320];
int getb(FILE *f);

unsigned int ii = 0;
const int do_large = 1;

void insert_data(unsigned char data)
{
	if (ii>=sizeof b)
			return;
	b[ii++] = data;
}


void dump(unsigned char c)
{
	if (c&0x80){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
	if (c&0x40){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
	if (c&0x20){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
	if (c&0x10){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}

	if (c&0x08){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
	if (c&0x04){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
	if (c&0x02){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
	if (c&0x01){printf("#");insert_data(1);} else {printf(" "); insert_data(0);}
}

BITMAPFILEHEADER hd;
BITMAPINFOHEADER info;
#define WIDTH  320
#define HEIGHT  262
int main(int argc, char *argv[])
{
		int c; 

		unsigned long count=0;
		FILE *outfile = 0;
		int i, j;
		FILE *f = fopen(YOUR_BMP_FILE, "rb");
		if (f==0) {
			fprintf(stderr, "can't open %s\n", YOUR_BMP_FILE);
			exit(0);
		}
		fread(&hd, sizeof hd, 1, f); 
		fread(&info, sizeof info, 1, f); 
		/*
		printf("sizeof  of hd %u\r\n",  sizeof hd);
		printf("sizeof  of info %u\r\n",  sizeof info);
		*/

		outfile = fopen("test.bin", "wb");
		if (outfile ==0) {
			fprintf(stderr, "Can't open test.bin for writing..\n");
			exit(0);
		}
		fprintf(stderr, "test.bin  created. Now run rbw to produce xes file\n");

		
		for (i = 0; i< HEIGHT; i++) {
		for (j = 0; j<WIDTH; j++) {
		unsigned cgray;
		int igray;
		double gray;
			int red;
			int green;
			int blue;
			red =getb(f);
			green =getb(f);
			blue =getb(f);
			gray=0.299*red +  0.587*green + 0.114*blue;
			if(gray>255)
				igray=255;
				else
				igray = gray;
				cgray=igray;
				/*printf(" pattern[%d][%d] = %d;\n", i, j,  igray);*/
				putc(cgray, outfile);

				
		}
		}
		fclose(outfile);
}


int getb(FILE *f)
{

		int c = getc(f);
		if (c==EOF)  {
		fprintf(stderr, "Premature EOF\r\n");
		exit(0);
		}
		return c;
}
