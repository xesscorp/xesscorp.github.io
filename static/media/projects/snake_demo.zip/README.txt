-----------------------------------------------------------------------------------------
SNAKE GAME DEMO
-----------------------------------------------------------------------------------------

by Anti Sullin
anti [dot] sullin [at] ttu [dot] ee

This game demo was created for the "IAY0070 HW/SW Co-design" class 
project in Tallinn University of Technology (http://www.ttu.ee), Estonia.
-----------------------------------------------------------------------------------------

Components from Xesswere re-used:
* SDRAM controller
* SDRAM controller 2-port module
* SDRAM controller to LPT port module (modified to be a sdram to PicoBlaze module)
* VGA generator (modified, added all the fancy 2-layer support)
* PicoBlaze

Some of my own components were re-used:
* a small PS/2 keyboard module

Feel free to use all of my modifications/new code in any projects of your own.
When using the code based on Xess code, licencing terms of Xess must be followed.
As seen on video files attached, this demo worked on my system. Still, I do not
guarantee anything and I am not responcible if the contents of this package just
does not work or causes any damage to your hw/sw.

COMPONENTS OF THIS PACKAGE:
-----------------------------------------------------------------------------------------
* binaries for the XSA-3S1000 board (FPGA and SDRAM)

* Picoblaze ASM source code tree in source/snake_src.zip/Assembler
* The whole hardware VHDL tree in source/snake_src.zip
* My game background image in source/images.zip
* BMP palette used with Jasc Paint Shop Pro to create BMP images in source/8bit.pspalette
* 2bin2xs16 utility with source to combine two image files into interleaved memory file: source/2bin2xs16.zip

* project report in video_game.pdf
* two videos how the game looked on my monitor (XVid codec needed)
* this README

-----------------------------------------------------------------------------------------
If you found something from this package useful, drop me an e-mail!