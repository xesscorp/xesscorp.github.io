//------------------------------------------------------------------------------
// Project: HID test software.
// File:    hidLIB.hpp
// Purpose: HID library prototypes.
// History: FB, 2001feb07, created.
//------------------------------------------------------------------------------

HANDLE hidOpen (unsigned short idVendor, unsigned short idProduct);
void   hidCaps (HANDLE DeviceHandle, int* inreport, int* outreport);
void   hidClose(HANDLE DeviceHandle);
int    hidRead (HANDLE handle, unsigned char* buf, int len);
int    hidWrite(HANDLE handle, unsigned char* buf, int len);

//------------------------------------------------------------------------------
// end of file
