//------------------------------------------------------------------------------
// Project: HID test software.
// File:    main.cpp
// Purpose: hidLIB test application.
// History: FB, 2001feb07, created.
//------------------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include <conio.h>

#include "hidLIB.hpp"

//------------------------------------------------------------------------------
int main(int argc, char* argv[])
{	unsigned short VID, PID;
	
	fprintf(stdout, "VID: 0x");
	fscanf(stdin, "%x", &VID);
	fprintf(stdout, "PID: 0x");
	fscanf(stdin, "%x", &PID);
	fprintf(stdout, "VID, PID: 0x%04X, 0x%04X\n", VID, PID);

	HANDLE hid= hidOpen(VID, PID);
	if (!hid) 
	{	fprintf(stderr, "device not found\n");
		return -1;
	}

#if 1
	int inreport, outreport;
	fprintf(stdout, "\n");
	hidCaps(hid, &inreport, &outreport);
	fprintf(stdout, "\n");
#endif

	int c; char line[80];
	do
	{	fprintf(stdout, "r, w, x: ");
		scanf("%s", line);
		c= line[0];

		unsigned char buf[80];
		memset(buf, 0, sizeof(buf));
		switch(c)
		{	case 'r':
			case 'R':
			{	fprintf(stdout, "hidRead: ");
				int q= hidRead(hid, buf, inreport);
				if (q!= inreport) 
				{	fprintf(stderr, "\n*** error\n");
				}
				else
				{	for (int j= 1; j< inreport; j++)
						fprintf(stdout, "%02X ", buf[j]);
					fprintf(stdout, "\n");
				}
			}	break;

			case 'w':
			case 'W':
			{	for (int i= 1; i< outreport; i++)
				{	int b;
					fprintf(stdout, "%d: 0x", i);
					fscanf(stdin, "%x", &b);
					buf[i]= unsigned char(b);
				}
				fprintf(stdout, "hidWrite: ");
				for (int j= 1; j< outreport; j++)
					fprintf(stdout, "%02X ", buf[j]);
				fprintf(stdout, "\n");

				int q= hidWrite(hid, buf, outreport);
				if (q!= outreport) fprintf(stderr, "*** error\n");
			}	break;

		}
	} while(c!= 'x' && c!= 'X');

	hidClose(hid);
	return 0;
}

//------------------------------------------------------------------------------
// end of file
