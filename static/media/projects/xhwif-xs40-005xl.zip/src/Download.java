import  com.xilinx.JBits.XC4000.JBits;
import  com.xilinx.JBits.XC4000.Devices;

import  com.xilinx.JBits.XC4000.CoreLib.*;

import  com.xilinx.JBits.XC4000.ConfigurationException;

import  com.xilinx.JBits.XC4000.Bits.IOB;

import  com.xilinx.XHWIF.XHWIF;

import com.xilinx.JBits.XC4000.Util;

public class Download {

   static byte    bs[];
   static int     lut[];
   static JBits   jBits;
   static XHWIF   board = null;

public static void
main(String  args[]) {
   String  usage = "Usage:  gafpga -<board> <infile.bit>\n"+
                   "\n"+
                   "Where board is:\n"+
                   XHWIF.SUPPORTED_SYSTEMS +
                   "\n";
   long    result;
   int     i;
   int     port;
   int     bits = 0;
   int     tmp;
   int     row;
   int     col;
   int     clbRows;
   int     clbColumns;
   int     deviceCount;
   int     deviceType = Devices.UNKNOWN_DEVICE;;
   String  systemNameFlag = "";
   String  infileName = "";
   String  remoteHostName = null;
   


   /*
   **  Parse command line parameters
   */

   if (args.length == 2) {
      systemNameFlag = args[0];
      infileName = args[1];
      } else {
         System.out.println(usage);
         System.exit(-1);
         }  /* end if() */

   /* Get the remote host name (if we have one) */
   remoteHostName = XHWIF.GetRemoteHostName(systemNameFlag);

   /* Get the remote port number (if we have one) */
   port = XHWIF.GetPort(systemNameFlag);

   /* Get the board XHWIF interface */
   board = XHWIF.Get(systemNameFlag);
   if (board == null) {
      System.out.println("Could not access interface to '" + systemNameFlag +
                         "' hardware.  Exiting.");
      System.out.println(usage);
      System.exit(-1);
      }  /* end if() */


   /* Attempt to connect to the hardware */
   result = board.connect(remoteHostName, port);
   if (result != 0) {
      System.out.println("Could not connect to hardware.  Exiting.");
      System.exit(-1);
      }

   /* Get the type of devices used by the first FPGA on the board */
   deviceType = board.getDeviceType(0);

   /* Get the jBits device model for the device */
   jBits = new JBits(deviceType);

   /* Read in the bit file */
   System.out.println("Reading in "+infileName+".");
   System.out.println("");
   try {
      bits = jBits.read(infileName);
      } catch (Exception e) {
         System.out.println("Could not read in bitstream from file "+infileName+
                            ".  Exiting.");
         System.exit(-3);
      }  /* end catch() */

   System.out.println(bits + " bits read from bitstream file "+infileName+".");
   
   bs = jBits.get();
   if (bs == null)
      System.out.println("Error reading bitstream from JBits.");

   /* Download the bitstream to device 0 */
   result = board.setConfiguration(0, bs);
   
   System.out.println("Exiting.");

   board.disconnect();

   }  /* end main() */



}  /* end class Reconfig */



