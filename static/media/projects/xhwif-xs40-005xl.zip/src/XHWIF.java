
package com.xilinx.XHWIF;


import  com.xilinx.JBits.XC4000.Bitstream;
import  com.xilinx.JBits.XC4000.Devices;

import  com.xilinx.JBits.XC4000.ConfigurationException;


/**
**
**
**  <blockquote>
**  NOTE:  The source code for this class is provided for
**         informational purposes for engineers doing
**         <em>XHWIF</em> ports.  New interfaces are supported
**         by inheriting this class.
**         <b>THIS FILE SHOULD NOT BE MODIFIED!!</b>
**  </blockquote>
**
**  <p>
**
**  This defines a generic interface to the hardware of a reconfigurable 
**  logic based system.  This is intended to be used to facilitate porting
**  tools and applications from one hardware platform to another.  Note
**  that only the abstract functions must be supplied by the new
**  subclass.  The other "helper" functions based on this abstract
**  functions will still be available.
**
**  <p>
**
**  This interface must be re-implemented for each new hardware
**  platform.  It may also be extended, if necessary.  These
**  extensions, however, will not be portable.
**
**  <p>
**
**  Finally, a message passing version of this interface may be used
**  (along with a remote server) to interact with the hardware remotely.
**  Note that some of the functionality of this class (such as returning
**  blocks of data) is geared toward efficient support of a message passing
**  interface.  This should be kept in mind when crafting any extensions
**  to this package.
**
**  <p>
**
**  Note that is is strongly recommended that all <em>XHWIF</em> subclasses
**  have names that are in all lower case letters.  This is because 
**  <em>XHWIF</em> provides dynamic class loading of these subclasses.  This
**  is usually performed in response to some user-defined string such as
**  a command line flag.  Unfortunately, class names are case-sensitive in
**  Java, and hence, such command line flags will also be case-sensitive.
**  So to automatically support this automatic command line flags feature in
**  applications <em>XHWIF</em> subclasses <em>must</em> have names in all
**  lower case.
**
**  <p>
**
**  This interface was inspired by the Pci6200 interface written by
**  SAG for the XC6200DS.
**
**  <p>
**
**  Copyright (c)  1997 by Xilinx
**
**  <p>
**
**  version      1.00  August 6, 1997 <br>
**  version      1.10  December 23, 1997 <br>
**  version      1.20  February 4, 1998 <br>
**  version      1.30  February 9, 1998 <br>
**  @version      1.40  October 7, 1998
**  @author       SAG
**
*/


public abstract class XHWIF {


/**
**  This string contains a description of all of the boards
**  supported in this release of the software.  Of course,
**  users may add their own <em>XHWIF</em> interfaces to
**  <em>com.xilinx.XHWIF</em> to support new hardware.  These
**  will, or course, not be listed in this string.  This
**  string is provided primarily for "usage" error messages.
*/

public final static String  SUPPORTED_SYSTEMS =
   "   Demo          - Demonstration mode\n" +
   "   Wildforce     - Annapolis Wildforce (XC4036EX)\n" +
   "   Wildforce36EX - Annapolis Wildforce (XC4036EX)\n" +
   "   Wildforce62XL - Annapolis Wildforce (XC4062XL)\n" +
   "   Wildforce85XL - Annapolis Wildforce (XC4085XL)\n" +
   "   WildOne       - Annapolis WildOne  (XC4036EX)\n" +
   "   WildOne36EX   - Annapolis WildOne  (XC4036EX)\n" +
   "   WildOne62XL   - Annapolis WildOne  (XC4062XL)\n" +
   "   WildOne85XL   - Annapolis WildOne  (XC4085XL)\n" +
   "   Pamette       - DEC PCI Pamette (XC4028EX)\n" +
   "   Pamette28EX   - DEC PCI Pamette (XC4028EX)\n" +
   "   Pamette44XL   - DEC PCI Pamette (XC4044XL)\n" +
   "   xs4005        - Xess XS40 (XC4005XL)          \n" +
   "   XHWIFnet@<hostname>{:port} - Remote access via XHWIFServer";


/*
**  Some private data structures (to support the non-abstract
**  functions).  These cache some commonly-used data in the
**  non-abstract functions.  This can greatly increase performance,
**  especially for remote access.
**
*/

private int  deviceType[] = null;
private int  pkgType[] = null;
private int  arraySize[] = null;
private int  deviceCount = 0;

private String  hostName = null;
private int  port = Message.DEFAULT_PORT;


/* Used to get width and height from getArraySize() */
public static final int  ARRAY_WIDTH =  0;
public static final int  ARRAY_HEIGHT = 1;


/**
**  This function is used to help parse command line parameters.
**  It takes in a string indicating an implementation of an
**  <em>XHWIF</em> interface for a particular system and returns
**  the <em>XHWIF</em> interface.  This function is provided
**  to avoid the duplication of this commonly used function.
**
**  <p>
**
**  This function operates by finding XHWIF interfaces in the
**  <em>com.xilinx.XHWIF</em> directory.  And interface supported
**  by an <em>XHWIF</em> subclass in this location is accessible
**  by using this function and a string containing the name of the
**  class.
**
**  <p>
**
**  This permits users to add new interfaces and automatically get
**  command line support for these new interfaces.  <em>Even for
**  existing, pre-compiled applications</em>.
**
**  <p>
**
**  The currently supported interfaces shipped with this version of
**  <em>XHWIF</em> are:
**
**  <ul>
**     <li>  Demo        - Demonstration mode
**     <li>  Wildforce   - Annapolis Wildforce (XC4036EX/XL)
**     <li>  WildOne     - Annapolis WildOne  (XC4036EX/XL)
**     <li>  Pamette     - DEC PCI Pamette (XC4028EX)
**     <li>  Pamette28EX - DEC PCI Pamette (XC4028EX)
**     <li>  Pamette44XL - DEC PCI Pamette (XC4044XL)
**     <li>  Custom      - User-defined custom interface
**     <li>  xs4005      - XESS XS40 (XC4005XL)
**     <li>  XHWIFnet@<hostname>{:port} - Remote access via XHWIFServer
**  </ul>
**
**  <p>
**
**  After the <em>XHWIF</em> object is returned from this function,
**  use the <em>getRemoteHostName()</em> and <em>getPort()</em>
**  functions to get the parameters to the <em>connect()</em>
**  function.  Note that both <em>getRemoteHostName()</em>
**  and <em>getPort()</em> should take the same exact String
**  parameter, <em>systemName</em> as this function.
**
**  <p>
**
**  Note that this function is statically defined and does not
**  require an <em>XHWIF</em> object to be constructed for its
**  use.
**
**
**  @param  systemName  This is the name of the system supported by
**          XHWIF.  The first character is optionally a dash ("-").
**
**  @return  This function returns an XHWIF interface if the requested
**           system is supported, otherwise <em>null</em> is returned.
**
**
*/

public static XHWIF
Get(String  systemName) {
   int    index;
   Class  systemClass = null;
   XHWIF  system = null;

   /* Remove (optional) dash ("-") from command line flag */
   if (systemName.startsWith("-") == true)
      systemName = systemName.substring(1);

   /* Convert to lower case */
   systemName = systemName.toLowerCase();

   /* If we have an "XHWIFNet@" parameter, remove */
   /* everything after (and including) the "@"    */
   if (systemName.startsWith("xhwifnet@") == true) {
      index = systemName.indexOf("@");
      systemName = systemName.substring(0, index);
      }

   /*
   **  This neat little piece of code gets an object based
   ** only on a string name.  This permits users to add
   ** new XHWIF interfaces and automagically get command
   ** line flags to support them.
   */
   
   try { 

      systemClass = Class.forName("com.xilinx.XHWIF.Boards." + systemName); 
      system = (XHWIF) systemClass.newInstance();

      } catch (Exception  e) {
         system = null;
      }  /* end try */  

   return (system);

   }  /* end Get()*/




/**
**  This function returns the remote host name for networked access
**  via <em>XHWIFNet</em>.  Note that this value is <em>null</em> for
**  all non-networked acesses.  This provide the correct value for
**  the <em>XHWIF</em> <em>connect()</em> function in both cases.
**
**  @param  systemName  This is the name of the system supported by
**          XHWIF.  The first character is optionally a dash ("-") to
**          aid in the use of command line parameter flags.
**
**  @return  This function returns the remote host name for networked
**           <em>XHWIFNet</em> access.  If non-networked, direct access
**           to hardware is specified, a <em>null</em> string is returned.
**           Note that this is the appropriate value for the 
**           <em>connect()</em> function in both cases.
**
**  @see Get
**
*/

public static String
GetRemoteHostName(String systemName) {
   int     index;
   String  remoteHostName = null;

   /* Remove (optional) dash ("-") */
   if (systemName.startsWith("-") == true)
      systemName = systemName.substring(1);

   /* Convert to lower case */
   systemName = systemName.toLowerCase();

   /* Be sure we have an XHWIFNet parameter */
   if (systemName.startsWith("xhwifnet@") == false)
      return (null);

   /* Remote host name is everything after the "@" */
   remoteHostName = systemName.substring("-xhwifnet@".length() - 1);

   /* Remote host name is before the (optional) ":" */
   index = remoteHostName.indexOf(":");
   if (index != -1)
      remoteHostName = remoteHostName.substring(0, index);

   return (remoteHostName);

   }  /* end GetRemoteHostName() */




/**
**  This function returns the remote host TCP/IP port number for networked
**  access via <em>XHWIFNet</em>.  Note that this value is the default port
**  defined in the <em>Messages</em> class, unless a value is specified and
**  parsed in the get() function.  But this dosen't matter.  Just use the
**  returned value in the <em>XHWIF</em> <em>connect()</em> function.
**
**  @param  systemName  This is the name of the system supported by
**          XHWIF.  The first character is optionally a dash ("-").
**
**  @return  This function returns the remote host TCP/IP port for networked
**           <em>XHWIFNet</em> access.  This value is set in the
**           <em>Get()</em> command.
**
**  @see Get
**
*/

public static int
GetPort(String systemName) {
   String  portStr = null;
   int     port = Message.DEFAULT_PORT;
   int     index;

   /* Return default on null */
   if (systemName == null)
      return (port);

   /* Remove (optional) dash ("-") */
   if (systemName.startsWith("-") == true)
      systemName = systemName.substring(1);

   /* Convert to lower case */
   systemName = systemName.toLowerCase();

   /* Be sure we have an XHWIFNet parameter */
   if (systemName.startsWith("xhwifnet@") == false)
      return (-1);

   /* Port number is everything after the (optional) ":" */
   index = systemName.indexOf(":");
   if (index != -1) {

      portStr = systemName.substring((index+1), systemName.length());

      /* Get numeric value for port (if we have one) */
      try {
         port = Integer.parseInt(portStr);
         } catch (NumberFormatException e) {
            /* something is wrong, return a guaranteed bad port */
            return (-1);
         }  /* end try{} */

      }  /* end if() */

   return (port);

   }  /* end GetPort() */





/**
**  This function establishes communication with the hardware.
**  This function should also perform all necessary hardware
**  initializations.  Note that the explicit connect / disconnect
**  approach is used here rather than a simple constructor
**  to establish the connection.  This permits explicit
**  disconnection to be performed, which may be necessary in
**  some networking environments.
**
**  @param  serverName  The name of the server to which to
**          connect.  If this parameter is <em>null</em>,
**          non-networked access to local hardware is assumed.
**
**  @param  port  This is the port number used by the network
**          connection.  It is ignored for non-networked access.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see disconnect
**  @see isConnected
**
*/

public abstract int connect(String  serverName, int  port);



/**
**  This function is a version of the <em>connect()</em>
**  function with the default TCP/IP port used.  It
**  otherwise functions identically to the <em>connect()</em>
**  function.
**
**  @param  serverName  The name of the server to which to
**          connect.  If this parameter is <em>null</em>,
**          non-networked access to local hardware is assumed.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see disconnect
**  @see isConnected
**
*/

public int connect(String  serverName) {

   return (connect(serverName, Message.DEFAULT_PORT));

   }  /* end connect() */



/**
**  This function is a version of the <em>connect()</em>
**  function used for local access to hardware.  No parameters
**  are specified.  This function is identical to the abstract
**  <em>connect()</em> with parameters of <em>null</em> for the
**  server name and <em>0</em> for the server port.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see disconnect
**  @see isConnected
**
*/

public int connect() {

   return (connect(null, 0));

   }  /* end connect() */



/**
**  This function shuts down the connection with the hardware.
**  Any exit clean-up should be performed in this function.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see connect
**  @see isConnected
**
*/

public abstract int disconnect();



/**
**  This returns the status of the current connection to the
**  hardware.  This function is supplied so that the integrity
**  of the connection can be tested dynamically, permitting
**  detection of run-time failures.
**
**  @return  This function returns <em>true</em> if a connection
**           to the hardware is active, and <em>false</em> if
**           there is no active connection.
**
**  @see connect
**  @see disconnect
**
*/

public abstract boolean isConnected();



/**
**  This function returns a string which gives the name of the
**  system.  This string is used primarily for status and error
**  messages.
**
**  @return  This function returns a string giving the name of
**           the system.
**
*/

public abstract String  getName();



/**
**  This function returns width and height of the FPGA array.
**
**  @return  This function returns the width and height of the FPGA
**           array.  <em>null</em> is returned on failure.
**
*/

public abstract int [] getArraySize();



/**
**  This function returns an array of integers representing the
**  devices on the board.  These codes are defined in the
**  <em>Devices</em> class.  The number of devices on the board
**  is also determined by the data returned by this call.
**
**  @return  This function returns an array of codes giving the types of
**           devices on the board or a <em>null</em> on failure.
**
**  @see getDeviceType
**  @see getPackageType
**  @see getDeviceCount
**
*/

public abstract int [] getDeviceType();


/**
**  This function returns an array of codes specifying the package types
**  of the the devices on the board.  This array should agree element for
**  element with the array returned by getDeviceType().  Note that this
**  permits mixing of device package types in the system.  The definitions
**  for the package types are defined as constants in <em>Device</em>
**  class.
**
**  @return  This function returns an array of codes giving the types of
**           device packages on the board or a <em>null</em> on
**           failure.
**
**  @see getPackageType
**  @see getDeviceType
**  @see getDeviceCount
**
*/

public abstract int [] getPackageType();



/**
**  This function returns an array of integers containing system-specific
**  information.  It is used primarily for simple status information and
**  to aid in debugging.
**
**  @return  This function returns an array of integers containing
**           system-specific information.  A <em>null</em> may
**           also be returned in no such information is available.
**
*/

public abstract int [] getSystemInfo();




/**
**  This function resets the entire system.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**
*/

public abstract int  reset();



/**
**  This function sets the frequency of an on-board programmable
**  oscillator.
**
**  @param  frequency  The frequency (in Megahertz) to which the
**          clock is to be set.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**
*/

public abstract int  setClockFrequency(float frequency);



/**
**  This function turns on the clock.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see  clockOff
**  @see  clockStep
**
*/

public abstract int  clockOn();



/**
**  This function turns off the clock.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see  clockOn
**  @see  clockStep
**
*/

public abstract int  clockOff();



/**
**  This function steps the clock <em>count</em> cycles.  The
**  clock should be halted when this function returns.
**
**  @param  count  The number of cycles to step the system clock.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see  clockOn
**  @see  clockOff
**
*/

public abstract int  clockStep(int  count);



/**
**  This function returns the complete device configuration.  In
**  Xilinx XC4000 devices this will be the entire bitstream, usually
**  read back from the device.  Note that it is advised that the
**  format of the bitstream returned by this function be compatible
**  with the download bitstream format.  This mostly means that a
**  40 byte header should be appended to the front of the data
**  which is read back from the hardware.
**
**  @param  device  This is the index of the reconfigurable logic device
**          to be read.  Note that this index is zero-based.  In a 
**          single-device system, for instance, this value should
**          be <em>0</em>.
**
**  @return  This function returns an array of bytes containing the
**           configuration data on success, or a <em>null</em> on
**           failure.
**
**  @see  setConfiguration
**
*/

public abstract byte [] getConfiguration(int  device);



/**
**  This sets the configuration of the reconfigurable logic device.  In
**  Xilinx XC4000 devices this will be the entire bitstream, usually
**  read from a file.
**
**  @param  device  This is the index of the reconfigurable logic device
**          to be written.  Note that this index is zero-based.  In a 
**          single-device system, for instance, this value should
**          be <em>0</em>.
**
**  @param  data  This is the data to be written to the device.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**
**  @see  getConfiguration
**
*/

public abstract int setConfiguration(int  device, byte data[]);


public abstract int testChip(int testVector);

/**
**  This function reads data from on board RAM.  Note that thie assumes that
**  on board RAM is distinctly addressable and available in the host memory
**  map.
**
**  @param  address  This is the start address of the local RAM data
**          to be returned.
**
**  @param  bytes  This is the number of bytes of RAM data to be read
**          and returned.
**
**  @return  This function returns an array of bytes containing the
**           data read on success, or a <em>null</em> on failure.
**
**
**  @see  getRAM
**
*/

public abstract byte [] getRAM(int address, int bytes);



/**
**  This function writes data to the on board RAM.  Note that thie assumes that
**  on board RAM is distinctly addressable and available in the host memory
**  map.
**
**  @param  address  This is the start address of the local RAM data
**          to be written.
**
**  @param  data  This is the data to be written to the RAM.
**
**  @return  This function returns a <em>0</em> on success
**           or a negative error code on failure.
**
**  @see  setRAM
**
*/

public abstract int setRAM(int address, byte data[]);



/*
**  Non-abstract functions
**
*/


/**
**  This function returns a code specifying the type of the
**  selected device.  Note that this permits mixing of device
**  types in the system.  The definitions for the device types
**  are defined as constants in the Devices class external to
**  this interface.
**
**  @param  device  This is the index of the selected device.  Note
**          that this index is zero-based.  The index of the
**          first device on a board is <em>0</em>
**
**  @return  This function returns a code giving the type of
**           device selected or a negative error code on failure.
**
**  @see getDeviceCount
**  @see getDeviceType
**
*/

public int
getDeviceType(int  device) {

   /* We must be connected to make this call */
   if (isConnected() == false)
      return (-1);

   /* Get the data if we don't have a copy yet */
   if ((deviceCount == 0) ||
      (deviceType == null)) {
      deviceType = getDeviceType();
      deviceCount = deviceType.length;
      }

   /* be sure we have a valid device index */
   if ((device < 0) || (device >= deviceCount))
      return (-2);

   return (deviceType[device]);

   }  /* end getDeviceType() */



/**
**  This function returns a code specifying the package type of
**  the selected device.  Note that this permits mixing of device
**  package types in the system.  The definitions for the package types
**  are defined as constants in Devices class external to this interface.
**
**  @param  device  This is the index of the selected device.  Note
**          that this index is zero-based.  The index of the first device
**          device on a board is <em>0</em>
**
**  @return  This function returns a code giving the type of
**           device package for the selected device or a negative
**           error code on failure.
**
**  @see getDeviceCount
**  @see getPackageType
**
*/

public int
getPackageType(int  device) {

   /* We must be connected to make this call */
   if (isConnected() == false)
      return (-1);

   /* Get the data if we don't have a copy yet */
   if ((deviceCount == 0) ||
      (pkgType == null)) {
      pkgType = getPackageType();
      deviceCount = pkgType.length;
      }

   /* be sure we have a valid device index */
   if ((device < 0) || (device >= deviceCount))
      return (-2);

   return (pkgType[device]);

   }  /* end getPackageType() */



/**
**  This function returns the number of devices on the board.  Note that
**  these devices may be of different types and packages.
**
**  @return  This function returns the number of device on the board
**           or a negative error code on failure.
**
**  @see getDeviceCount
**  @see getPackageType
**
*/

public int
getDeviceCount() {

   /* We must be connected to make this call */
   if (isConnected() == false)
      return (-1);

   /* Get the data if we don't have a copy yet */
   if (deviceCount == 0) {
      deviceType = getDeviceType();
      deviceCount = deviceType.length;
      }

   return (deviceCount);

   }  /* end getdeviceCount() */



/**
**  This function returns the width of the FPGA array.
**
**  @return  This function returns the width of the FPGA array
**           on the board or a negative error code on failure.
**
**  @see getArrayHeight
**  @see getArraySize
**
*/

public int
getArrayWidth() {

   /* We must be connected to make this call */
   if (isConnected() == false)
      return (-1);

   /* Get the data if we don't have a copy yet */
   if (arraySize == null)
      arraySize = getArraySize();

   return (arraySize[ARRAY_WIDTH]);

   }  /* end getArrayWidth() */



/**
**  This function returns the height of the FPGA array.
**
**  @return  This function returns the height of the FPGA array
**           on the board or a negative error code on failure.
**
**  @see getArrayWidth
**  @see getArraySize
**
*/

public int
getArrayHeight() {

   /* We must be connected to make this call */
   if (isConnected() == false)
      return (-1);

   /* Get the data if we don't have a copy yet */
   if (arraySize == null)
      arraySize = getArraySize();

   return (arraySize[ARRAY_HEIGHT]);

   }  /* end getArrayHeight() */




/**
**  This function is used to print the data from 
**  getSystemInfo() into a readable text string.  This
**  is used primarily for debugging and status.  This
**  function is not defined as abstract, since some
**  systems may choose not to overload it.  In this
**  case this default implementation is called.
**
**  @return  This function returns a string which may be
**           used to display the system-specific information.
**
*/

public String
getSystemInfoString() {

   return ("System information not available");

   }  /* end getSystemInfoString() */





/**
**  This is the main routine and contains simple test to verify
**  that the hardware is operational.
**
*/

public static void
main(String  args[])  {
   String  usage = "Usage:  XHWIF -<board> <infile.bit>\n"+
                   "\n"+
                   "Where board is:\n"+
                   XHWIF.SUPPORTED_SYSTEMS +
                   "\n";
   int     result;
   int     i;
   int     bits = 0;
   int     deviceCount;
   int     deviceType;
   int     port = Message.DEFAULT_PORT;
   XHWIF   board = null;
   Bitstream  downloadBs;
   Bitstream  readbackBs;
   String  systemName = "";
   String  systemNameFlag = "";
   String  bitFileName = "";
   String  remoteHostName = null;
   int     systemInfo[];
   byte    bitStream[];


   /*
   **  Parse command line parameters
   */

   if (args.length == 2) {
      systemNameFlag = args[0];
      bitFileName = args[1];
      } else {
         System.out.println(usage);
         System.exit(-1);
         }  /* end if() */

   /* Get the remote host name (if we have one) */
   remoteHostName = XHWIF.GetRemoteHostName(systemNameFlag);

   /* Get the remote port number (if we have one) */
   port = XHWIF.GetPort(systemNameFlag);

   /* Get the board XHWIF interface */
   board = XHWIF.Get(systemNameFlag);
   if (board == null) {
      System.out.println("Could not access interface to '" + systemNameFlag +
                         "' hardware.  Exiting.");
      System.exit(-2);
      }  /* end if() */



   /*
   **  Access the hardware
   */

   /* Connect to the hardware */
   result = board.connect(remoteHostName, port);
   if (result != 0) {
      System.out.println("Could not connect to hardware.  Exiting.  ("+result+")");
      System.exit(-3);
      }  /* end if() */

   /* Get the real name of the board (not the command line flag) */
   systemName = board.getName();
   System.out.println("");
   System.out.println("Connected to:  "+systemName);
   System.out.println("");

   /* Get the number of devices on the board */
   deviceCount = board.getDeviceCount();

   /* Print out system information */
   systemInfo = board.getSystemInfo();
   System.out.println(board.getSystemInfoString());

   /* Reset the board */
   System.out.println("Resetting "+systemName+" hardware.");
   System.out.println("");
   result = board.reset();
   if (result != 0) {
      System.out.println("Could not reset the hardware.  Exiting.  ("+result+")");
      result = board.disconnect();
      System.exit(-4);
      }  /* end if() */

   /* Read in the bit file */
   System.out.println("Reading in "+bitFileName+".");
   System.out.println("");
   downloadBs = new Bitstream(Devices.UNKNOWN_DEVICE);

   try {
      bits = downloadBs.read(bitFileName);
      } catch (Exception e) {
         System.out.println("Could not read in bitstream from file " +
                             bitFileName + ".  Exiting.");
         result = board.disconnect();
         System.exit(-5);
      }  /* end catch() */

   System.out.println(bits + " bits read from bitstream file "+bitFileName+".");
   downloadBs.dump();


   for (i=0; i<deviceCount; i++) {

      /* Download bitstream */
      System.out.print("Downloading bitstream to device "+i);
      result = board.setConfiguration(i, downloadBs.get());
      System.out.println("  (Done signal:  "+result+").");
      if (result < 0) {
         System.out.println("Could not download bitstream to device "+i+
                            ".  Exiting.  ("+result+")");
         result = board.disconnect();
         System.exit(-6);
         }  /* end if() */

      /* Readback Bitstream */
      System.out.println("Testing readback to device "+i+".");

      bitStream = board.getConfiguration(i);

      if (bitStream == null) {
         System.out.println("Could not readback device "+i+".  Exiting.  ("+result+")");
         result = board.disconnect();
         System.exit(-7);
      } else {
         System.out.println("Read back "+(bitStream.length*8)+" bits from device "+i+".");
         }/* end if() */

      deviceType = board.getDeviceType(i);
      readbackBs = new Bitstream(deviceType);

      try {
         readbackBs.set(bitStream);
         } catch (Exception e) {
            System.out.println("Could not set bitstream.  Exiting.");
            result = board.disconnect();
            System.exit(-8);
      }  /* end catch() */

      readbackBs.dump();
   
      }  /* end for() */


   /* Clock test */
   for (i=0; i<10; i++) {
      result = board.clockStep(1);
      if (result != 0)
         System.out.println("Error stepping clock: "+i+".");
      }


   /* Disconnect */
   result = board.disconnect();
   if (result != 0) {
      System.out.println("Could not disconnect from hardware.  Exiting.  ("+result+")");
      System.exit(-9);
      }  /* end if() */

   System.out.println("");
   System.out.println("Disconnected from "+systemName+".");
   System.out.println("");

   }  /* end main() */



};  /* end class XHWIF */



 
