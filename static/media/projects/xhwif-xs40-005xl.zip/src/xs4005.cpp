
/*
**  Filename:     xs4005.c
**  Author:       Gordon Hollingworth
**  Date:         August 27th
**  Description:  This software provides an XHWIF interface to the XS40 board
**                
*/


#include <windows.h>
#include <time.h>
#include <conio.h>


#include "xs4005.hpp"
#include "jtagport.h"
static const unsigned int posPROG = 0;
static const unsigned int posTCK = 1; // output bit	to XS board
static const unsigned int posTMS = 2; // output bit	to XS board
static const unsigned int posTDI = 3; // output bit	to XS board
static const unsigned int posTDO = 7; // input bit from XS board

#define BOUNDARY_SCAN_LENGTH 344
/* Length of chain =    2 (Bits for TDO.T and TDO.O)
					+28*3 (3 bits per IOB, 40 for top side )
					+28*3 (Left side)
					+5    (Bits for MD stuff)
					+28*3 (Bottom)
					+28*3 (Right)
					+1	 (BSCANT.UPD) */



void InsertDelay(unsigned long d)
{

	clock_t start;
	start=clock();
	while(clock()<(start+d));
	
}


/*
**  Microsoft 2.0 needs this stuff defined.  Note that is
**  is ignored by other interpreters, but Jview needs it,
**  even in DLLs it will not ever use.
**
*/

#ifndef RNIVER
#define RNIMAJORVER         2
#define RNIMINORVER         0
#define RNIVER              ((((DWORD) RNIMAJORVER) << 16) + (DWORD) RNIMINORVER)
#endif

__declspec(dllexport) DWORD __cdecl
RNIGetCompatibleVersion() {

   return (RNIVER);

   }  /* end RNIGetCompatibleVersion() */


/*
**  This function establishes communication with the device
**  driver / hardware.  It may also performs some housekeeping
**  functions.  Note that we probably don't want to do a
**  reset or disturb anything, since we may be hooking up
**  to a running system.
**
*/

JTAGPort *port;

long
Connect() {

   printf("Connect\n");
   port = new JTAGPort(1, 0x03, 0, 0x09);

   port->SetControl(1,posPROG,posPROG);
   port->SetData(0xFF);

   FlushStack();

   return (0L);

   }  /* end Connect() */




/*
**  This function disconnects from the driver / hardware.
**  This is the place to do any cleanup such as closing
**  files or drivers.
**
*/

long
Disconnect() {

   printf("Disconnect\n");

   /*delete port;*/

   return (0L);

   }  /* end Disconnect() */




/*
**  This function returns some string describing the system.
**  This function is provided for systems which return such 
**  a string as part of a hardware API.  This function provides
**  a good way to display system-dependent information and to
**  provide a "sanity check".  Note that not all systems may
**  support this function.
**
**  Note that we call this "GetSystemInformation()" rather than
**  "GetSystemInfo()" to avoid a name collision with a Windows
**  function.
**
**  Finally, note that the string data is placed one character
**  per integer array element.  While inefficient, it makes
**  things like the remote network interface easier.
**
*/

long
GetSystemInformation(int *data, long length) {
   int   i;
   const char str[] = "XS40";
   int   strLen;

   /* Get the length string */
   strLen = strlen(str) + 1;

   /* Be sure it fits in the data[] buffer */
   if (strLen > length)
      strLen = length;

   /* Copy it to data[], one char per int element */
   for (i=0; i<strLen; i++)
      data[i] = (int) (str[i] & 0x00ff);

   return (0L);
 
   }  /* end GetSystemInformation() */




/*
**  This resets the hardware.
**
*/

long
Reset() {
   printf("Reset\n");

   return (0L);

   }  /* end Reset() */




/*
**  This function turns on the clock,
**
*/

long
ClockOn() {

   return (0L);

   }  /* end ClockOn() */





/*
**  This function turns off the clock,
**
*/

long
ClockOff() {

   return (0L);

   }  /* end ClockOff() */




/*
**  This function single steps the clock.
**
*/

long
ClockStep(long  count) {
   for(int i=0;i<count;i++)
   {
	  port->SetTMS(1);
	  port->SetData(0xFF);
	  port->PulseTCK();
	  count=port->GetStatus(3,6);
   }
   FlushStack();
   return (count);

   }  /* end ClockStep() */




/*
**  This function sets the clock frequency.
**
*/

long
SetClockFrequency(float frequency) {

   return (0L);

   }  /* end SetClockFrequency() */




/*
**  This function returns a bitstream which is read back from
**  the hardware.  The <bitLength> parameter tells how many *bits*
**  to read back from the device.  The return parameter is the number
**  of bits actually read.
**
**  ***  Note that readback on the 4K device does not
**  ***  return a header, but supplies 5 "dummy" bits at
**  ***  the beginning of the bitstream.  This function
**  ***  should ignore these "dummy" bits and "fake" a download
**  ***  bitstream header of 40 bits.  This permits a bitstream
**  ***  to be readback, then manipulated like a standard bitstream
**  ***  from a file.
**
*/

long
GetConfiguration(long device,
                 unsigned char *bitstream,
                 long bitLength) {

   long dwnLoadBits; 

   bitLength-=4; /* The input value for bitLength is 4 bits too long, it's because the readback
				 ** postamble is 12 bits whereas the bitStream postamble is only 8 bits, this has
				 ** not been taken into account and MUST be correct so that the bitLength is correct
				 ** in the bitStream we return!
				 */

   /* Fake up a download header */
   bitstream[0] = 0xff;  // 11111111b
   bitstream[1] = 0x20;  // 0010____b  (reserve for length count)
   bitstream[2] = 0x00;  // ________b
   bitstream[3] = 0x00;  // ________b
   bitstream[4] = 0x0f;  // ____1111b

   /* Fill in the bit length */
   bitstream[1] = bitstream[1] | (unsigned char) ((bitLength >> 20) & 0x0f);
   bitstream[2] = bitstream[2] | (unsigned char) ((bitLength >> 12) & 0xff);
   bitstream[3] = bitstream[3] | (unsigned char) ((bitLength >> 4) & 0xff);
   bitstream[4] = bitstream[4] | (unsigned char) ((bitLength << 4) & 0xf0);

   dwnLoadBits = (bitLength -40 -8 +12); 

   /* Subtract 40 cos we don't readback header  */
   /* Subtract 8 to account for the postamble	*/
   /* Add 12 cos we read 12 bits postamble with ReadBack */


   /* Initialise the TAP port into Test-Logic-Reset state */
   port->InitTAP();

   port->GoThruTAPSequence(RunTestIdle, SelectDRScan,	SelectIRScan, CaptureIR, ShiftIR, -1);

   /* Now shift in 100b (LSB first) into the Instruction register */
   port->SetTDI(0);
   port->PulseTCK();
   port->SetTDI(0);
   port->PulseTCK();
   port->SetTMS(1);  //Must get the system into the Exit1-IR state after shifting in the last bit
   port->SetTDI(1);
   port->PulseTCK(); //State:Exit1R

   port->PulseTCK(); //State:UpdateIR
   port->SetTMS(0);
   port->PulseTCK(); //State:RunTestIdle

   port->SetTMS(1);
   port->PulseTCK(); //State:SelectDrScan
   port->SetTMS(0);
   port->PulseTCK(); //State:CaptureDR
   port->PulseTCK(); //State:ShiftDR

   /* Now we are ready to readback the bitStream, the first five bits are preamble...*/
   for(unsigned int j=0;j<5;j++)
     port->PulseTCK();

   /* Now read in the bits and pack them into bytes*/
   for(unsigned int k=7,i=0;i<dwnLoadBits;i++)
   {
	   if(k==-1) k=7;
	   if(k==7) bitstream[5+(i/8)]=0; //Just clear the original contents first
	   bitstream[5+(i/8)]+=((port->GetTDO()) << k--);
	   port->PulseTCK();
   }

   // OK, That's it! just send the TAP port back to TestLogicReset state
   port->InitTAP(); 

   /*
   ** NOTE: JBits automatically fills in the postamble code and the CRC (I assume!!)
   ** this is why it is essential to get the bitlength correct, otherwise the software
   ** will put the postamble in the wrong place!!!
   */
   FlushStack();
   return ((long) bitLength);

   }  /* end GetConfiguration() */

/*
**  This function writes a bitstream to one of the devices
**  on the board.  Note that on some boards it is possible to
**  load all devices at once, but for consistency with other
**  machines we have defined only single bitstream loads.
**  A zero is returned upon success, a negative error code on
**  failure.
*/

Bitstream in_bits(BOUNDARY_SCAN_LENGTH);
Bitstream out_bits(BOUNDARY_SCAN_LENGTH);
Bitstream instruction(3);

long
SetConfiguration(long device,
                 unsigned char *bitstream,
                 long bitLength) {

   static int firstTime = -1;

   /* 
   ** The first time around we cannot configure the 4010 chip using boundary scan, cos the
   ** bits we need to mess with are not available
   */

   /* Only one device on the XS40 board!!! */

   bitLength =  ((int)(bitstream[1] & 0x0F)) << 20;
   bitLength += ((int)bitstream[2]) << 12;
   bitLength += ((int)bitstream[3]) << 4;
   bitLength += ((int)(bitstream[4] & 0xF0)) >> 4;

   if(firstTime==-1)
   {int k;
	   /* Send the PROGRAM pin low and then back high, this starts the configuration process*/
	   port->SetControl(1,posPROG,posPROG);
	   port->SetControl(0,posPROG,posPROG);
	   port->SetControl(1,posPROG,posPROG);

	   FlushStack();
	   /* We must delay for this time, because the chip is clearing */
	   InsertDelay(100);
    
	   for(k=0;bitLength>0;bitLength-=8,k++)
	   {
		  unsigned char b=bitstream[k];
		  for(int i=0; i<8; i++)
		  {
			port->SetTDI(b&0x80 ? 1:0);  // byte is sent MSB first
			b <<= 1;
			port->PulseTCK();
		  }
	   }

	   firstTime=0;
   }
   else
   {
	   // Configure the chip using Boundary scan mode 
	   port->InitTAP(); //State:TestLogicReset

	   port->GoThruTAPSequence(RunTestIdle, SelectDRScan,	SelectIRScan, CaptureIR, ShiftIR, -1);
	   
	   // Now we are in ShiftIR state, ready to shift in instruction 101b (Configure) 
	   port->SetTDI(1);
	   port->PulseTCK();
	   port->SetTDI(0);
	   port->PulseTCK();
	   port->SetTMS(1);
	   port->SetTDI(1);
	   port->PulseTCK(); //State:Exit1R

	   port->PulseTCK(); //State:UpdateIR
	   port->SetTMS(0);
	   port->PulseTCK(); //State:RunTestIdle
	   FlushStack();

	   // Configuration clearing is now beginning, we must wait for it to finish! 
	   InsertDelay(100); // Delay in milliseconds 

       // Finally Go to Shift-DR state and shift in the configuration 

	   port->SetTMS(1);
	   port->PulseTCK();
	   port->SetTMS(0);
	   port->PulseTCK();  //Capture DR state, the system will change into shirt-dr state on the
						  //next pulse

   	   for(int k=0;bitLength>0;bitLength-=8,k++)
	   {
		  unsigned char b=bitstream[k];
		  for(int i=0; i<8; i++)
		  {
			port->SetTDI(b&0x80 ? 1:0);  // byte is sent MSB first
			b <<= 1;
			port->PulseTCK();
		  }
	   }

	   port->InitTAP();
	   FlushStack();
	   
   }

   instruction.SetBits(0, 0,0,0);
   port->LoadBSIRthenBSDR(instruction, out_bits, in_bits);
   port->InitTAP();
   FlushStack();

   return (0L);

   }  /* end SetConfiguration() */

static int input_vectors[]  = {2, 5, 14, 17, 38, 41, 56, 59, 62, 65, 80, 83, 107, 116, 119, 122}; 
static int output_vectors[] = {3,6,15,18};

long TestChip(long testvector)
{
   out_bits = in_bits;

   for(int i=0;i<16;i++)	 
     out_bits.SetBit(BOUNDARY_SCAN_LENGTH-input_vectors[i],!!(testvector & (1<<i)));
   port->LoadBSIRthenBSDR(instruction, out_bits, in_bits);
   FlushStack();
   return (in_bits[3])+(in_bits[6]<<1)+(in_bits[15]<<2)+(in_bits[18]<<3);
}
/*
**  Ths function reads on-board RAM.  Linear addressing is assumed.
**
*/

long
GetRAM(long address,
       unsigned char *data,
       long length) {

   return (0L);

   }  /* end GetRAM() */



/*
**  Ths function writes on-board RAM.  Linear addressing is assumed.
**
*/


long
SetRAM(long address,
       unsigned char *data,
       long length) {

   return (0L);

   }  /* end SetRAM() */

