

/*
**  Filename:     xs40.h
**  Author:       SAG
**  Date:         January 25, 1998
**  Description:  This file contains the function prototypes for the functions
**                in xs40.c.  See this file for more information on these
**                functions.
**
**                IT SHOULD NOT BE NECESSARY TO MODIFY THIS FILE.  IF
**                YOU ARE MODIFYING THIS FILE, BE SURE YOU KNOW WHAT
**                YOU ARE DOING!!!!
**
**
**                Copyright (c) 1999 by Xilinx
**
*/
#ifdef __cplusplus
extern "C"{
#endif
long Connect();
long Disconnect();
long GetSystemInformation(int *data, long length);
long Reset();
long ClockOn();
long ClockOff();
long ClockStep(long  count);
long SetClockFrequency(float frequency);
long GetConfiguration(long device, unsigned char *bitstream, long bitLength);
long SetConfiguration(long device, unsigned char *bitstream, long bitLength);
long TestChip(long testvector);
long GetRAM(long address, unsigned char *data, long length);
long SetRAM(long address, unsigned char *data, long length);
#ifdef __cplusplus
}
#endif