

package  com.xilinx.XHWIF.Boards;


import  java.util.*;

import  com.xilinx.XHWIF.XHWIF;
import  com.xilinx.JBits.XC4000.Devices;

/*
**  Author: Gordon Hollingworth
**
**  This file was previously the custom.java board specification, not much has changed other than
**  the 'custom' tag!
**
*/

public class xs4005 extends XHWIF {


/*
**  The parameters below define the system.  Change them
**  to suit your needs.
**
*/


/*
**  Put your system name here
*/
private static final String  systemName = "xs4005 Board";


/*
**  The height and width of the FPGA array in your system
**  (this is mostly for the GUI)
*/
private static final int  HEIGHT = 1;
private static final int  WIDTH =  1;


/*
**  Put your device types here.  Note that they don't all
**  have to be the same device type.
*/
private static final int  deviceType[] = {Devices.XC4005XL};

/*
**  Put your package types here.  Note that they don't all have
**  to be the same.  And they should correspond to the items in
**  the  deviceType[] array above.
*/  
private static final int packageType[] = {Devices.PC84};


/*
**  The names of the libraries containing the native methods.  This
**  assumes you are using three libraries to support Sun 1.0,
**  Sun 1.1, and Microsoft Java implementations.  You may wish to
**  keep the default names below, or you may want to replace the
**  "xs4005" tag with some other more meaningful name, such as the 
**  name of your system.
**
**  Note that on Windows, you shouldn't add the ".dll" suffix.
**
*/
private static final String STUBS_LIBRARY_NAME = "xs4005Stubs";
private static final String JNI_LIBRARY_NAME =   "xs4005JNI";
private static final String RNI_LIBRARY_NAME  =  "xs4005RNI";



/*
****************************************************
**                                                **
**     DO NOT MODIFY ANYTHING BELOW THIS LINE     **
**                                                **
**  (unless you *really* know what you're doing)  **
**                                                **
****************************************************
*/


private boolean connected = false;



public int
connect(String  serverName, int  port)  {
   int  result;

   /* We should only accept a server name of null */
   if (serverName != null) {
      connected = false;
      return (-10);
      }

   /* Be sure we aren't already connected */
   if (isConnected() == true)
      return (-20);

   /* Initialize the hardware */
   result = xs4005Connect();
   if (result != 0)
      return (result);

   connected = true;

   return (0);

   }  /* end connect() */



public int
disconnect() {
   int  result;

   /* Be sure we're actually connected */
   /* before we try to disconnect */
   if (isConnected() == false)
      return (-1);

   /* Disconnect the hardware */
   result = xs4005Disconnect();
   if (result != 0)
      return (-2);

   connected = false;

   return (0);

   }  /* end disconnect() */




public boolean
isConnected() {

   return (connected);

   }  /* end isConnected() */



public int
getDeviceCount() {

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   return (deviceType.length);

   }  /* end getDeviceCount() */



public String
getName() {

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (systemName);

   }  /* end getName() */



public int []
getArraySize() {
   int  config[] = {WIDTH,
                    HEIGHT};

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (config);

   }  /* end getArraySize() */





public int []
getDeviceType() {

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (deviceType);

   }  /* end getDeviceType() */



public int []
getPackageType() {

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (packageType);

   }  /* end getPackageType() */



public int [] 
getSystemInfo() {
   int  result;
   int  systemInfo[] = new int[80];

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   result = xs4005GetSystemInfo(systemInfo, systemInfo.length);

   if (result == 0)
      return (systemInfo);
   else
      return (null);

   }  /* end getSystemInfo() */




public int
reset() {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005Reset();

   return (result);

   }  /* end reset() */




public int
setClockFrequency(float frequency) {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005SetClockFrequency(frequency);

   return (result);

   }  /* end setClockFrequency() */



public int
clockOn() {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005ClockOn();

   return (result);

   }  /* end clockOn() */



public int
clockOff() {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005ClockOff();

   return (result);

   }  /* end clockOff() */




public int
clockStep(int  count) {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005ClockStep(count);

   return (result);

   }  /* end clockStep() */




public byte []
getConfiguration(int  device) {
   int   bitsRead;
   int   deviceType;
   int   readbackBits;
   int   readbackBytes;
   byte  data[];

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   /* Get the device type */
   deviceType = getDeviceType(device);

   /* Get the number of bits to read back */
   /* (less "dummy" bits, plus a header)  */
   readbackBits = Devices.getReadbackSize(deviceType) - 5 + 40;
   readbackBytes = (readbackBits + 7) / 8;

   /* Allocate the array */
   data = new byte[readbackBytes];

   /* Get the data using the native method */
   bitsRead = xs4005GetConfiguration(device, data, readbackBits);

   //System.out.println("Bits read:  "+bitsRead);

   if (bitsRead <= 0)
      return (null);

   return (data);

   }  /* end getConfiguration() */




public int
setConfiguration(int  device, byte data[]) {
   int   result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005SetConfiguration(device, data, (data.length*8));

   return (result);

   }  /* end setConfiguration() */


public int
testChip(int testVector) {
  int result;

  result = xs4005TestChip(testVector);

  return (result);
}

public byte []
getRAM(int address, int bytes) {
   int   result;
   byte  data[] = new byte[bytes];

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   /* Use the native method */
   result = xs4005GetRAM(address, data, data.length);

   if (result == 0)
      return (data);
   else
      return (null);

   }  /* end getRAM() */




public int
setRAM(int address, byte data[]) {
   int   result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = xs4005SetRAM(address, data, data.length);

   return (result);

   }  /* end setRam() */



/*
**  This routine is used to return the Pam-Specific information
**  from the getSystemInfo() call.  The string may be printed
**  to display the contents of the info data.
**
*/

public String
getSystemInfoString() {
   int  i;
   int  j;
   int  systemInfo[];
   char    tmpChars[];
   String  info;
   String  systemName;

   systemName = getName();

   systemInfo = getSystemInfo();

   if (systemInfo == null)
      return (systemName+":  No system info available.");

   /* Convert the int array into a byte array, then into a String */
   tmpChars = new char[systemInfo.length];
   for (i=0; i<systemInfo.length; i++)
      tmpChars[i] = (char) systemInfo[i];
   
   info = systemName + new String(tmpChars);

   return (info);

   }  /* end getSystemInfoString() */




/*
**  The native methods
**  (See the C code for the libraries for more information)
*/


public native int  xs4005Connect();
public native int  xs4005Disconnect();
public native int  xs4005GetSystemInfo(int data[], int length);
public native int  xs4005Reset();
public native int  xs4005SetClockFrequency(float frequency);
public native int  xs4005ClockOn();
public native int  xs4005ClockOff();
public native int  xs4005ClockStep(int count);
public native int  xs4005GetConfiguration(int device, byte data[], int  bitLength);
public native int  xs4005SetConfiguration(int device, byte data[], int  bitLength);
public native int  xs4005TestChip(int testVector);
public native int  xs4005GetRAM(int address, byte data[], int  length);
public native int  xs4005SetRAM(int address, byte data[], int  length);



/*
**  Load the libraries (two for Sun, one for Microsoft)
*/

static {


   try {
      System.loadLibrary(STUBS_LIBRARY_NAME);
      } catch (UnsatisfiedLinkError ule) {
         System.err.println("Could not load library " + STUBS_LIBRARY_NAME);
         System.err.println("UnsatisfiedLinkException: " + ule);
         System.exit(-1);
      } catch (SecurityException se) {
         System.err.println("Could not load library " + STUBS_LIBRARY_NAME);
         System.err.println("SecurityException: " + se);
         System.exit(-1);
      }  /* end try{} */


      try {
      System.loadLibrary(JNI_LIBRARY_NAME);
      } catch (UnsatisfiedLinkError ule) {
         System.err.println("Could not load library " + JNI_LIBRARY_NAME);
         System.err.println("UnsatisfiedLinkException: " + ule);
         System.exit(-1);
      } catch (SecurityException se) {
         System.err.println("Could not load library " + JNI_LIBRARY_NAME);
         System.err.println("SecurityException: " + se);
         System.exit(-1);
      }  /* end try{} */


   try {
      System.loadLibrary(RNI_LIBRARY_NAME);
      } catch (UnsatisfiedLinkError ule) {
         System.err.println("Could not load library " + RNI_LIBRARY_NAME);
         System.err.println("UnsatisfiedLinkException: " + ule);
         System.exit(-1);
      } catch (SecurityException se) {
         System.err.println("Could not load library " + RNI_LIBRARY_NAME);
         System.err.println("SecurityException: " + se);
         System.exit(-1);
      }  /* end try{} */



   }  /* end static() */





};  /* end class xs4005 */



 
