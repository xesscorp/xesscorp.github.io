
/*
**  Filename:     xs4005JNI.c
**  Author:       SAG
**  Date:         January 25, 1999
**  Description:  This provides the Sun Java 1.1 Java Native Interface (JNI)
**                interface to xs4005 hardware.
**
**                This file fills in the function prototypes created
**                by the "javah" translator.  Note that these functions
**                essentially call other more generic functions in the
**                "xs4005.c" file.  This permits the hardware-specific
**                code in "xs4005.c" to be used in the other interfaces.
**
**                IT SHOULD NOT BE NECESSARY TO MODIFY THIS FILE.  IF
**                YOU ARE MODIFYING THIS FILE, BE SURE YOU KNOW WHAT
**                YOU ARE DOING!!!!
**
**                This file is provides for example purposes only and
**                is supplies "as is".
**
**                Copyright (c) 1999 by Xilinx
**
*/


#include "xs4005JNI.h"
#include "xs4005.hpp"


JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005Connect
   (JNIEnv *env, jobject  obj) {

   return (Connect());

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005Connect() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005Disconnect
   (JNIEnv *env, jobject  obj) {

   return (Disconnect());

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005Disconnect() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005GetSystemInfo
   (JNIEnv *env, jobject  obj, jintArray  data, jint  length) {

   long   result;
   jint  *body;
   
   body = (*env)->GetIntArrayElements(env, data, 0);

   result = GetSystemInformation(body, length);

   (*env)->ReleaseIntArrayElements(env, data, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005GetSystemInfo() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005Reset
   (JNIEnv *env, jobject  obj) {

   return (Reset());

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005Reset() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005SetClockFrequency
   (JNIEnv *env, jobject  obj, jfloat frequency) {

   return (SetClockFrequency(frequency));

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005SetClockFrequency() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOn
  (JNIEnv *env, jobject  obj) {

   ClockOn();

   return (0L);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOn() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOff
   (JNIEnv *env, jobject  obj) {

   ClockOff();

   return (0L);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOff() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005ClockStep
   (JNIEnv *env, jobject  obj, jint  count) {

   return (ClockStep(count));

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005ClockStep() */



JNIEXPORT jint JNICALL 
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005SetConfiguration
   (JNIEnv *env, jobject  obj, jint  device, jbyteArray  bitstream, jint  bitLength) {

   long    result;
   jbyte  *body;
   
   body = (*env)->GetByteArrayElements(env, bitstream, 0);

   result = SetConfiguration(device, body, bitLength);

   (*env)->ReleaseByteArrayElements(env, bitstream, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005SetConfiguration() */

JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005TestChip
(JNIEnv *env, jobject obj, jint testvector) {
	return(TestChip(testvector));
}

JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005GetConfiguration
   (JNIEnv *env, jobject  obj, jint  device, jbyteArray  bitstream, jint  bitLength) {

   long    result;
   jbyte  *body;
   
   body = (*env)->GetByteArrayElements(env, bitstream, 0);

   result = GetConfiguration(device, body, bitLength);

   (*env)->ReleaseByteArrayElements(env, bitstream, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005GetConfiguration() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005SetRAM
   (JNIEnv *env, jobject  obj, jint  address, jbyteArray  data, jint  length) {

   long    result;
   jbyte  *body;
   
   body = (*env)->GetByteArrayElements(env, data, 0);

   result = SetRAM(address, body, length);

   (*env)->ReleaseByteArrayElements(env, data, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005SetRAM() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xs4005_xs4005GetRAM
   (JNIEnv *env, jobject  obj, jint  address, jbyteArray  data, jint  length) {

   long    result;
   jbyte  *body;
   
   body = (*env)->GetByteArrayElements(env, data, 0);

   result = GetRAM(address, body, length);

   (*env)->ReleaseByteArrayElements(env, data, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xs4005_xs4005GetRAM() */

