
/*
**  Filename:     xs4005RNI.c
**  Author:       SAG
**  Date:         January 25, 1999
**  Description:  This provides the Microsoft Java Raw Native Interface (RNI)
**                interface to xs4005 hardware.
**
**                This file fills in the function prototypes created
**                by the "msjavah" translator.  Note that these functions
**                essentially call other more generic functions in the
**                "xs4005.c" file.  This permits the hardware-specific
**                code in "xs4005.c" to be used in the other interfaces.
**
**                IT SHOULD NOT BE NECESSARY TO MODIFY THIS FILE.  IF
**                YOU ARE MODIFYING THIS FILE, BE SURE YOU KNOW WHAT
**                YOU ARE DOING!!!!
**
**                This file is provides for example purposes only and
**                is supplies "as is".
**
**                Copyright (c) 1999 by Xilinx
**
*/

#include <stdarg.h>

#include "xs4005RNI.h"
#include "xs4005.hpp"

__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005Connect
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h) {

   return (Connect());

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005Connect() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005Disconnect
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h) {

   return (Disconnect());

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005Disconnect() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005GetSystemInfo
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h,
    struct HArrayOfInt *data,
    long  length) {

   return (GetSystemInformation(unhand(data)->body, length));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005GetSystemInfo() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005Reset
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h) {

   return (Reset());

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005Reset() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005SetClockFrequency
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h, float  frequency) {

   return (SetClockFrequency(frequency));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005SetClockFrequency() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOn
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h) {

   ClockOn();

   return (0L);

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOn() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOff
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h) {

   ClockOff();

   return (0L);

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005ClockOff() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005ClockStep
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h, long  count) {

   return (ClockStep(count));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005ClockStep() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005SetConfiguration
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h,
    long  device,
    struct HArrayOfByte *data,
    long  bitLength) {

   return (SetConfiguration(device, unhand(data)->body, bitLength));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005SetConfiguration() */

__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005TestChip
	(struct Hcom_xilinx_XHWIF_Boards_xs4005 *h,
	long testVector) {

	return (TestChip(testVector));
}

__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005GetConfiguration
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h,
    long  device,
    struct HArrayOfByte *data,
    long  bitLength) {

   return (GetConfiguration(device, unhand(data)->body, bitLength));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005GetConfiguration() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005SetRAM
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h,
    long  address,
    struct HArrayOfByte *data,
    long  length) {

   return (SetRAM(address, unhand(data)->body, length));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005SetRAM() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xs4005_xs4005GetRAM
   (struct Hcom_xilinx_XHWIF_Boards_xs4005 *h,
    long  address,
    struct HArrayOfByte *data,
    long  length) {

   return (GetRAM(address, unhand(data)->body, length));

   }  /* end com_xilinx_XHWIF_Boards_xs4005_xs4005GetRAM() */


