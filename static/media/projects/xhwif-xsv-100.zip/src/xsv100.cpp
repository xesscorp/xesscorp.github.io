
/*
**  Filename:     xsv100.c
**  Author:       Gordon Hollingworth
**  Date:         NOT FINISHED
**  Description:  This software provides an XHWIF interface to the XSV100 board
**                
*/


#include <windows.h>
#include <time.h>
#include <conio.h>
#include <stdio.h>


#include "xsv100.hpp"
#include "pport.h"

/*
** Control bits to write to Virtex Chip
*/

static const unsigned int posPROG = 0;
static const unsigned int posCCLK = 1;
static const unsigned int posDATA = 3;

/*
** Status bits to read from Virtex Chip
*/

static const unsigned int posA0 = 3; 
static const unsigned int posA1 = 4; 
static const unsigned int posA2 = 5;
static const unsigned int posA3 = 6; 

/*
** Data bits to write to Virtex Chip (General Purpose)
*/

static const unsigned int posD0 = 0;  /* Only valid after programming */
static const unsigned int posD1 = 1;  /* the device */
static const unsigned int posD2 = 2;
static const unsigned int posD3 = 3;
static const unsigned int posD4 = 4;
static const unsigned int posD5 = 5;
static const unsigned int posD6 = 6;
static const unsigned int posD7 = 7;


void InsertDelay(clock_t d)
{

	clock_t start;
	start=clock();
	while(clock()<(start+d));
	
}


/*
**  Microsoft 2.0 needs this stuff defined.  Note that is
**  is ignored by other interpreters, but Jview needs it,
**  even in DLLs it will not ever use.
**
*/

#ifndef RNIVER
#define RNIMAJORVER         2
#define RNIMINORVER         0
#define RNIVER              ((((DWORD) RNIMAJORVER) << 16) + (DWORD) RNIMINORVER)
#endif

__declspec(dllexport) DWORD __cdecl
RNIGetCompatibleVersion() {

   return (RNIVER);

   }  /* end RNIGetCompatibleVersion() */


/*
**  This function establishes communication with the device
**  driver / hardware.  It may also performs some housekeeping
**  functions.  Note that we probably don't want to do a
**  reset or disturb anything, since we may be hooking up
**  to a running system.
**
*/

Pport *port;

long
Connect() {

   printf("Connecting to Virtex Board\n");
   port = new Pport(1, 0x03, 0, 0x09); /* 1 = parallel port number
				       ** 3 = data register invert mask
				       ** 0 = status register invert mask
				       ** 9 = control register invert mask
				       */

   port->SetControl(1,posPROG,posPROG);
   port->SetControl(0,posCCLK,posCCLK);
   port->SetData(0xFF);

   FlushStack();

   return (0L);

   }  /* end Connect() */




/*
**  This function disconnects from the driver / hardware.
**  This is the place to do any cleanup such as closing
**  files or drivers.
**
*/

long
Disconnect() {

   printf("Disconnect\n");

   return (0L);

   }  /* end Disconnect() */




/*
**  This function returns some string describing the system.
**  This function is provided for systems which return such 
**  a string as part of a hardware API.  This function provides
**  a good way to display system-dependent information and to
**  provide a "sanity check".  Note that not all systems may
**  support this function.
**
**  Note that we call this "GetSystemInformation()" rather than
**  "GetSystemInfo()" to avoid a name collision with a Windows
**  function.
**
**  Finally, note that the string data is placed one character
**  per integer array element.  While inefficient, it makes
**  things like the remote network interface easier.
**
*/

long
GetSystemInformation(int *data, long length) {
   int   i;
   const char str[] = "xsv100";
   int   strLen;

   /* Get the length string */
   strLen = strlen(str) + 1;

   /* Be sure it fits in the data[] buffer */
   if (strLen > length)
      strLen = length;

   /* Copy it to data[], one char per int element */
   for (i=0; i<strLen; i++)
      data[i] = (int) (str[i] & 0x00ff);

   return (0L);
 
   }  /* end GetSystemInformation() */




/*
**  This resets the hardware.
**
*/

long
Reset() {
   printf("Reset\n");

   return (0L);

   }  /* end Reset() */




/*
**  This function turns on the clock,
**
*/

long
ClockOn() {

   return (0L);

   }  /* end ClockOn() */





/*
**  This function turns off the clock,
**
*/

long
ClockOff() {

   return (0L);

   }  /* end ClockOff() */




/*
**  This function single steps the clock.
**
*/

long
ClockStep(long  count) {

   return (count);

   }  /* end ClockStep() */




/*
**  This function sets the clock frequency.
**
*/

long
SetClockFrequency(float frequency) {

   return (0L);

   }  /* end SetClockFrequency() */




/*
**  This function returns a bitstream which is read back from
**  the hardware.  The <bitLength> parameter tells how many *bits*
**  to read back from the device.  The return parameter is the number
**  of bits actually read.
**
**  ***  Note that readback on the 4K device does not
**  ***  return a header, but supplies 5 "dummy" bits at
**  ***  the beginning of the bitstream.  This function
**  ***  should ignore these "dummy" bits and "fake" a download
**  ***  bitstream header of 40 bits.  This permits a bitstream
**  ***  to be readback, then manipulated like a standard bitstream
**  ***  from a file.
**
*/

long
GetConfiguration(long device,
                 unsigned char *bitstream,
                 long bitLength) {

/* 
** This is currently impossible to implement because the access to the card
** is serial slave mode, it would have to be changed to SelectMAP to enable
** Readback...
*/

   return ((long) bitLength);

   }  /* end GetConfiguration() */

/*
**  This function writes a bitstream to one of the devices
**  on the board.  Note that on some boards it is possible to
**  load all devices at once, but for consistency with other
**  machines we have defined only single bitstream loads.
**  A zero is returned upon success, a negative error code on
**  failure.
*/

long
SetConfiguration(long device,
                 unsigned char *bitstream,
                 long bitLength) {

   /* Only one device on the XSV100 board!!! */

   /* Send the PROGRAM pin low and then back high, this starts the configuration process*/
   port->SetControl(1,posPROG,posPROG);
   port->SetControl(0,posPROG,posPROG);
   port->SetControl(1,posPROG,posPROG);

   FlushStack();
   /* We must delay for this time, because the chip is clearing */
   InsertDelay(100);
    
   for(int k=0;bitLength>0;bitLength-=8,k++)
   {
	  unsigned char b=bitstream[k];
	  for(int i=0; i<8; i++)
	  {
		port->SetControl(b&0x80 ? 1:0, posDATA, posDATA);  // byte is sent MSB first
		b <<= 1;
		port->SetControl(1, posCCLK, posCCLK);
		port->SetControl(0, posCCLK, posCCLK);
	  }
   }

   FlushStack();

   return (0L);

   }  /* end SetConfiguration() */


/*
**  Ths function reads on-board RAM.  Linear addressing is assumed.
**
*/

long
GetRAM(long address,
       unsigned char *data,
       long length) {

   return (0L);

   }  /* end GetRAM() */



/*
**  Ths function writes on-board RAM.  Linear addressing is assumed.
**
*/


long
SetRAM(long address,
       unsigned char *data,
       long length) {

   return (0L);

   }  /* end SetRAM() */

