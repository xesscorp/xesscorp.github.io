#ifdef __cplusplus
extern "C" {
#endif

long
Connect();

long
Disconnect();

long
GetSystemInformation(long *data, long length);

long
Reset();

long
ClockOn();

long
ClockOff();

long
ClockStep(long  count);

long
SetClockFrequency(float frequency);


long
GetConfiguration(long device,
                 unsigned char *bitstream,
                 long bitLength);

long
SetConfiguration(long device,
                 unsigned char *bitstream,
                 long bitLength);

long
GetRAM(long address,
       unsigned char *data,
       long length);

long
SetRAM(long address,
       unsigned char *data,
       long length); 

#ifdef __cplusplus
}
#endif
