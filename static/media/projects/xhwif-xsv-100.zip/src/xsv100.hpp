

/*
**  Filename:     xsv100.h
**  Author:       Gordon Hollingworth
**  Date:         January 25, 1998
**  Description:  This file contains the function prototypes for the functions
**                in xsv100.c.  See this file for more information on these
**                functions.
**
*/
#ifdef __cplusplus
extern "C"{
#endif
long Connect();
long Disconnect();
long GetSystemInformation(int *data, long length);
long Reset();
long ClockOn();
long ClockOff();
long ClockStep(long  count);
long SetClockFrequency(float frequency);
long GetConfiguration(long device, unsigned char *bitstream, long bitLength);
long SetConfiguration(long device, unsigned char *bitstream, long bitLength);
long TestChip(long testvector);
long GetRAM(long address, unsigned char *data, long length);
long SetRAM(long address, unsigned char *data, long length);
#ifdef __cplusplus
}
#endif