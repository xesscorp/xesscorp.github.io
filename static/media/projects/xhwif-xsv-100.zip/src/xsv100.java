
package  com.xilinx.XHWIF.Boards;


import  java.util.*;

import  com.xilinx.XHWIF.XHWIF;
import  com.xilinx.JBits.Virtex.Devices;

/*
**  Author: Gordon Hollingworth
*/

public class xsv100 extends XHWIF {

/*
**  Put your system name here
*/
private static final String  systemName = "xsv100 Board";


/*
**  The height and width of the FPGA array in your system
**  (this is mostly for the GUI)
*/
private static final int  HEIGHT = 1;
private static final int  WIDTH =  1;


/*
**  Put your device types here.  Note that they don't all
**  have to be the same device type.
*/
private static final int  deviceType[] = {Devices.XCV100};

/*
**  Put your package types here.  Note that they don't all have
**  to be the same.  And they should correspond to the items in
**  the  deviceType[] array above.
*/  
private static final int packageType[] = {Devices.PQ240};


private static final String STUBS_LIBRARY_NAME = "xsv100JNI";
private static final String JNI_LIBRARY_NAME =   "xsv100JNI";
private static final String RNI_LIBRARY_NAME  =  "xsv100JNI";



/*
****************************************************
**                                                **
**     DO NOT MODIFY ANYTHING BELOW THIS LINE     **
**                                                **
**  (unless you *really* know what you're doing)  **
**                                                **
****************************************************
*/


private boolean connected = false;



public int
connect(String  serverName, int  port)  {
   int  result;

   /* We should only accept a server name of null */
   if (serverName != null) {
      connected = false;
      return (-10);
      }

   /* Be sure we aren't already connected */
   if (isConnected() == true)
      return (-20);

   /* Initialize the hardware */
   result = Connect();
   if (result != 0)
      return (result);

   connected = true;

   return (0);

   }  /* end connect() */



public int
disconnect() {
   int  result;

   /* Be sure we're actually connected */
   /* before we try to disconnect */
   if (isConnected() == false)
      return (-1);

   /* Disconnect the hardware */
   result = Disconnect();
   if (result != 0)
      return (-2);

   connected = false;

   return (0);

   }  /* end disconnect() */




public boolean
isConnected() {

   return (connected);

   }  /* end isConnected() */



public int
getDeviceCount() {

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   return (deviceType.length);

   }  /* end getDeviceCount() */



public String
getName() {

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (systemName);

   }  /* end getName() */



public int []
getArraySize() {
   int  config[] = {WIDTH,
                    HEIGHT};

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (config);

   }  /* end getArraySize() */





public int []
getDeviceType() {

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (deviceType);

   }  /* end getDeviceType() */



public int []
getPackageType() {

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   return (packageType);

   }  /* end getPackageType() */



public int [] 
getSystemInfo() {
   int  result;
   int  systemInfo[] = new int[80];

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   result = GetSystemInfo(systemInfo, systemInfo.length);

   if (result == 0)
      return (systemInfo);
   else
      return (null);

   }  /* end getSystemInfo() */




public int
reset() {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = Reset();

   return (result);

   }  /* end reset() */




public int
setClockFrequency(float frequency) {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = SetClockFrequency(frequency);

   return (result);

   }  /* end setClockFrequency() */



public int
clockOn() {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = ClockOn();

   return (result);

   }  /* end clockOn() */



public int
clockOff() {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = ClockOff();

   return (result);

   }  /* end clockOff() */




public int
clockStep(int  count) {
   int  result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = ClockStep(count);

   return (result);

   }  /* end clockStep() */




public byte []
getConfiguration(int  device, int byteCount) {
   int   bitsRead;
   int   deviceType;
   int   readbackBits;
   int   readbackBytes;
   byte  data[];

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   /* Allocate the array */
   data = new byte[byteCount];

   /* Get the data using the native method */
   bitsRead = GetConfiguration(device, data, byteCount);

   if (bitsRead <= 0)
      return (null);

   return (data);

   }  /* end getConfiguration() */




public int
setConfiguration(int  device, byte data[]) {
   int   result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = SetConfiguration(device, data, (data.length*8));

   return (result);

   }  /* end setConfiguration() */


public byte []
getRAM(int address, int bytes) {
   int   result;
   byte  data[] = new byte[bytes];

   /* Be sure we are connected */
   if (connected == false)
      return (null);

   /* Use the native method */
   result = GetRAM(address, data, data.length);

   if (result == 0)
      return (data);
   else
      return (null);

   }  /* end getRAM() */




public int
setRAM(int address, byte data[]) {
   int   result;

   /* Be sure we are connected */
   if (connected == false)
      return (-1);

   /* Use the native method */
   result = SetRAM(address, data, data.length);

   return (result);

   }  /* end setRam() */



/*
**  This routine is used to return the Pam-Specific information
**  from the getSystemInfo() call.  The string may be printed
**  to display the contents of the info data.
**
*/

public String
getSystemInfoString() {
   int  i;
   int  j;
   int  systemInfo[];
   char    tmpChars[];
   String  info;
   String  systemName;

   systemName = getName();

   systemInfo = getSystemInfo();

   if (systemInfo == null)
      return (systemName+":  No system info available.");

   /* Convert the int array into a byte array, then into a String */
   tmpChars = new char[systemInfo.length];
   for (i=0; i<systemInfo.length; i++)
      tmpChars[i] = (char) systemInfo[i];
   
   info = systemName + new String(tmpChars);

   return (info);

   }  /* end getSystemInfoString() */




/*
**  The native methods
**  (See the C code for the libraries for more information)
*/


public native int  Connect();
public native int  Disconnect();
public native int  GetSystemInfo(int data[], int length);
public native int  Reset();
public native int  SetClockFrequency(float frequency);
public native int  ClockOn();
public native int  ClockOff();
public native int  ClockStep(int count);
public native int  GetConfiguration(int device, byte data[], int  bitLength);
public native int  SetConfiguration(int device, byte data[], int  bitLength);
public native int  GetRAM(int address, byte data[], int  length);
public native int  SetRAM(int address, byte data[], int  length);



/*
**  Load the libraries (two for Sun, one for Microsoft)
*/

static {


   try {
      System.loadLibrary(STUBS_LIBRARY_NAME);
      } catch (UnsatisfiedLinkError ule) {
         System.err.println("Could not load library " + STUBS_LIBRARY_NAME);
         System.err.println("UnsatisfiedLinkException: " + ule);
         System.exit(-1);
      } catch (SecurityException se) {
         System.err.println("Could not load library " + STUBS_LIBRARY_NAME);
         System.err.println("SecurityException: " + se);
         System.exit(-1);
      }  /* end try{} */


      try {
      System.loadLibrary(JNI_LIBRARY_NAME);
      } catch (UnsatisfiedLinkError ule) {
         System.err.println("Could not load library " + JNI_LIBRARY_NAME);
         System.err.println("UnsatisfiedLinkException: " + ule);
         System.exit(-1);
      } catch (SecurityException se) {
         System.err.println("Could not load library " + JNI_LIBRARY_NAME);
         System.err.println("SecurityException: " + se);
         System.exit(-1);
      }  /* end try{} */


   try {
      System.loadLibrary(RNI_LIBRARY_NAME);
      } catch (UnsatisfiedLinkError ule) {
         System.err.println("Could not load library " + RNI_LIBRARY_NAME);
         System.err.println("UnsatisfiedLinkException: " + ule);
         System.exit(-1);
      } catch (SecurityException se) {
         System.err.println("Could not load library " + RNI_LIBRARY_NAME);
         System.err.println("SecurityException: " + se);
         System.exit(-1);
      }  /* end try{} */



   }  /* end static() */





};  /* end class xs4005 */



 
