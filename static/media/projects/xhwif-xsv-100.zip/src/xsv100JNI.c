
/*
**  Filename:     xsv100JNI.c
**  Author:       SAG
**  Date:         January 25, 1999
**  Description:  This provides the Sun Java 1.1 Java Native Interface (JNI)
**                interface to xsv100 hardware.
**
**                This file fills in the function prototypes created
**                by the "javah" translator.  Note that these functions
**                essentially call other more generic functions in the
**                "xsv100.c" file.  This permits the hardware-specific
**                code in "xsv100.c" to be used in the other interfaces.
**
**                IT SHOULD NOT BE NECESSARY TO MODIFY THIS FILE.  IF
**                YOU ARE MODIFYING THIS FILE, BE SURE YOU KNOW WHAT
**                YOU ARE DOING!!!!
**
**                This file is provides for example purposes only and
**                is supplies "as is".
**
**                Copyright (c) 1999 by Xilinx
**
*/


#include "xsv100JNI.h"
#include "xsv100.h"


JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_Connect
   (JNIEnv *env, jobject  obj) {

   return (Connect());

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_Connect() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_Disconnect
   (JNIEnv *env, jobject  obj) {

   return (Disconnect());

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_Disconnect() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_GetSystemInfo
   (JNIEnv *env, jobject  obj, jintArray  data, jint  length) {

   long   result;
   jint  *body;

   body = (*env)->GetIntArrayElements(env, data, 0);

   result = GetSystemInformation(body, length);

   (*env)->ReleaseIntArrayElements(env, data, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_GetSystemInfo() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_Reset
   (JNIEnv *env, jobject  obj) {

   return (Reset());

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_Reset() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_SetClockFrequency
   (JNIEnv *env, jobject  obj, jfloat frequency) {

   return (SetClockFrequency(frequency));

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_SetClockFrequency() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_ClockOn
  (JNIEnv *env, jobject  obj) {

   ClockOn();

   return (0L);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_ClockOn() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_ClockOff
   (JNIEnv *env, jobject  obj) {

   ClockOff();

   return (0L);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_ClockOff() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_ClockStep
   (JNIEnv *env, jobject  obj, jint  count) {

   return (ClockStep(count));

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_ClockStep() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_SetConfiguration
   (JNIEnv *env, jobject  obj, jint  device, jbyteArray  bitstream, jint  bitLength) {

   long    result;
   jbyte  *body;

   body = (*env)->GetByteArrayElements(env, bitstream, 0);

   result = SetConfiguration(device, body, bitLength);

   (*env)->ReleaseByteArrayElements(env, bitstream, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_SetConfiguration() */


JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_GetConfiguration
   (JNIEnv *env, jobject  obj, jint  device, jbyteArray  bitstream, jint  bitLength) {

   long    result;
   jbyte  *body;

   body = (*env)->GetByteArrayElements(env, bitstream, 0);

   result = GetConfiguration(device, body, bitLength);

   (*env)->ReleaseByteArrayElements(env, bitstream, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_GetConfiguration() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_etRAM
   (JNIEnv *env, jobject  obj, jint  address, jbyteArray  data, jint  length) {

   long    result;
   jbyte  *body;

   body = (*env)->GetByteArrayElements(env, data, 0);

   result = SetRAM(address, body, length);

   (*env)->ReleaseByteArrayElements(env, data, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_SetRAM() */



JNIEXPORT jint JNICALL
Java_com_xilinx_XHWIF_Boards_xsv100_GetRAM
   (JNIEnv *env, jobject  obj, jint  address, jbyteArray  data, jint  length) {

   long    result;
   jbyte  *body;

   body = (*env)->GetByteArrayElements(env, data, 0);

   result = GetRAM(address, body, length);

   (*env)->ReleaseByteArrayElements(env, data, body, 0);

   return (result);

   }  /* end Java_com_xilinx_XHWIF_Boards_xsv100_GetRAM() */

