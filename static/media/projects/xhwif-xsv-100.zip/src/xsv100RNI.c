
/*
**  Filename:     xsv100RNI.c
**  Author:       SAG
**  Date:         January 25, 1999
**  Description:  This provides the Microsoft Java Raw Native Interface (RNI)
**                interface to xsv100 hardware.
**
**                This file fills in the function prototypes created
**                by the "msjavah" translator.  Note that these functions
**                essentially call other more generic functions in the
**                "xsv100.c" file.  This permits the hardware-specific
**                code in "xsv100.c" to be used in the other interfaces.
**
**                IT SHOULD NOT BE NECESSARY TO MODIFY THIS FILE.  IF
**                YOU ARE MODIFYING THIS FILE, BE SURE YOU KNOW WHAT
**                YOU ARE DOING!!!!
**
**                This file is provides for example purposes only and
**                is supplies "as is".
**
**                Copyright (c) 1999 by Xilinx
**
*/

#include <stdarg.h>

#include "xsv100RNI.h"
#include "xsv100.hpp"

__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_Connect
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h) {

   return (Connect());

   }  /* end com_xilinx_XHWIF_Boards_xsv100_Connect() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_Disconnect
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h) {

   return (Disconnect());

   }  /* end com_xilinx_XHWIF_Boards_xsv100_Disconnect() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_GetSystemInfo
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h,
    struct HArrayOfInt *data,
    long  length) {

   return (GetSystemInformation(unhand(data)->body, length));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_GetSystemInfo() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_Reset
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h) {

   return (Reset());

   }  /* end com_xilinx_XHWIF_Boards_xsv100_Reset() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_SetClockFrequency
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h, float  frequency) {

   return (SetClockFrequency(frequency));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_SetClockFrequency() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_ClockOn
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h) {

   ClockOn();

   return (0L);

   }  /* end com_xilinx_XHWIF_Boards_xsv100_ClockOn() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_ClockOff
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h) {

   ClockOff();

   return (0L);

   }  /* end com_xilinx_XHWIF_Boards_xsv100_ClockOff() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_ClockStep
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h, long  count) {

   return (ClockStep(count));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_ClockStep() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_SetConfiguration
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h,
    long  device,
    struct HArrayOfByte *data,
    long  bitLength) {

   return (SetConfiguration(device, unhand(data)->body, bitLength));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_SetConfiguration() */

__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_GetConfiguration
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h,
    long  device,
    struct HArrayOfByte *data,
    long  bitLength) {

   return (GetConfiguration(device, unhand(data)->body, bitLength));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_GetConfiguration() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_SetRAM
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h,
    long  address,
    struct HArrayOfByte *data,
    long  length) {

   return (SetRAM(address, unhand(data)->body, length));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_SetRAM() */



__declspec(dllexport) long __cdecl
com_xilinx_XHWIF_Boards_xsv100_GetRAM
   (struct Hcom_xilinx_XHWIF_Boards_xsv100 *h,
    long  address,
    struct HArrayOfByte *data,
    long  length) {

   return (GetRAM(address, unhand(data)->body, length));

   }  /* end com_xilinx_XHWIF_Boards_xsv100_GetRAM() */


