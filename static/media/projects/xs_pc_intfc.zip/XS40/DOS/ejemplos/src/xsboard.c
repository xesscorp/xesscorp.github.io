





/*
Assignment of port signals to FPGA controls:

Signal   VHDL Design Pin XC4010XL      COMMENTS
D0(pin2)  DIN(0)          p44         On Board Inverted
D1(pin3)  DIN(1)          p45         On Board Inverted
D2(pin4)  DIN(2)          p46
D3(pin5)  DIN(3)          p47
D4(pin6)  DIN(4)          p48
D5(pin7)  DIN(5)          p49
D6(pin8)  DIN(6)          p32             pin M0
D7(pin9)  DIN(7)          p34             pin M2

C0(STROBE) Do not touch. Must be permanent LOW!! Yuyu signal.
C1(AUTOF)  RST 			  p16			pin TCK; Port and On Board Inverted
C2(INIT)	  READB          p17             pin TMS
C3(SELIN)  WRITEB			  p15			pin TDI; Port Inverted

S3(ERROR)  DOUT(0)        p70
S4(SEL)    DOUT(1)        p77
S5(PEND)   DOUT(2)        p66
S6(ACK)    DOUT(3)        p69
S7(BUSY)*  NIBBLE         p75       pin TDO, Port and On Board Inverted
This signal is not used in this sample but implemented

PROTOCOL:
Due to the Inversions the Inactive STATE is C1,C3 LOW and C2 HIGH

Reset is active HIGH.

WRITE Cycle:
    1.- Write Data on Byte D
    2.- WRITEB goes to LOW, say, C3 goes to HIGH.
    3.- C3 goes to LOW

ADDRESS Write Cycle:
	 1.- Write Address on Byte D
    2.- WRITEB and READB goes to LOW simultaneously, say, C3 goes to HIGH
    and C1 goes to LOW.
    3.- C3 goes to LOW and C1 goes to HIGH.

READ Cycle is implemented in two steps:
	1.- In the first step READB goes LOW, say, C2 goes LOW.
   2.- C2 goes HIGH.
   3.- Read Lower Nibble and SHIFT Right one Byte
   4.- In the first step READB goes LOW, say, C2 goes LOW.
   5.- C2 goes HIGH.
   6.- Read Upper Nibble and SHIFT left three Bytes

*/

unsigned PortD;
unsigned PortS;
unsigned PortC;

unsigned char RegDato;
unsigned char RegAddr;
unsigned char RegCtrl;
unsigned char RegStat;

void DlPortWritePortUchar(unsigned short port,unsigned char value)
{

	 __asm__ __volatile__ ("outb %b0,%w1"
			       : /* no outputs */
			       :"a" (value),"d" (port));
}
   
   
unsigned char DlPortReadPortUchar(unsigned short port)
      {
	         unsigned int _v;
	 __asm__ __volatile__ ("inb %w1,%b0"
			       :"=a" (_v):"d" (port),"0" (0));
	         return _v;
      }
   


void xsinit(unsigned Base)
{
   PortD=Base;
   PortC=Base+2;
   PortS=Base+1;
#ifdef __linux__
   ioperm(Base,3,1);
   setreuid(getuid(),getuid());
#endif   
}

void xsreset(void)
{   
   RegCtrl = 0x00;  //00000110
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x06;
   DlPortWritePortUchar(PortC, RegCtrl);
   usleep(10000);
   RegCtrl= 0x00;
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x00 ^0x03;
   DlPortWritePortUchar(PortD, RegCtrl);   

}

unsigned char xsread(unsigned dir)
{
   unsigned char kk1, kk2;
   
   RegAddr=dir ^ 0x03; //Due to the on board Inverters
   DlPortWritePortUchar(PortD, RegAddr);
   RegCtrl= 0x08;
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x04;
   DlPortWritePortUchar(PortC, RegCtrl);


   RegCtrl= 0x00;
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x04;
   DlPortWritePortUchar(PortC, RegCtrl);
   kk1 = DlPortReadPortUchar(PortS);
   RegCtrl= 0x00;
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x04;
   DlPortWritePortUchar(PortC, RegCtrl);
   kk2 = DlPortReadPortUchar(PortS);
   kk1=(kk1 >> 3) & 0x0F;
   kk2=(kk2 << 1) & 0xF0;

   return (kk1 | kk2);
}

void  xswrite(unsigned dir, unsigned char data)
{
   RegDato=data ^ 0x03;  //Due to the on board Inverters
   RegAddr=dir ^ 0x03;  //Due to the on board Inverters

   //write direction
   DlPortWritePortUchar(PortD, RegAddr);
   RegCtrl= 0x08;
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x04;
   DlPortWritePortUchar(PortC, RegCtrl);

   //write data
   DlPortWritePortUchar(PortD, RegDato);
   RegCtrl= 0x0C;
   DlPortWritePortUchar(PortC, RegCtrl);
   RegCtrl= 0x04;
   DlPortWritePortUchar(PortC, RegCtrl);
}





