extern void xsinit(unsigned Base);
extern unsigned char xsread(unsigned dir);
extern void  xswrite(unsigned dir, unsigned char data);
extern void  xsreset(void);
