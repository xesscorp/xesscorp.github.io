
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xsboard.h"


void Usage(void);


int
main(int argc, char* argv[])
{
   int i, dir, data;
   int noreturn = 0;
   char *pf_format = "%d";   
   FILE *Fptr;
   char buf[1024];

   /* On unix drop root before playing with options */
   xsinit(0x378);
   
   if (argc != 2 )
     Usage();

   if ((Fptr = fopen(argv[1], "r")) == NULL)
     Usage();


   while (fgets(buf, 1024, Fptr)) 
      {
	 char *argvs[6];
	 int i, argcs;
	 
	 argcs=1;
	 argvs[0] = strtok(buf," 	");
	 while (argvs[argcs] = strtok(NULL," 	\n\r"))
           argcs++;
	 
	 
	    switch (argvs[0][0]) {
	     case 'w':
	     case 'W':	       
	       if (argcs == 4) {
		  dir = atoi(argvs[2]);
		  switch (argvs[1][1])
		     {
		      case 'a':
			data=(int) argvs[3][0];
			break;
		      case 'x':
			sscanf(argvs[3],"%x", &data);
			break;
		      default:
			Usage();
		     }
	       } else {
		  dir = atoi(argvs[1]);
		  data = atoi(argvs[2]);
	       }
	       if (data > 255)
		 Usage();
	       xswrite (dir, data);
	       break;
	     case 'r':
	     case 'R':	       
	       dir = atoi(argvs[argcs-1]);
	       data=xsread(dir);
	       i=1;
	       
	       while (i < argcs-1) {
		  switch (argvs[i][1])
		     {
		      case 'a':
			pf_format = "%c";
			break;
		      case 'x':
			pf_format = "%X";
			break;
		      case 'n':
			noreturn=1;
			break;
		      default:
			Usage();
		     }
		  i++;
	       }
	       
	       printf(pf_format, data);
	       if (!noreturn)
		 printf("\n");
	       break;
	     case 'p':
	     case 'P':	       
	       if (argcs == 4) {
		  dir = atoi(argvs[2]);
		  switch (argvs[1][1])
		     {
		      case 'a':
			data=(int) argvs[3][0];
			break;
		      case 'x':
			sscanf(argvs[3],"%x", &data);
			break;
		      default:
			Usage();
		     }
	       } else {
		  dir = atoi(argvs[1]);
		  data = atoi(argvs[2]);
	       }

	       if (data > 255)
		 Usage();

	       while (xsread(dir) != data)
		 usleep(1000); // ALGO SIMILAR
	       
	       break;
	     default:
	       Usage();
	    }
      }
}
   


void
Usage(void)
{
   fprintf(stderr, "Usage: xsfile FILE\n");
   fprintf(stderr, "each line of FILE is:\n");   
   fprintf(stderr, "[w|r|p] [option] DIR [DATA]\n");
   fprintf(stderr, "  w xswrite syntax\n");   
   fprintf(stderr, "  r xsread syntax\n");      
   fprintf(stderr, "  p xspoll syntax\n");         
   
   exit (1);
}
