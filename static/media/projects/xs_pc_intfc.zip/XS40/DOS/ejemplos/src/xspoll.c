

#include <stdio.h>
#include <stdlib.h>
#include "xsboard.h"

void Usage(void);

int
main(int argc, char* argv[])
{
   int dir, data;

   /* On unix drop root before playing with options */
   xsinit(0x378);
   
   if (argc < 3 || argc > 4)
     Usage();
   
   if (argc == 4) {
      dir = atoi(argv[2]);
      switch (argv[1][1])
	 {
	  case 'a':
	    data=(int) argv[3][0];
	    break;
	  case 'x':
	    sscanf(argv[3],"%x", &data);
	    break;
	  default:
	    Usage();
	 }
   } else {
      dir = atoi(argv[1]);
      data = atoi(argv[2]);
   }

   if (data > 255)
     Usage();


   while (xsread(dir) != data)
     usleep(1000); // ALGO SIMILAR

}
     
	    
     
   


void
Usage(void)
{
   fprintf(stderr, "Usage: xswrite [-a|-x] DIR DATA\n");
   fprintf(stderr, "      -a DATA is ASCII\n");   
   fprintf(stderr, "      -x DATA is HEX\n");
   fprintf(stderr, "      DATA is range 0 to 255\n");   
   exit (1);
}
