

#include <stdio.h>
#include <stdlib.h>
#include "xsboard.h"

void Usage(void);


int
main(int argc, char* argv[])
{
   int i, dir, data;
   int noreturn = 0;
   char *pf_format = "%d";

   /* On unix drop root before playing with options */
   xsinit(0x378);
   
   if (argc < 2 || argc > 4)
     Usage();
   
   dir = atoi(argv[argc-1]);

   data=xsread(dir);
   i=1;
   
   while (i < argc-1) {
         switch (argv[i][1])
	 {
	  case 'a':
	    pf_format = "%c";
	    break;
	  case 'x':
	    pf_format = "%X";
	    break;
	  case 'n':
	    noreturn=1;
	    break;
	  default:
	    Usage();
	 }
      i++;
   }

   printf(pf_format, data);
   if (!noreturn)
      printf("\n");
}
     
	    
     
   


void
Usage(void)
{
   fprintf(stderr, "Usage: xsread [-n][-a|-x] DIR\n");
   fprintf(stderr, "      -a DATA is read as ASCII\n");   
   fprintf(stderr, "      -x DATA is read as HEX\n");
   fprintf(stderr, "      -n no return\n");   
   exit (1);
}
