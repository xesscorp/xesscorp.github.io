

#include <stdio.h>
#include <stdlib.h>
#include "xsboard.h"

void Usage(void);


int
main(int argc, char* argv[])
{
   xsinit(0x378);
   
   if (argc != 1)
     Usage();
   
   xsreset();
}
     
	    
     
   


void
Usage(void)
{
   fprintf(stderr, "Usage: xsreset\n");
   fprintf(stderr, "      Send reset signal to FPGA\n");   
   exit (1);
}
