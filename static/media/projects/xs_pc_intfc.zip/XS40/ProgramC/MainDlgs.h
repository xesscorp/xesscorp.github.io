#define IDM_MENU1 1
#define IDI_ICON1 3
#define IDI_ICON2 2
#define ID_UNUSED 101
#define ID_EXIT   108
#define CM_ABOUT   18873
#define IDD_ABOUT   1
#define CM_WRITEREAD 501
#define CM_RDFILEADDR 516
#define CM_RDFILEPOLL 517
#define CM_WRFILEAD   518
#define CM_WRFILED    519
#define CM_RNDRDWR    520

