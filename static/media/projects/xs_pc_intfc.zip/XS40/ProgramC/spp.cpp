#include <owl\pch.h>
#include <owl\window.h>
#include <owl/applicat.h>
#include <owl/framewin.h>
#include <owl/decmdifr.h>
#include <owl\button.h>
#include <owl\checkbox.h>
#include <owl\edit.h>
#include <owl/dc.h>
#include <owl/opensave.h>
#include <stdio.h>
#include <string.h>
#include <process.h>
#include <dir.h>
#include <time.h>

#include "xsboarddlg.h"
#include "xsboard.h"
#include "spp.h"
#include "MainDlgs.h"
#define IDD_RDWR     400
//TDecoratedMDIFrame *fw;
DEFINE_RESPONSE_TABLE1(TWinSpp,TWindow)
	EV_COMMAND(ID_UNUSED,Unused),
	EV_COMMAND(CM_ABOUT,About),
	EV_COMMAND(ID_EXIT,Exit),
   EV_COMMAND(CM_WRITEREAD,WriteRead),
   EV_COMMAND(CM_RDFILEADDR,ReadFileAddr),
   EV_COMMAND(CM_RDFILEPOLL,ReadFilePoll),
   EV_COMMAND(CM_WRFILED,WriteFileData),
   EV_COMMAND(CM_WRFILEAD,WriteFileAddrData),
   EV_COMMAND(CM_RNDRDWR,RandomReadWrite),
END_RESPONSE_TABLE;
TWinSpp::TWinSpp(TWindow *parent):TWindow(parent)
{
	Base=0;
 //  ras=NULL;
}
void TWinSpp:: Unused()
{

}
void TWinSpp:: About()
{
	TDialog *kk;
   kk= new TDialog(this,IDD_ABOUT);
   if(kk->Execute()==IDOK) delete kk;
}
void TWinSpp:: Exit()
{
	CloseWindow();
}

void TWinSpp:: WriteRead()
{
  Base=0x378;//Direccion Base
  MXsboardDlg *ras1;
  ras1=NULL;
  if(ras1==NULL)
  {
  	ras1=new MXsboardDlg(this,IDD_RDWR,&Base);
  	if(ras1->Execute()==IDOK)  delete ras1;
   ras1=NULL;
  }
}
void TWinSpp:: ReadFileAddr()
{
	char *filenameWR;
//   TOpenSaveDialog::TData* File;
   MXsboard *pepe;
   FILE *pfi,*pfo;
   unsigned char address,data;

	TFileOpenDialog::TData File(OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST,
   	"Format: Address (*.ird)|*.IRD", 0, "","IRD");
   if ((TFileOpenDialog(this, File)).Execute()==IDOK){
      filenameWR= (char *)calloc(strlen(File.FileName)+1,sizeof(char));
      strcpy(filenameWR,File.FileName);
      int k=strlen(File.FileName);
      filenameWR[k+1]='\0';
      filenameWR[k]='w';
      filenameWR[k-1]='d';
      filenameWR[k-2]='r';
      pfo=fopen(filenameWR,"w");
      pfi=fopen(File.FileName,"r");
      pepe=new MXsboard(0x378);
      if((pfi!=NULL)&&(!feof(pfi)))fscanf(pfi,"%d",&address);
   	while((pfi!=NULL)&&(!feof(pfi)))
      {
            pepe->ExtReadADFPGA(address,&data);
      		fprintf(pfo,"%d %d\n",address,data);
            fscanf(pfi,"%d",&address);
      }
      delete pepe;
   	fclose(pfi);
   	fclose(pfo);
   }
}
void TWinSpp:: ReadFilePoll()
{
	char *filenameWR;
   TOpenSaveDialog::TData* File;
   MXsboard *pepe;
   FILE *pfi,*pfo;
   unsigned char address,data,amount;
	File = new TOpenSaveDialog::TData (OFN_PATHMUSTEXIST, "Format:  Amount Address (*.ird)|*.IRD", 0, "","IRD");
   if ((TFileOpenDialog(this, *File)).Execute()==IDOK){
      filenameWR= (char *)calloc(strlen(File->FileName)+1,sizeof(char));
      strcpy(filenameWR,File->FileName);
      int k=strlen(File->FileName);
      filenameWR[k+1]='\0';
      filenameWR[k]='w';
      filenameWR[k-1]='d';
      filenameWR[k-2]='r';
      pfo=fopen(filenameWR,"w");
      pfi=fopen(File->FileName,"r");
      pepe=new MXsboard(0x378);
   	while((pfi!=NULL)&&(!feof(pfi)))
      {
            fscanf(pfi,"%d %d",&amount,&address);
            pepe->ExtReadADFPGA(address,&data);
            while((pfi!=NULL)&&(!feof(pfi)))
            {
               fprintf(pfo, "Block Data amount: %d in address: %d\n",amount,address);
         	   for (int i=0;i<amount;i++){
      				fprintf(pfo,"%d %d %d\n",i,address,data);
   	         	pepe->ExtReadADFPGA(address,&data);
	            }
            	fscanf(pfi,"%d",&address);
            }
      }
      delete pepe;
	   fclose(pfi);
   	fclose(pfo);
   }
}
void TWinSpp:: WriteFileData()
{
	char *filenameWR;
   TOpenSaveDialog::TData* File;
   MXsboard *pepe;
   FILE *pfi;
   unsigned char address,data;
	File = new TOpenSaveDialog::TData (OFN_PATHMUSTEXIST, "Format: Data (*.rdw)|*.RDW", 0, "","RDW");
   if ((TFileOpenDialog(this, *File)).Execute()==IDOK){
      pfi=fopen(File->FileName,"r");
      pepe=new MXsboard(0x378);
   	while((pfi!=NULL)&&(!feof(pfi)))
      {
            fscanf(pfi,"%d",&data);
            pepe->ExtWriteDFPGA(data);
      }
      delete pepe;
   fclose(pfi);
   }
}
void TWinSpp:: WriteFileAddrData()
{
	char *filenameWR;
   TOpenSaveDialog::TData* File;
   MXsboard *pepe;
   FILE *pfi;
   int aux1,aux2;
   unsigned char address,data,media;
	File = new TOpenSaveDialog::TData (OFN_PATHMUSTEXIST, "Format: Address Data (*.rdw)|*.RDW", 0, "","RDW");
   if ((TFileOpenDialog(this, *File)).Execute()==IDOK){
      pfi=fopen(File->FileName,"r");
      pepe=new MXsboard(0x378);
      if((pfi!=NULL)&&(!feof(pfi)))fscanf(pfi,"%d %d",&aux1,&aux2);
      data=(unsigned char)aux2;
      address=(unsigned char)aux1;
   	while((pfi!=NULL)&&(!feof(pfi)))
      {
            pepe->ExtWriteADFPGA(data,address);
            fscanf(pfi,"%d %d",&aux1,&aux2);
            data=(unsigned char)aux2;
		      address=(unsigned char)aux1;

      }
      delete pepe;
	   fclose(pfi);
   }
}
void TWinSpp:: RandomReadWrite()
{
	char *filenameWR;
   TOpenSaveDialog::TData* File;
   MXsboard *pepe;
   char *line;
   FILE *pfi,*pfo;
   int aux1,aux2;
   char aux3;
   unsigned char address,data,media;
   char mode;

	File = new TOpenSaveDialog::TData (OFN_PATHMUSTEXIST, "Format: Address Data Mode(w/r) (*.ird)|*.IRD", 0, "","IRD");
   if ((TFileOpenDialog(this, *File)).Execute()==IDOK){
   	filenameWR= (char *)calloc(strlen(File->FileName)+1,sizeof(char));
      strcpy(filenameWR,File->FileName);
      int k=strlen(File->FileName);
      filenameWR[k]='\0';
      filenameWR[k-1]='w';
      filenameWR[k-2]='d';
      filenameWR[k-3]='r';
      pfi=fopen(File->FileName,"r");
      pfo=fopen(filenameWR,"w");
      pepe=new MXsboard(0x378);
      line= (char *)calloc(50,sizeof(char));
      aux3=2;
  		GetLine(pfi,&line[0]);
    	while((pfi!=NULL)&&(!feof(pfi)))
      {
      		if(line[0]=='#') ;
         	else sscanf(line,"%d %d %c",&aux1,&aux2,&aux3);
            data=(unsigned char)aux2;
      		address=(unsigned char)aux1;
      		mode=aux3;
            if (mode=='w')pepe->ExtWriteADFPGA(data,address);
            else if(mode=='r') pepe->ExtReadADFPGA(address,&data);
            if(mode!='q')fprintf(pfo,"%d %d %c\n",address,data,mode);
            else fprintf(pfo,"%s",line);
         	if (line!=NULL)free( line);
          	line=NULL;
           	line= (char *)calloc(50,sizeof(char));
            aux3='q';
      		GetLine(pfi,&line[0]);
      }
     	if (line!=NULL)free( line);
     	line=NULL;
      if (pepe!=NULL) free(pepe);
	   fclose(pfi);
      fclose(pfo);
   }
}
void TWinSpp:: GetLine(FILE* pfi, char *line)
{
	int nchar=0;
   int veces=1;
   char caracter;
   caracter=fgetc(pfi);
   line[0]=caracter;
   nchar++;
   while((caracter!='\n')&&(!feof(pfi)))
   {
      if(nchar==49)
      {
      	veces++;
      	line= (char *)realloc(line,veces*50);
         nchar=0;
      }

	   caracter=fgetc(pfi);
   	line[(veces-1)*50+nchar]=caracter;
      nchar++;

   }
}

void TSppApp:: InitMainWindow()
{
   EnableCtl3d();
//	TFrameWindow *MainWindow;
//  	fw =  new TFrameWindow("Control del Puerto EPP", IDM_MENU1,*new MWinEpp, true);
//  	fw->SetIcon(this, ICON_1);
//  	fw->SetIconSm(this,ICON_SMALL);
//  	fw->SetMenuDescr(TMenuDescr(IDM_MENU1,1,1,1,0,0,1));
   MainWindow=new TFrameWindow(NULL,"Dialog using SPP Port",new TWinSpp);
   MainWindow->AssignMenu(IDM_MENU1);
   MainWindow->EnableKBHandler();
   MainWindow->Attr.X=MainWindow->Attr.Y=100;
   MainWindow->Attr.W=400;
   MainWindow->Attr.H=140;
   MainWindow->SetIcon(this,IDI_ICON2);
   MainWindow->SetIconSm(this,IDI_ICON1);
//   MainWindow->Attr.Style|=WS_VSCROLL;
  	SetMainWindow(MainWindow);
}


int
OwlMain(int argc, char* argv[])
//OwlMain()
{
//   return TPresentApp(0).Run();
 	return TSppApp().Run();

}