#if !defined(XSBOARD_H)
#define XSBOARD_H


class  MXsboard : public TWindow {

public:
   MXsboard(unsigned Base);
   ~MXsboard();
   void ExtWriteADFPGA(uchar RegDato,uchar RegAddr);
   void ExtReadADFPGA(uchar RegAddr,uchar* RegData);
   void ExtWriteDFPGA(uchar RegDato);
private:
   unsigned PortD;
   unsigned PortS;
   unsigned PortC;

   uchar RegDato;
   uchar RegAddr;
   uchar RegCtrl;
   uchar RegStat;

   void Iniports();
   void InitializeFPGA();
};
#endif


