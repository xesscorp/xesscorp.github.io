#include <owl\pch.h>
#include <owl\applicat.h>
#include <owl\framewin.h>
#include <owl\dc.h>
#include <owl\edit.h>
#include <owl\button.h>
#include <owl\checkbox.h>
#include <owl\dialog.h>
#include <owl\static.h>
#include <stdlib.h>
#include <stdio.h>

#include "dlgsdef.h"
#include "DlPortIO.h"
#include "xsboarddlg.h"

/*
Assignment of port signals to FPGA controls:

Signal   VHDL Design Pin XC4010XL      COMMENTS
D0(pin2)  DIN(0)          p44         On Board Inverted
D1(pin3)  DIN(1)          p45         On Board Inverted
D2(pin4)  DIN(2)          p46
D3(pin5)  DIN(3)          p47
D4(pin6)  DIN(4)          p48
D5(pin7)  DIN(5)          p49
D6(pin8)  DIN(6)          p32             pin M0
D7(pin9)  DIN(7)          p34             pin M2

C0(STROBE) Do not touch. Must be permanent LOW!! Yuyu signal.
C1(AUTOF)  RST 			  p16			pin TCK; Port and On Board Inverted
C2(INIT)	  READB          p17             pin TMS
C3(SELIN)  WRITEB			  p15			pin TDI; Port Inverted

S3(ERROR)  DOUT(0)        p70
S4(SEL)    DOUT(1)        p77
S5(PEND)   DOUT(2)        p66
S6(ACK)    DOUT(3)        p69
S7(BUSY)*  NIBBLE         p75       pin TDO, Port and On Board Inverted
This signal is not used in this sample but implemented

PROTOCOL:
Due to the Inversions the Inactive STATE is C1,C3 LOW and C2 HIGH

Reset is active HIGH.

WRITE Cycle:
    1.- Write Data on Byte D
    2.- WRITEB goes to LOW, say, C3 goes to HIGH.
    3.- C3 goes to LOW

ADDRESS Write Cycle:
	 1.- Write Address on Byte D
    2.- WRITEB and READB goes to LOW simultaneously, say, C3 goes to HIGH
    and C1 goes to LOW.
    3.- C3 goes to LOW and C1 goes to HIGH.

READ Cycle is implemented in two steps:
	1.- In the first step READB goes LOW, say, C2 goes LOW.
   2.- C2 goes HIGH.
   3.- Read Lower Nibble and SHIFT Right one Byte
   4.- In the first step READB goes LOW, say, C2 goes LOW.
   5.- C2 goes HIGH.
   6.- Read Upper Nibble and SHIFT left three Bytes

*/
DEFINE_RESPONSE_TABLE1(MXsboardDlg,TDialog)
	EV_COMMAND(IDC_BESCXSB,WriteFPGA),
 	EV_COMMAND(IDC_BLEEXSB,ReadFPGA),
   EV_COMMAND(IDC_BRESET,InitializeFPGA),
END_RESPONSE_TABLE;

MXsboardDlg :: MXsboardDlg(TWindow *parent,TResId resid,unsigned *Base):TDialog(parent,resid)
{
	PortD=*Base;
   PortC=*Base+2;
   PortS=*Base+1;
   BtRead=new TButton(this,IDC_BLEEXSB);
   BtWrite=new TButton(this,IDC_BESCXSB);
   BtReset=new TButton(this,IDC_BRESET);
   TEdWr=new TEdit(this,IDC_ESCXSB,6);
   TEdRd=new TEdit(this,IDC_LEEXSB,6);
   TEdAw=new TEdit(this,IDC_DIRESC,6);
   TEdAr=new TEdit(this,IDC_DIRLEE,6);
   TVers=new TCheckBox(this,IDC_VERSION);

	Iniports();
//   InitializeFPGA();
}
MXsboardDlg :: ~MXsboardDlg()
{
;
}

void MXsboardDlg :: Iniports()
{
   RegCtrl = 0x04;  //00000100
	DlPortWritePortUchar(PortC, RegCtrl);
}

void  MXsboardDlg :: InitializeFPGA()
{
    if (TVers->GetCheck()==BF_UNCHECKED)
    {
    	RegCtrl= 0x06;   //00000110
    	DlPortWritePortUchar(PortC, RegCtrl);
    	RegCtrl= 0x04;
    	DlPortWritePortUchar(PortC, RegCtrl);
    }
}

void  MXsboardDlg :: ReadFPGA()
{
	 char aux[10];
    TEdAr->GetText(aux,10);
	 RegAddr=(uchar)atoi(aux);
    RegAddr=RegAddr ^ 0x03; //Due to the on board Inverters
	 DlPortWritePortUchar(PortD, RegAddr);
    RegCtrl= 0x08;
    DlPortWritePortUchar(PortC, RegCtrl);
    RegCtrl= 0x04;
    DlPortWritePortUchar(PortC, RegCtrl);


    RegCtrl= 0x00;
    DlPortWritePortUchar(PortC, RegCtrl);
    RegCtrl= 0x04;
    DlPortWritePortUchar(PortC, RegCtrl);
    uchar kk1 = DlPortReadPortUchar(PortS);
    RegCtrl= 0x00;
    DlPortWritePortUchar(PortC, RegCtrl);
    RegCtrl= 0x04;
    DlPortWritePortUchar(PortC, RegCtrl);
    uchar kk2 = DlPortReadPortUchar(PortS);
    kk1=(kk1 >> 3) & 0x0F;
    kk2=(kk2 << 1) & 0xF0;

    uchar dato=kk1 | kk2;
    char aux1[10];
    sprintf(aux1,"%d",dato);
    TEdRd->SetText(aux1);
}

void  MXsboardDlg :: WriteFPGA()
{
    char aux[10];
    TEdWr->GetText(aux,10);
	 RegDato=(uchar)atoi(aux);
    RegDato=RegDato ^ 0x03;  //Due to the on board Inverters
    TEdAw->GetText(aux,10);
	 RegAddr=(uchar)atoi(aux);
    RegAddr=RegAddr ^ 0x03;  //Due to the on board Inverters
    //Se escribe la direci�n
	 DlPortWritePortUchar(PortD, RegAddr);
    RegCtrl= 0x08;
    DlPortWritePortUchar(PortC, RegCtrl);
    RegCtrl= 0x04;
    DlPortWritePortUchar(PortC, RegCtrl);

	 DlPortWritePortUchar(PortD, RegDato);
    //la se�al Write es el Bit 3 del registro de control, invertido por hardware
    RegCtrl= 0x0E;
    DlPortWritePortUchar(PortC, RegCtrl);
    RegCtrl= 0x04;
    DlPortWritePortUchar(PortC, RegCtrl);
}


