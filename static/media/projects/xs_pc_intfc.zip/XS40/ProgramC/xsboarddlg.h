#if !defined(XSBOARDDLG_H)
#define XSBOARDDLG_H


class  MXsboardDlg : public TDialog {

public:
   MXsboardDlg(TWindow *parent,TResId resid,unsigned *Base);
   ~MXsboardDlg();
private:
   unsigned PortD;
   unsigned PortS;
   unsigned PortC;

   uchar RegDato;
   uchar RegAddr;
   uchar RegCtrl;
   uchar RegStat;

   TButton *BtRead;
   TButton *BtWrite;
   TButton *BtReset;
   TEdit *TEdWr;
   TEdit *TEdRd;
   TEdit *TEdAw;
   TEdit *TEdAr;
   TCheckBox *TVers;
   void Iniports();
   void InitializeFPGA();
	void ReadFPGA();
   void WriteFPGA();

   DECLARE_RESPONSE_TABLE(MXsboardDlg);
};
#endif


