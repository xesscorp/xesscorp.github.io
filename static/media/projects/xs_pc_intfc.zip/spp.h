/*
  Application Framework for Xsboard Communication based on SPP Port
  by Miguel A. Aguirre Ech�nove
  University of Sevilla (SPAIN)
  1/3rd/2000
*/

#if !defined(SPP_H)
#define SPP_H

class TWinSpp : public TWindow
{

public:
		TWinSpp(TWindow *parent=0);
      DECLARE_RESPONSE_TABLE(TWinSpp);
      MXsboardDlg *ras;
void  Unused();
void About();
void Exit();
void WriteRead();
void ReadFileAddr();
void ReadFilePoll();
void WriteFileData();
void WriteFileAddrData();
void RandomReadWrite();
void GetLine(FILE* pfi,char* line);
unsigned Base;
};


class TSppApp : public TApplication {


    void InitMainWindow();
	public:
   	TSppApp():TApplication("Spp"){};
};
#endif
