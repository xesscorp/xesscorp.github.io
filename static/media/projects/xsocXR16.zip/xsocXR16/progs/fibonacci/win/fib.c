//
// find the largest Fibonacci sequence number less
// than N
//

#include <stdio.h>
#include <stdlib.h>

enum { N = 10000 };

int main(int argc, char *argv[])
{
  int a = 1, b = 1, c = 1;

  printf("Calculating Fibonacci numbers...\n");
  
  while (c < N) {
    printf("a=%d, b=%d, c=%d\n",a,b,c);

    c = a + b;
    a = b;
    b = c;
  }

  printf("a=%d, b=%d, c=%d\n",a,b,c);

  system("PAUSE");	
  return 0;
}

