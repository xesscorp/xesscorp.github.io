Commands to build fib.c
-----------------------

> lcc-xr16 -S fib.c

This runs the lcc "C" compiler and generates the 
fib.s assembly file.

> xr16 -hex=fib.hex -lst=fib.lst reset.s fib.s

This is assembling the files reset.s and fib.s. The 
assembly code. A XESS compatible xes file is created
for downloading and a listing file is generated.

