//
// find the largest Fibonacci sequence number less
// than N
//

enum { N = 10000 };

int main() {

	int a = 1, b = 1, c = 1;

	int *a_ptr;
	int *b_ptr;
	int *c_ptr;

	a_ptr = (int *)0x0080;
	b_ptr = (int *)0x0082;
	c_ptr = (int *)0x0084;
	
	while (c < N) {
		c = a + b;
		a = b;
		b = c;
	}

	*a_ptr = a;
	*b_ptr = b;
	*c_ptr = c;

	while(1);  // loop forever
		
	return 0;
}
