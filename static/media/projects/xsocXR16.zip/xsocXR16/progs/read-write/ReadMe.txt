
A simple program that reads and writes to memory.

It was used to test the cpu interface to memory
for reading instructions, reading data and
writing data to memory.
