USING THE STEREO AUDIO CODEC ON THE XST-3.0 BOARD
    This is a simple design example that digitizes a stereo audio input and
    then converts it back into an audio output (i.e., a simple audio
    loopback).

DESIGN FILES
    * common.vhd
        This file contains some definitions and functions used in the rest
        of the VHDL code.

    * audio.vhd
        This is the VHDL file that describes an interface to the stereo
        audio codec and then uses this interface to digitize a stereo input
        waveform and then convert it back into an analog output. You can get
        a more detailed description of the codec interface at
        http://www.xess.com/appnotes/an-032904-codec.pdf .

    * audio.ucf
        These are the constraints which assign the I/O signals of the stereo
        codec interface to the appropriate pins of the FPGA on the
        XSA-3S1000 + XST-3.0 combination.

    * audio.bit
        This is a compiled bitstream for the design that can be downloaded
        into the XSA-3S1000 + XST-3.0 combination.

    * audio-200.ucf
        This is an alternate set of pin assignments to be used if the design
        is recompiled for an XSA-200 + XST-3.0 combination.

    * audio.npl
        Open this project file with WebPACK if you need to recompile the
        design.

USING THE DESIGN EXAMPLE
    * Step 1:
        Set jumper J9 on the XSA-3S1000 Board to XS.

    * Step 2:
        Download the default parallel port interface into the XSA-3S1000
        (\XSTOOLS\XSA\3S1000\dwnldpar.svf) if it is not already present.
        (Running GXSTEST will do this automatically.)

    * Step 3:
        Connect a stereo cable from the line-out of a PC audio card to the
        J1 (IN) jack of the XST-3.0 Board. Connect stereo headphones to the
        J2 (OUT) jack. On the XST-3.0 Board near the audio jacks, make sure
        the shunts are removed from jumpers JP2 and JP3 and placed on
        jumpers JP4 and JP5.

    * Step 4:
        Download the audio.bit file to the XSA Board.

    * Step 5:
        Use Windows Media Player to play a .wav file from the \WINDOWS\Media
        folder. The sound should be output through the headphones. Hold down
        pushbutton PB1 on the XST-3.0 Board to keep the circuit in the FPGA
        in its reset state. No sound should come from the headphones while
        the circuit is in the reset state.

ENVIRONMENT
    This example design was developed using the following version of
    software:

       Xilinx WebPACK       : 6.3.03i

SOURCE FILES
    You can download the source files for this example design from the XESS
    website at http://www.xess.com/projects/xst3_audio.zip .

AUTHOR
    Dave Vanden Bout, X Engineering Software Systems Corp.

    Send bug reports to bugs@xess.com.

COPYRIGHT AND LICENSE
    Copyright 2006 by X Engineering Software Systems Corporation.

    This application can be freely distributed and modified as long as you
    do not remove the attributions to the author or his employer.

HISTORY
    01/29/2006 - Initial release.

